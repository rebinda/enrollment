<!doctype html>
<html>
     <head>
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <link href="fontawesome5.9.0/css/all.min.css" rel="stylesheet">
          <link href="bootstrap-4.3.1/css/bootstrap.min.css" rel="stylesheet">
          <link href="bootstrap4-toggle-3.5.0/css/bootstrap4-toggle.min.css" rel="stylesheet"> 
          <script src="js/jquery-3.3.1.min.js"></script> 
          <script src="js/popper.min.js"></script> 
          <script src="bootstrap-4.3.1/js/bootstrap.min.js"></script> 
          <script src="bootstrap4-toggle-3.5.0/js/bootstrap4-toggle.min.js"></script> 
          <meta charset="utf-8">
          <title>PSU Computer Studies Department PEF</title>
          <style>
               ul {
                    list-style: none;
               }
               .topic {cursor: pointer;}
               a, a:link, a:visited {color:#000000;}
          </style>
     </head>

<body>
     <div class="container">
          <div class="row">
               <div class="col-md-12">
                    <h1 id="faq" class="text-center"><strong>FAQ</strong></h1>                    
                              <p class="topic alert alert-primary" data-toggle="collapse" data-target="#demo1"><strong><a href="#"><i class="fas fa-question-circle fa-lg"></i> What should I do if I don't know my ID Number?</a></strong></p>
                              <div id="demo1" class="alert alert-primary collapse">
                                   <ol>
                                        <li><p>From the login page, click the link <code>Get your ID Number HERE!</code></p>                                   
                                             <p><img src="img/1.png" class="img-thumbnail img-fluid"/></p>
                                             <p>This will display the page for accessing your ID Number.</p>
                                             <p><img class="img-thumbnail img-fluid" src="img/2.png"/></p>
                                        </li>
                                        <li>
                                             <p>Fill-in your Lastname, Firstname and Birthdate correctly then click <code>Retrieve</code> Button.</p>
                                             <p><img src="img/3.png" class="img-thumbnail img-fluid"/></p>
                                             <p>Your ID Number is shown in Red Box.</p>
                                             <p>If it shows an error similar to the image below, probably your Lastname or Firstname is incorrect. Otherwise, your ID Number is still in process (You may contact your respective College Secretary).</p>
                                             <p><img src="img/4.png" class="img-thumbnail img-fluid"/></p>                                           
                                        </li>
                                   </ol>
                              </div>                                                      
                              <p class="topic alert alert-warning" data-toggle="collapse" data-target="#demo2"><strong><a href="#"><i class="fas fa-question-circle fa-lg"></i> How to recover my Password?</a></strong></p>
                              <div id="demo2" class="alert alert-warning collapse">
                                   <ol>
                                        <li>
                                             <p>From the login page, click the link <code>Recover your Password HERE!</code></p>
                                             <p><img src="img/5.png" class="img-thumbnail img-fluid"/></p>
                                             <p>This will display the page for recovering your Password.</p>
                                             <p><img class="img-thumbnail img-fluid" src="img/6.png"/></p>                                             
                                        </li>
                                        <li>
                                             <p>Fill-in your ID Number(No Dashes), Firstname and Lastname correctly then click <code>Recover</code> Button.</p>
                                             <p><img class="img-thumbnail img-fluid" src="img/7.png"/></p>
                                             <p>Your Password is shown in Red Box.</p>
                                             <p>If it shows an error similar to the image below, review the casing and spelling of your Lastname, Firstname, and ID Number.</p>
                                             <p><img class="img-thumbnail img-fluid" src="img/8.png"/></p>
                                        </li>
                                   </ol>
                              </div>                         
                              <p class="topic alert alert-danger" data-toggle="collapse" data-target="#demo3"><strong><a  href="#"><i class="fas fa-question-circle fa-lg"></i> How to change my Password?</a></strong></p>
                              <div id="demo3" class="alert alert-danger collapse">
                                   <ol>
                                        <li>
                                             <p>Login using your ID Number and Password.</p>
                                        </li>
                                        <li>
                                             <p>Once inside the CSPEF, click <code>UPDATE REGISTRATION NOW</code> if you are a first time user.</p>
                                             <p><img class="img-thumbnail img-fluid" src="img/9.png"/></p>
                                        </li>
                                        <li><p>If you have previously used the CSPEF, click the <code>Burger</code> icon.</p></li>
                                        <p><img class="img-thumbnail img-fluid" src="img/10.png"/></p>
                                        <li>
                                             <p>Click <code>Modify Personal Info</code></p>
                                             <p><img class="img-thumbnail img-fluid" src="img/11.png"/></p>
                                        </li>
                                        <li>
                                             <p>Both steps 3 and 4 will take you to the page shown below.</p>
                                             <p><img class="img-thumbnail img-fluid" src="img/12.png"/></p>
                                             <p>Apply the necessary changes then click <code>Update Button</code> to save the changes.</p>
                                        </li>
                                   </ol>
                              </div>                        
                              <p class="topic alert alert-primary" data-toggle="collapse" data-target="#demo4"><strong><a href="#"><i class="fas fa-question-circle fa-lg"></i> How to update my Personal Information?</a></strong></p>
                              <div id="demo4" class="alert alert-primary collapse">
                                   <p>See <strong class="text-danger">step 3 of How to change my Password.</strong></p>
                              
                              </div>                       
                              <p class="topic alert alert-warning" data-toggle="collapse" data-target="#demo5"><strong><a href="#"><i class="fas fa-question-circle fa-lg"></i> I can't submit my PEF.</a></strong></p>
                              <div id="demo5" class="alert alert-warning collapse">
                                   <p>Submission of PEF is allowed only ones. This is to avoid congestion of PEF on the side of your Enrolling Advisers that would cause delay in evaluating your PEF.</p>
                                   <p>To submit another PEF, you must delete your subjects and GET another one then click <code>submit</code> button..</p>
                                   <p><strong>IMPORTANT:</strong> You cannot delete subjects that have been already approved by your chairperson. See Total Units approved by Chairperson.</p>
                              </div>                        
                              <p class="topic alert alert-danger" data-toggle="collapse" data-target="#demo6"><strong><a href="#"><i class="fas fa-question-circle fa-lg"></i> I want to delete my subject so I can choose a different one.</a></strong></p>
                              <div id="demo6" class="alert alert-danger collapse">
                                   <ol>
                                        <li>
                                             <p>Click the <code>View</code> button.</p>
                                             <p><img class="img-thumbnail img-fluid" src="img/13.png"/></p>
                                             <p>This will display the subjects that you have selected.</p>
                                             <p><img class="img-thumbnail img-fluid" src="img/14.png"/></p>
                                             <p>Click the <code>Trashbin</code> button before the subject code. This will permanently delete your subject.</p>
                                             <p><strong>IMPORTANT:</strong> You cannot delete subjects that have been already approved by your chairperson. See Total Units approved by Chairperson.</p>
                                        </li>
                                        
                                   </ol>
                              </div>                        
                              <p class="topic alert alert-primary" data-toggle="collapse" data-target="#demo7"><strong><a href="#"><i class="fas fa-question-circle fa-lg"></i> I want to see the progress of my PEF.</a></strong></p>
                              <div id="demo7" class="alert alert-primary collapse">
                                   <ol>
                                        <li>
                                             <p>Login to CSPEF.</p>                                             
                                        </li>
                                        <li>
                                             <p>Once inside the CSPEF, click the <code>Burger</code> icon.</p>
                                             <p><img class="img-thumbnail img-fluid" src="img/15.png"/></p>                                             
                                        </li>
                                        <li>
                                             <p>Select your PEF Number.</p>
                                             <p><img class="img-thumbnail img-fluid" src="img/16.png"/></p>
                                             <p>This will display the progress of your PEF.</p>
                                             <p><img class="img-thumbnail img-fluid" src="img/17.png"/></p>
                                             <p><strong>IMPORTANT:</strong> If no PEF number is showing in the Dropdown List, it indicates that you have not submitted your subjects.</p>
                                        </li>
                                   </ol>
                              </div>                         
               </div>
          </div>
          <div class="row">
               <div class="col-md-12">
                    <h2 class="text-center"><strong>PEF MESSAGES</strong></h2>
                    <p><strong>The following briefly describes the causes of receiving dialog messages.</strong></p>
                    <div class="alert alert-primary"><p><img class="img-thumbnail" src="img/20.png"/></p>
                    <p>This message shows up when you GET a subject that is already in your PEF.</p></div>
                    <div class="alert alert-info"><p><img class="img-thumbnail" src="img/21.png"/></p>
                    <p>This message appears whenever there are DAY/TIME conflict between the subjects you are getting and the subjects you have in your PEF.</p></div>
                    <div class="alert alert-danger"><p><img class="img-thumbnail" src="img/24.png"/></p>
                    <p>This message appears when the subject you are getting has reached the maximum class size.</p></div>
                    <div class="alert alert-primary"><p><img class="img-thumbnail" src="img/19.png"/></p>                         
                    <p>This message shows up if you are clicking the <code>Submit Button</code> without getting/selecting any subjects.</p></div>
                    <div class="alert alert-info"><p><img class="img-thumbnail" src="img/22.png"/></p>
                    <p>This message is displayed when you are clicking the <code>Submit Button</code> or submitting your PEF for the second time. Each user is allowed to submit his/her PEF only ones.</p></div>
                    <div class="alert alert-danger"><p><img class="img-thumbnail" src="img/18.png"/></p>                    
                    <p>You will receive this message if there are problems on your financial or academic record. Expect that you will receive a phone call or a text message from your respective Enrolling Officer to discuss the cause of this matter.</p>
                    <p>If you have not received a phone call or a text message, you may contact your respective Enrolling Officer or Chairperson.</p></div>
                    <div class="alert alert-primary"><p><img class="img-thumbnail" src="img/23.png"/></p>
                    <p>You will receive this message once your PEF has been encoded.</p></div>
               </div>
          </div>
          <div class="row">
               <div class="col-md-12">
                    <h2 id="video" class="text-center"><strong>TUTORIAL</strong></h2>
               </div>
          </div>
          <div class="row"> 
               <div class="col-md-12">
                    <p><strong>For Freshmen and Transferees</strong></p>
                    <iframe width="384" height="341" src="https://www.youtube.com/embed/eEcw7mBDBuA?list=PLHAzQYpYnxWHITILoyQCQ5TU2I6OMOG03" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
               </div>               
          </div>
     </div>
</body>
</html>