<?php
session_start();
if( $_SERVER[ 'REQUEST_METHOD' ] == "POST" ) {
     if(isset($_POST['back'])) {
          header("Location: include/logout.php");
     }
     if (isset($_POST['agree'])) {
          header("Location: survey.php");
     }
}
?>
<!doctype html>
<html>
<head>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link href="fontawesome5.9.0/css/all.min.css" rel="stylesheet">
     <link href="bootstrap-4.3.1/css/bootstrap.min.css" rel="stylesheet">
     <script src="js/jquery-3.3.1.min.js"></script>
     <script src="js/popper.min.js"></script>
     <script src="bootstrap-4.3.1/js/bootstrap.min.js"></script>
     <script src="js/devicedetector-min.js"></script>
     <meta charset="utf-8">
     <title>PSU Computer Studies Department PEF</title>
</head>

<body>
     <h2 class="text-center alert alert-primary">DATA PRIVACY</h2>
     <div class="container">          
          <div class="row">
               <div class="col-md-12">
                    <p class="text-justify text-muted">By filling up this form, you agree that we can collect and process your personal information for purposes related to enrollment and education. You acknowledge that this information will be handled by selected Faculty of the College, as well as other authorized staff and advisers from the University. 
Your records may be retained for legal purposes only. Any information we receive through this means will be protected against loss, misuse or unauthorized alteration through technical and organizational measures. 
Rest assured that your information as provided will be handled properly and securely.</p>
               </div>
          </div>
          <div class="row">
               <div class="col-md-12">
                    <form role="form" id="reg" method="post" action="<?php echo( htmlspecialchars($_SERVER["PHP_SELF"])); ?>">
                         <div class="text-center"><button id="idsubmit" class="btn btn-success" type="submit" value="agree" name="agree"><i class="fas fa-check"></i> I Agree</button> <button id="idlogout" class="btn btn-danger" type="submit" value="Back" name="back"><i class="fas fa-home"></i> Disagree</button></div>
                    </form>
               </div>
          </div>
          <div class="row">
               <div class="col-md-12">                    
                    <p class="text-center text-primary small" style="margin-top:20px;">Powered by Computer Studies. Copyright 2019</p>
               </div>
          </div>
     </div>
</body>
</html>