<?php
session_start();
if (!isset($_SESSION['is_login'])) {
	header("Location: /pef");
}

$idstudent = $_SESSION['idstudent'];
include_once('include/connect.php');

$err1 = '';
$err2 = '';
$err3 = '';
$err4 = '';
$err5 = '';
$err6 = '';
$err7 = '';
$err8 = '';
$err9 = '';
$err10 = '';
$err11 = '';
$err12 = '';
$err13 = '';
$err14 = '';
$err15 = '';
$err16 = '';
$err17 = '';
$err18 = '';

if ($_SERVER['REQUEST_METHOD']=="POST") {	
	if(isset($_POST['submit'])) {
		
		
		$q1 = 0;
		$q2 = 0;
		$q3 = 0;
		$q4 = 0;
		$q5 = 0;
		$q6 = 0;
		$q7 = 0;
		$q8 = 0;
		$q9 = 0;
		$q10 = 0;
		$q11 = 0;
		$q12 = 0;
		$q13 = 0;
		$q14 = 0;
		$q15 = 0;
		$q16 = 0;
		$q17 = 0;
          $q18 = 0;
		
		$ans1 = 0;
		$ans2 = 0;
		$ans3 = 0;
		$ans4 = 0;
		$ans5 = 0;
		$ans6 = 0;
		$ans7 = 0;
		$ans8 = 0;
		$ans9 = 0;
		$ans10 = 0;
		$ans11 = 0;
		$ans12 = 0;
		$ans13 = 0;
          $ans14 = 0;
		$ans15 = 0;
		$ans16 = 0;
		$ans17 = 0;
          $ans18 = 0;
		
		$exp1 = '';
		$exp2 = '';
		$exp3 = '';
		$exp4 = '';
		$exp5 = '';
		$exp6 = '';
		$exp7 = '';
		$exp8 = '';
		$exp9 = '';
		$exp10 = '';
		$exp11 = '';
		$exp12 = '';          
		$exp13 = '';
          $exp14 = '';
          $exp17 = '';
          $exp18 = '';
		
		if (isset( $_POST['q1'])) {$q1 = $_POST['q1'];}
		if (isset($_POST['q2'])) {$q2 = $_POST['q2'];}
		if (isset($_POST['q3'])) {$q3 = $_POST['q3'];}
		if (isset($_POST['q4'])) {$q4 = $_POST['q4'];}
		if (isset($_POST['q5'])) {$q5 = $_POST['q5'];}
		if (isset($_POST['q6'])) {$q6 = $_POST['q6'];}
		if (isset($_POST['q7'])) {$q7 = $_POST['q7'];}
		if (isset($_POST['q8'])) {$q8 = $_POST['q8'];}		
		if (isset($_POST['q9'])) {$q9 = $_POST['q9'];}
		if (isset($_POST['q10'])) {$q10 = $_POST['q10'];}
		if (isset($_POST['q11'])) {$q11 = $_POST['q11'];}
		if (isset($_POST['q12'])) {$q12 = $_POST['q12'];}
		if (isset($_POST['q13'])) {$q13 = $_POST['q13'];}
          if (isset($_POST['q14'])) {$q14 = $_POST['q14'];}
          if (isset($_POST['q15'])) {$q15 = $_POST['q15'];}
          if (isset($_POST['q16'])) {$q16 = $_POST['q16'];}
          if (isset($_POST['q17'])) {$q17 = $_POST['q17'];}
          if (isset($_POST['q18'])) {$q18 = $_POST['q18'];}
		
		
		if (isset($_POST['ans1'])) {$ans1 = $_POST['ans1'];}else{$err1='Please answer Test A item 1.';}
		if (isset($_POST['ans2'])) {$ans2 = $_POST['ans2'];}else{$err2='Please answer Test A item 2.';}
		if (isset($_POST['ans3'])) {$ans3 = $_POST['ans3'];}else{$err3='Please answer Test A item 3.';}
		if (isset($_POST['ans4'])) {$ans4 = $_POST['ans4'];}else{$err4='Please answer Test A item 4.';}
		if (isset($_POST['ans5'])) {$ans5 = $_POST['ans5'];}else{$err5='Please answer Test A item 5.';}
          if (isset($_POST['ans6'])) {$ans6 = $_POST['ans6'];}else{$err6='Please answer Test A item 6.';}
          if (isset($_POST['ans7'])) {$ans7 = $_POST['ans7'];}else{$err7='Please answer Test A item 7.';}
          
		if (isset($_POST['ans8'])) {$ans8 = $_POST['ans8'];}else{$err8='Please answer Test B item 1.';}
		if (isset($_POST['ans9'])) {$ans9 = $_POST['ans9'];}else{$err9='Please answer Test B item 2.';}
		if (isset($_POST['ans10'])) {$ans10 = $_POST['ans10'];}else{$err10='Please answer Test B item 3.';}
		if (isset($_POST['ans11'])) {$ans11 = $_POST['ans11'];}else{$err11='Please answer Test B item 4.';}
		if (isset($_POST['ans12'])) {$ans12 = $_POST['ans12'];}else{$err12='Please answer Test B item 5.';}
		if (isset($_POST['ans13'])) {$ans13 = $_POST['ans13'];}else{$err13='Please answer Test B item 6.';}
		if (isset($_POST['ans14'])) {$ans14 = $_POST['ans14'];}else{$err14='Please answer Test B item 7.';}
          
		if (isset($_POST['ans15'])) {$ans15 = $_POST['ans15'];}else{$err15='Please answer Test C item 1.';}
          if (isset($_POST['ans16'])) {$ans16 = $_POST['ans16'];}else{$err16='Please answer Test C item 2.';}
          if (isset($_POST['ans17'])) {$ans17 = $_POST['ans17'];}else{$err17='Please answer Test D item 1.';}
          if (isset($_POST['ans18'])) {$ans18 = $_POST['ans18'];}else{$err18='Please answer Test D item 2.';}
		
		
		if (isset($_POST['exp1'])) {$exp1 = $_POST['exp1'];}
		if (isset($_POST['exp2'])) {$exp2 = $_POST['exp2'];}
		if (isset($_POST['exp3'])) {$exp3 = $_POST['exp3'];}
		if (isset($_POST['exp4'])) {$exp4 = $_POST['exp4'];}
		if (isset($_POST['exp5'])) {$exp5 = $_POST['exp5'];}
		if (isset($_POST['exp6'])) {$exp6 = $_POST['exp6'];}
		if (isset($_POST['exp7'])) {$exp7 = $_POST['exp7'];}
		if (isset($_POST['exp8'])) {$exp8 = $_POST['exp8'];}
		if (isset($_POST['exp9'])) {$exp9 = $_POST['exp9'];}
		if (isset($_POST['exp10'])) {$exp10 = $_POST['exp10'];}
		if (isset($_POST['exp11'])) {$exp11 = $_POST['exp11'];}
		if (isset($_POST['exp12'])) {$exp12 = $_POST['exp12'];}
		if (isset($_POST['exp13'])) {$exp13 = $_POST['exp13'];}
          if (isset($_POST['exp14'])) {$exp14 = $_POST['exp14'];}
          if (isset($_POST['exp15'])) {$exp15 = $_POST['exp15'];}
          if (isset($_POST['exp16'])) {$exp16 = $_POST['exp16'];}
          if (isset($_POST['exp17'])) {$exp17 = $_POST['exp17'];}
          if (isset($_POST['exp18'])) {$exp18 = $_POST['exp18'];}
		
				
		$fq = array(
			array($q1, $ans1, $exp1, $idstudent),
			array($q2, $ans2, $exp2, $idstudent),
			array($q3, $ans3, $exp3, $idstudent),
			array($q4, $ans4, $exp4, $idstudent),
			array($q5, $ans5, $exp5, $idstudent),
			array($q6, $ans6, $exp6, $idstudent),
			array($q7, $ans7, $exp7, $idstudent),
			array($q8, $ans8, $exp8, $idstudent),
			array($q9, $ans9, $exp9, $idstudent),
			array($q10, $ans10, $exp10, $idstudent),
			array($q11, $ans11, $exp11, $idstudent),
			array($q12, $ans12, $exp12, $idstudent),
			array($q13, $ans13, $exp13, $idstudent),
               array($q14, $ans14, $exp14, $idstudent),
               array($q15, $ans15, null, $idstudent),
               array($q16, $ans16, null, $idstudent),
               array($q17, $ans17, $exp17, $idstudent),
               array($q18, $ans18, $exp18, $idstudent)
		);
		
		if($ans1>0 && $ans1>0 && $ans3>0 && $ans4>0 && $ans5>0 && $ans6>0 && $ans7>0 && $ans8>0 && $ans9>0 && $ans10>0 && $ans11>0 && $ans12>0 && $ans13>0 && $ans14>0 && $ans15>0 && $ans16>0 && $ans17>0 && $ans18>0) {
			
			$stmt = $pdo->prepare("INSERT INTO survey(idsurvey_question, ans, explanation, idstudent) VALUES(?, ?, ?, ?)");	

			for($row=0; $row<=17; $row++) {			
				$stmt->execute([$fq[$row][0], $fq[$row][1], $fq[$row][2], $fq[$row][3]]);
			}
			header("Location: pef.php");
		}		
	}
}

?>
<!doctype html>
<html>
     <head>
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <link href="fontawesome5.9.0/css/all.min.css" rel="stylesheet">
          <link href="bootstrap-4.3.1/css/bootstrap.min.css" rel="stylesheet">
          <script src="js/jquery-3.3.1.min.js"></script>
          <script src="js/popper.min.js"></script>
          <script src="bootstrap-4.3.1/js/bootstrap.min.js"></script>
          <title>Survey Form</title>
          <script>
               $(function(){
                    function scroll_now(elem){
                         $("html, body").animate({scrollTop:elem.offset().top},1000);
                         elem.focus();
                    } 
                    $('form').submit(function(e){
                         
                         $(".question").removeClass("alert alert-danger");
                         $(".explain").removeClass("alert alert-danger");
                         
                         if(!$("input[name='ans1']").is(":checked")){
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("Answer Question A No. 1");                              
                              $('#myModal').modal('show');
                              $(".question1").addClass("alert alert-danger");
                              scroll_now($("input[name='ans1']"));
                              e.preventDefault();
                              return;
                         } 
                         
                         if(($("input[name='ans1']:checked").val()<4) && ($.trim($("input[name='exp1']").val())=='')){
                              $('#myModal .modal-title').text("REASON NEEDED...");
                              $('#myModal .modal-body').text("State your Reason.");
                              $('#myModal').modal('show');
                              $(".exp1").addClass("alert alert-danger");
                              scroll_now($("input[name='exp1']"));
                              e.preventDefault();
                              return;
                         } 
                         if(!$("input[name='ans2']").is(":checked")){
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("Answer Question A No. 2");
                              $('#myModal').modal('show');
                              $(".question2").addClass("alert alert-danger");
                              scroll_now($("input[name='ans2']"));
                              e.preventDefault();
                              return;
                         }
                         
                         if($("input[name='ans2']:checked").val()<4 && $.trim($("input[name='exp2']").val())==''){
                              $('#myModal .modal-title').text("REASON NEEDED...");
                              $('#myModal .modal-body').text("State your Reason.");
                              $('#myModal').modal('show');
                              $(".exp2").addClass("alert alert-danger");
                              scroll_now($("input[name='exp2']"));
                              e.preventDefault();
                              return;
                         } if(!$("input[name='ans3']").is(":checked")){
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("Answer Question A No. 3");
                              $('#myModal').modal('show');
                              $(".question3").addClass("alert alert-danger");
                              scroll_now($("input[name='ans3']"));
                              e.preventDefault();
                              return;
                         } 
                         if($("input[name='ans3']:checked").val()< 4 && $.trim($("input[name='exp3']").val())==''){
                              $('#myModal .modal-title').text("REASON NEEDED...");
                              $('#myModal .modal-body').text("State your Reason.");
                              $('#myModal').modal('show');
                              $(".exp3").addClass("alert alert-danger");
                              scroll_now($("input[name='exp3']"));
                              e.preventDefault();
                              return;
                         } 
                         if(!$("input[name='ans4']").is(":checked")){
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("Answer Question A No. 4");
                              $('#myModal').modal('show');
                              $(".question4").addClass("alert alert-danger");
                              scroll_now($("input[name='ans4']"));
                              e.preventDefault();
                              return; } 
                         if($("input[name='ans4']:checked").val()<4&&$.trim($("input[name='exp4']").val())==''){
                              $('#myModal .modal-title').text("REASON NEEDED...");
                              $('#myModal .modal-body').text("State your Reason.");
                              $('#myModal').modal('show');
                              $(".exp4").addClass("alert alert-danger");
                              scroll_now($("input[name='exp4']"));
                              e.preventDefault();
                              return;
                         } 
                         if(!$("input[name='ans5']").is(":checked")){
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("Answer Question A No. 5");
                              $('#myModal').modal('show');
                              $(".question5").addClass("alert alert-danger");
                              scroll_now($("input[name='ans5']"));
                              e.preventDefault();
                              return;
                         } 
                         if($("input[name='ans5']:checked").val()<4 && $.trim($("input[name='exp5']").val())==''){
                              $('#myModal .modal-title').text("REASON NEEDED...");
                              $('#myModal .modal-body').text("State your Reason.");
                              $('#myModal').modal('show');
                              $(".exp5").addClass("alert alert-danger");
                              scroll_now($("input[name='exp5']"));
                              e.preventDefault();
                              return;
                         } 
                         
                         if(!$("input[name='ans6']").is(":checked")){
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("Answer Question A No. 6");
                              $('#myModal').modal('show');
                              $(".question6").addClass("alert alert-danger");
                              scroll_now($("input[name='ans6']"));
                              e.preventDefault();
                              return;
                         } 
                         if($("input[name='ans6']:checked").val()<4 && $.trim($("input[name='exp6']").val())==''){
                              $('#myModal .modal-title').text("REASON NEEDED...");
                              $('#myModal .modal-body').text("State your Reason.");
                              $('#myModal').modal('show');
                              $(".exp6").addClass("alert alert-danger");
                              scroll_now($("input[name='exp6']"));
                              e.preventDefault();
                              return;
                         }
                         
                         if(!$("input[name='ans7']").is(":checked")){
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("Answer Question A No. 7");
                              $('#myModal').modal('show');
                              $(".question7").addClass("alert alert-danger");
                              scroll_now($("input[name='ans7']"));
                              e.preventDefault();
                              return;
                         } 
                         if($("input[name='ans7']:checked").val()<4 && $.trim($("input[name='exp7']").val())==''){
                              $('#myModal .modal-title').text("REASON NEEDED...");
                              $('#myModal .modal-body').text("State your Reason.");
                              $('#myModal').modal('show');
                              $(".exp7").addClass("alert alert-danger");
                              scroll_now($("input[name='exp7']"));
                              e.preventDefault();
                              return;
                         }
                         
                         if(!$("input[name='ans8']").is(":checked")){
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("Answer Question B No. 1");
                              $('#myModal').modal('show');
                              $(".question8").addClass("alert alert-danger");
                              scroll_now($("input[name='ans8']"));
                              e.preventDefault();
                              return;
                         } 
                         if($("input[name='ans8']:checked").val()==2 && $.trim($("input[name='exp8']").val())==''){
                              $('#myModal .modal-title').text("REASON NEEDED...");
                              $('#myModal .modal-body').text("State your Reason.");
                              $('#myModal').modal('show');
                              $(".exp8").addClass("alert alert-danger");
                              scroll_now($("input[name='exp8']"));
                              e.preventDefault();
                              return;
                         } 
                         if(!$("input[name='ans9']").is(":checked")){
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("Answer Question B No. 2");
                              $('#myModal').modal('show');
                              $(".question9").addClass("alert alert-danger");
                              scroll_now($("input[name='ans9']"));
                              e.preventDefault();
                              return;
                         } 
                         if($("input[name='ans9']:checked").val()== 2 && $.trim($("input[name='exp9']").val())==''){
                              $('#myModal .modal-title').text("REASON NEEDED...");
                              $('#myModal .modal-body').text("State your Reason.");
                              $('#myModal').modal('show');
                              $(".exp9").addClass("alert alert-danger");
                              scroll_now($("input[name='exp9']"));
                              e.preventDefault();
                              return;
                         } 
                         if(!$("input[name='ans10']").is(":checked")){
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("Answer Question B No. 3");
                              $('#myModal').modal('show');
                              $(".question10").addClass("alert alert-danger");
                              scroll_now($("input[name='ans10']"));
                              e.preventDefault();
                              return;
                         } 
                         if($("input[name='ans10']:checked").val()==2&&$.trim($("input[name='exp10']").val())==''){
                              $('#myModal .modal-title').text("REASON NEEDED...");
                              $('#myModal .modal-body').text("State your Reason.");
                              $('#myModal').modal('show');
                              $(".exp10").addClass("alert alert-danger");
                              scroll_now($("input[name='exp10']"));
                              e.preventDefault();
                              return;
                         } 
                         if(!$("input[name='ans11']").is(":checked")){
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("Answer Question B No. 4");
                              $('#myModal').modal('show');
                              $(".question11").addClass("alert alert-danger");
                              scroll_now($("input[name='ans11']"));
                              e.preventDefault();
                              return;
                         } 
                         if($("input[name='ans11']:checked").val()==2&&$.trim($("input[name='exp11']").val())==''){
                              $('#myModal .modal-title').text("REASON NEEDED...");
                              $('#myModal .modal-body').text("State your Reason.");
                              $('#myModal').modal('show');
                              $(".exp11").addClass("alert alert-danger");
                              scroll_now($("input[name='exp11']"));
                              e.preventDefault();
                              return;
                         } 
                         if(!$("input[name='ans12']").is(":checked")){
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("Answer Question B No. 5");
                              $('#myModal').modal('show');
                              $(".question12").addClass("alert alert-danger");
                              scroll_now($("input[name='ans12']"));
                              e.preventDefault();
                              return;
                         } 
                         if($("input[name='ans12']:checked").val()==2&&$.trim($("input[name='exp12']").val())==''){
                              $('#myModal .modal-title').text("REASON NEEDED...");
                              $('#myModal .modal-body').text("State your Reason.");
                              $('#myModal').modal('show');
                              $(".exp12").addClass("alert alert-danger");
                              scroll_now($("input[name='exp12']"));
                              e.preventDefault();
                              return;
                         } 
                         
                         if(!$("input[name='ans13']").is(":checked")){
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("Answer Question B No. 6");
                              $('#myModal').modal('show');
                              $(".question13").addClass("alert alert-danger");
                              scroll_now($("input[name='ans13']"));
                              e.preventDefault();
                              return;
                         } 
                         
                         if($("input[name='ans13']:checked").val()==2&&$.trim($("input[name='exp13']").val())==''){
                              $('#myModal .modal-title').text("REASON NEEDED...");
                              $('#myModal .modal-body').text("State your Reason.");
                              $('#myModal').modal('show');
                              $(".exp13").addClass("alert alert-danger");
                              scroll_now($("input[name='exp13']"));
                              e.preventDefault();
                              return;
                         }
                         
                         if(!$("input[name='ans14']").is(":checked")){
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("Answer Question B No. 7");
                              $('#myModal').modal('show');
                              $(".question14").addClass("alert alert-danger");
                              scroll_now($("input[name='ans14']"));
                              e.preventDefault();
                              return;
                         }
                         
                         if($("input[name='ans14']:checked").val()==2&&$.trim($("input[name='exp14']").val())==''){
                              $('#myModal .modal-title').text("REASON NEEDED...");
                              $('#myModal .modal-body').text("State your Reason.");
                              $('#myModal').modal('show');
                              $(".exp14").addClass("alert alert-danger");
                              scroll_now($("input[name='exp14']"));
                              e.preventDefault();
                              return;
                         }
                         
                         if(!$("input[name='ans15']").is(":checked")){
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("Answer Question C No. 1");
                              $('#myModal').modal('show');
                              $(".question15").addClass("alert alert-danger");
                              scroll_now($("input[name='ans15']"));
                              e.preventDefault();
                              return;
                         } 
                         if(!$("input[name='ans16']").is(":checked")){
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("Answer Question C No. 2");
                              $('#myModal').modal('show');
                              $(".question16").addClass("alert alert-danger");
                              scroll_now($("input[name='ans16']"));
                              e.preventDefault();
                              return;
                         } 
                         if(!$("input[name='ans17']").is(":checked")){
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("Answer Question D No. 1");
                              $('#myModal').modal('show');
                              $(".question17").addClass("alert alert-danger");
                              scroll_now($("input[name='ans17']"));
                              e.preventDefault();
                              return;
                         } 
                         
                         if ($.trim($("input[name='exp17']").val())=='') {
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("State your reason on Question D No. 1");
                              $('#myModal').modal('show');
                              $(".exp17").addClass("alert alert-danger");
                              scroll_now($("input[name='exp17']"));
                              e.preventDefault();
                              return;
                         }
                         
                         if(!$("input[name='ans18']").is(":checked")){
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("Answer Question D No. 2");
                              $('#myModal').modal('show');
                              $(".question18").addClass("alert alert-danger");
                              scroll_now($("input[name='ans18']"));
                              e.preventDefault();
                              return;
                         } 
                         
                         if ($.trim($("input[name='exp18']").val())=='') {
                              $('#myModal .modal-title').text("UNANSWERED...");
                              $('#myModal .modal-body').text("State your reason on Question D No. 2");
                              $('#myModal').modal('show');
                              $(".exp18").addClass("alert alert-danger");
                              scroll_now($("input[name='exp18']"));
                              e.preventDefault();
                              return;
                         }
                         
                    });
               });
          </script>
     </head>
     <body>
          <div class="container">
               <div class="row">
                    <div class="col-md-12">
                         <h3 class="alert alert-success text-center">GIVE US YOUR FEEDBACK</h3>
                         <p class="text-danger">
<?php 
	if($err1<> ''){echo $err1.'<br>';}
	if($err2<>''){echo $err2.'<br>';}
	if($err3<>''){echo $err3.'<br>';}
	if($err4<>''){echo $err4.'<br>';}
	if($err5<>''){echo $err5.'<br>';}
	if($err6<>''){echo $err6.'<br>';}
	if($err7<>''){echo $err7.'<br>';}
	if($err8<>''){echo $err8.'<br>';}
	if($err9<>''){echo $err9.'<br>';}
	if($err10<>''){echo $err10.'<br>';}
	if($err11<>''){echo $err11.'<br>';}
	if($err12<>''){echo $err12.'<br>';}
	if($err13<>''){echo $err13.'<br>';}
     if($err14<>''){echo $err14.'<br>';}
     if($err15<>''){echo $err15.'<br>';}
     if($err16<>''){echo $err16.'<br>';}
     if($err17<>''){echo $err17.'<br>';}
     if($err18<>''){echo $err18;}
?></p></div></div>
		<?php 
		$stmt = $pdo->query("SELECT * FROM survey_instruction");
		foreach($stmt as $instruction){			
		?>
		<div class="row"><div class="col-md-12"><div style="margin-bottom:15px;"><form name="frmsurvey" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>"><h4 class="text-success"><?php echo $instruction['instruction']; ?></h4>
				<?php
				$stmt_q = $pdo->prepare("SELECT * FROM survey_question WHERE idsurvey_instruction=? ORDER BY idsurvey_question ASC;");
				$stmt_q->execute([$instruction['idsurvey_instruction']]);
				$item=0;
				foreach($stmt_q as $question) {
					$item++;
                         echo '<div class="question question'.$question['idsurvey_question'].'">';
					echo "<p class=\"text-primary\">$item. $question[question]<input type=\"hidden\" name=\"q$question[idsurvey_question]\" value=\"$question[idsurvey_question]\"></p>";
					if ($question['idsurvey_instruction']==1) {
						include('include/options.php');
					}elseif($question['idsurvey_instruction']==2) {
						include('include/options2.php');
					}elseif($question['idsurvey_instruction']==3) {
						include('include/options3.php');
					}elseif($question['idsurvey_instruction']==5) {
						include('include/options4.php');
					}
                         echo '</div>';
				}
				?>
		<?php } ?><div class="fixed-bottom text-center" style="background-color: lightgray; padding:5px 0px 5px 0px;"><button type="submit" class="btn btn-primary" name="submit" value="Submit">Submit</button></div></form></div></div></div><div id="myModal" class="modal fade" role="dialog"><div class="modal-dialog modal-sm"><div class="modal-content"><div class="modal-header"><h4 class="modal-title"></h4> <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span></button></div><div class="modal-body"></div><div class="modal-footer"> <button type="button" class="btn btn-default" data-dismiss="modal">Close</button></div></div></div></div></div></body></html>