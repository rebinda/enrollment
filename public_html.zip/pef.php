<?php
session_start();
include_once( "include/function.php" );

if ( !isset( $_SESSION[ 'is_login' ] ) ) {
	header( "Location: /" );
}
$idstudent = $_SESSION[ 'idstudent' ];
$idcourse = $_SESSION[ 'idcourse' ];
$yl = $_SESSION['yl'];

$idsem_settings = get_idsem_settings();
$isAsync = get_pef_status($idsem_settings,'is_sync_getting_subject');
$is_enable_same_subj = get_pef_status($idsem_settings,'is_enable_getting_same_subject');


if ( $_SERVER[ "REQUEST_METHOD" ] == "POST" ) {
	if (isset($_POST["action"])) {
		if(trim($_POST['action']) == "Edit") {
			$_SESSION['is_edit_profile'] = true;
			$_SESSION['view_edit'] = true;
			header("Location: reg.php");
		} 
          elseif(trim($_POST['action']) == "COR"){
               header("Location: cor.php");
          }
          elseif(trim($_POST['action']) == "Grades"){
               header("Location: sg.php");
          }
          else {
			header("Location: include/logout.php");
		}
	}
}
?>

<!doctype html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="fontawesome5.9.0/css/all.min.css" rel="stylesheet">
	<link href="bootstrap-4.3.1/css/bootstrap.min.css" rel="stylesheet">
     <link href="css/cb.css" rel="stylesheet">
     <link href="scrollbar/jquery.mCustomScrollbar.css" rel="stylesheet">
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="bootstrap-4.3.1/js/bootstrap.min.js"></script>
	<script src="js/devicedetector-min.js"></script>
     <script src="scrollbar/jquery.mCustomScrollbar.js"></script>
     <script src="scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>          
	<meta charset="utf-8">
	<title>Palawan State University PEF</title>
	<script>
		$( function () {
               $('#consent').modal('show');
               $("#chatbox .msg_sent").mCustomScrollbar();
		     $('[data-toggle="tooltip"]').tooltip();
		     $("#course, #yl, #semester").change( function () {
		          show_section();
		          show_sched();
		     });
		     $("#section").change( function () {
		          show_sched();
		     });
		     $("#show_sched").click( function () {
		          show_sched();                    
		     });                             
                              

			function show_sched() {
				$( "#show_sched" ).attr( "disabled", "true" );
				$( "#semester" ).prop( "disabled", true );
				$( "#course" ).prop( "disabled", true );
				$( "#yl" ).prop( "disabled", true );
				$( "#section" ).prop( "disabled", true );
                    
				$.ajax( {
					method: "POST",
					async: true,
					url: "include/get_sched.php",
					data: {
						idsection: $( "#section" ).val(),
						idsem_settings: $( "#semester" ).val(),
						idstudent: <?php echo $idstudent;?>
					},
					beforeSend: function () {
						$( "#show_sched" ).html( '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Loading...' );
						$( "#sched_block tbody tr" ).find( 'button' ).each( function () {
							$( this ).prop( 'disabled', true );
						} );
					},
					success: function (e) {                                                       
						$( "#sched_result" ).html( "" );
						$( "#sched_result" ).html( e );						
						merge_common_rows( "#sched_block tbody tr" );
                        add_click_handler();
						$( "#show_sched" ).removeAttr( "disabled" );
						$( "#show_sched" ).html( "GO!" );
						$( "#semester" ).prop( "disabled", false );
						$( "#course" ).prop( "disabled", false );
						$( "#yl" ).prop( "disabled", false );
						$( "#section" ).prop( "disabled", false );                             
					}
				});
			}

			function show_section() {
				$.ajax({
					method: "POST",
					async: false,
					url: "include/get_section.php",
					data: {
						idsem_settings: $( "#semester" ).val(),
						idcourse: $( "#course" ).val(),
						yl: $( "#yl" ).val()
					},
					success: function ( e ) {
						$( "#section option" ).remove();
						$( "#section" ).append( e );
					}
				} );
			}

			function add_click_handler() {                    
				$( "#sched_block td button" ).click( function () {                                                                                                    
					$( this ).attr( 'class', "btn btn-dark" );
					$( this ).attr( 'disabled', "true" );
                         var btn = $(this);		                        			                                                                        
					$.ajax({
						method: "POST",                                                           
						async: <?php if($isAsync == 0) {echo 'true';}
                                   else{echo 'false';}
                                   ?>,
                              dataType:"json",
						url: "include/new_sched.php",
						data: {
                                   idsched: $(this).parent().find("input[name=idsched]").val(),
							idsection: $("#section").val(),
							idsem_settings: $("#semester").val(),
							idcourse: $("#course").val(),
							idcurriculum: $(this).parent().find("input[name=idcurriculum]").val(),
							idstudent: <?php echo $idstudent;?>},
						beforeSend: function () {        
                                   
							btn.html( '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>' );							
							$("#sched_block button").attr( 'disabled', true );                                   							
						},                             
						success: function (e) {                                                                     
							$("#sched_block button" ).each(function() {
                                        if($(this).attr('class')!='btn btn-dark') {
                                             $(this).removeAttr("disabled"); }
                                   });
                                   btn.html('GET');
                                   
                                   if(e.type == 1) {
                                        btn.attr( 'class', "btn btn-success"); 
                                        btn.removeAttr("disabled");
                                        $('#msgbox .msgbox-title').html('SIZE LIMIT...'); 
                                        $("#msgbox_content").html(e.message); 
                                        $("#msgbox" ).modal("show");
                                      }
                                   else if (e.type == 2) {
                                        btn.attr( 'class', "btn btn-success"); 
                                        btn.removeAttr("disabled");
                                        $('#conflict .modal-title').html('SCHED CONFLICT');
                                        $("#conflict_sched").html(e.message);
                                        $('#conflict').modal('show');
                                   }
                                   totalsubj();
                              } 
                         }); 
                    });
               }                          
                                     
               $("#btn_send").click(function() {                         
                         /*if ($("#sched_result button[disabled=disabled]").length==0) { 
                              $("#conflict h5").html("QUEUE"); 
                              $("#conflict_sched").html('<span class="text-danger">SELECT 1 or more subjects.</span>'); 
                              $('#conflict').modal('show'); 
                              $(this).html('<i class="fas fa-inbox"></i>'); 
                              $(this).removeAttr("disabled"); 
                              return; 
                         }*/
                                   
                         var btn = $(this);                              
                         $.ajax({ 
                              method: "POST", 
                              async: true, 
                              url: "include/send_to_queue_approver.php", 
                              data: {idsem_settings: $( "#semester" ).val(), 
                                        idsection: $(this).parent().find("input[name=idsection]").val(),                                             
                                        idcourse: $("#course").val(), 
                                        idcurriculum: $(this).parent().find("input[name=idcurriculum]").val(),
                                     idstudent: <?php echo $idstudent;?> }, 
                              beforeSend: function () {                                    
                                   btn.html('<i class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></i> Submit'); 
                                   $("button").attr("disabled","true");
                                   btn.attr("disabled","true");                                   
                              }, 
                              success: function (e) { 
                                   btn.html('Submit'); 
                                   btn.removeAttr("disabled"); 
                                   $("button").removeAttr("disabled");
                                   $("#conflict h5").html("QUEUE"); 
                                   $("#conflict_sched").html(e); 
                                   $('#conflict').modal('show');
                              }
                         });                        
               }); 
                                   
               $("#btn_selected_subject").click(function () { 
                    $("#selected_subject").modal( "show" ); 
                    $.ajax({ method: "POST", 
                            async: false, 
                            url: "include/get_student_sched.php", 
                            data: {idsem_settings:$( "#semester" ).val(), 
                                   idstudent: <?php echo $idstudent;?> },
                         beforeSend: function() { 
                              $("#btn_selected_subject i").attr("class","spinner-border spinner-border-sm"); 
                              $("#stud_sched").html('<div class="text-center"><i class="spinner-border spinner-border-lg" role="status" aria-hidden="true"></i></div>'); 
                         },                              
                         success: function (e) {                               
                              $("#stud_sched").html(e); 
                              $('[data-toggle="tooltip"]').tooltip(); 
                              button_delete_handler(); 
                              merge_common_rows( "#pef tbody tr" ); 
                              $("#btn_selected_subject i").attr("class","fas fa-shopping-cart"); 
                         } 
                    });
               });
          
               function button_delete_handler() { 
                    $("#pef td button").click(function () {
                         
                         /*if($("#stud_sched button:not(:disabled)").length==1) {                               
                              $.ajax({ method: "POST", 
                                      async: false, 
                                      url: "include/delete_queue_for_approve.php", 
                                      data: { idsem_settings: $( "#semester" ).val(),                                              
                                             idstudent: <?php //echo $idstudent;?> } 
                              }); 
                         }*/
                                     
                         $(this).attr('class', "btn btn-dark"); 
                         $(this).attr('disabled', "true");                          
                         $.ajax({ method: "POST", 
                                 async: true, 
                                 url: "include/delete_student_sched.php", 
                                 data: { idsem_settings: $( "#semester" ).val(),
                                        source: $(this).parent().find("input[name=source]").val(),
                                        idcurriculum: $(this).parent().find("input[name=idcurriculum]").val(),
                                        idstudent: <?php echo $idstudent;?> }, 
                                        success: function (e) {
                                             show_sched();
                                             totalsubj();
                                        } 
                         }); 
                    }); 
               } 
                                                        
               function merge_common_rows(table) { 
                    var $prev_row = $(table).find("td"); 
                    var prev_idcurr = $prev_row.parent().find( "input[name=idcurriculum]" ).val(); 
                    var $row = $( table ).next().find( "td" ); 
                    var idcurr = $row.parent().find( "input[name=idcurriculum]" ).val(); 
                    var rowspan = 1;
                    
                    $(table).each(function() { 
                         var code = $row.eq(1).text(); 
                         var description = $row.eq(2).text(); 
                         var units = $row.eq(3).text(); 
                         var day = $row.eq(4).text();
                         var class_time = $row.eq(5).text(); 
                         var room = $row.eq(6).text(); 
                         var prev_code = $prev_row.eq(1).text(); 
                         var prev_description = $prev_row.eq(2).text(); 
                         var prev_units = $prev_row.eq(3).text(); 
                         var prev_day = $prev_row.eq(4).text();
                         var prev_class_time = $prev_row.eq(5).text(); 
                         var prev_room = $prev_row.eq(6).text(); 
                         
                         if (idcurr == prev_idcurr) { 
                              rowspan++; 
                              $row.eq(0).remove(); 
                              $prev_row.eq(0).attr('rowspan', rowspan); 
                              if (code == prev_code) { 
                                   $row.eq(1).remove(); 
                                   $prev_row.eq(1).attr('rowspan', rowspan); 
                              }
                              if (description == prev_description) { 
                                   $row.eq(2).remove(); 
                                   $prev_row.eq(2).attr('rowspan', rowspan);
                              } 
                              if (units == prev_units) { 
                                   $row.eq(3).remove(); 
                                   $prev_row.eq(3).attr('rowspan', rowspan);
                              }
                              if (day == prev_day) { 
                                   $row.eq(4).remove(); 
                                   $prev_row.eq(4).attr('rowspan', rowspan);
                              }
                              if (class_time == prev_class_time) { 
                                   $row.eq(5).remove();
                                   $prev_row.eq(5).attr('rowspan', rowspan);
                              } 
                              if (room == prev_room) { 
                                   $row.eq(6).remove(); 
                                   $prev_row.eq(6).attr('rowspan', rowspan); 
                              } 
                              $row = $row.parent().next().find( "td" ); 
                              idcurr = $row.parent().find("input[name=idcurriculum]").val(); 
                         } else { 
                              rowspan = 1; 
                              $prev_row = $row.parent().find("td"); 
                              $row = $row.parent().next().find("td"); 
                              prev_idcurr = $prev_row.parent().find("input[name=idcurriculum]").val(); 
                              idcurr = $row.parent().find("input[name=idcurriculum]").val(); 
                         } 
                    }); 
                    
                    fix_media_compatibility(); 
                    if (deviceDetector.isMobile) { 
                         if (deviceDetector.device == "phone") { 
                              bind_subject_details_click(table); 
                         } 
                    } 
               } 
               
               function fix_media_compatibility() {
                    if (deviceDetector.device == 'desktop') {} 
                    else {
                         $("table .title").hide(); 
                         $( "table .room" ).hide(); 
                         $("table .unit").hide();
                    }
               } 
               
               function bind_subject_details_click(table) {
                    $(table + " span.subj").css({"text-decoration": "underline","color": "#0000FF"}); 
                    $( table + " span.subj" ).click( function () { 
                         $.ajax({url: "include/get_subj_details.php", 
                                 async: true, 
                                 method: "POST", 
                                 data: { idsection: $("#section").val(), 
                                        idcurriculum: $(this).parent().parent().find("input[name=idcurriculum]").val()}, 
                                 success: function (e) {
                                      $('#sub_details_content').html("");
                                      $('#sub_details_content').html(e);
                                      merge_table_sub_details_content("#sub_details_content table tbody tr");
                                      $('#sub_details').modal('show');
                                 }
                                }); 
                    });
               } 
                                        
               function merge_table_sub_details_content(table) { 
                    var $prev_row = $(table).find("td"); 
                    var prev_idcurr = $prev_row.parent().find("input[name=idcurriculum]").val(); 
                    var $row = $(table).next().find("td"); 
                    var idcurr = $row.parent().find("input[name=idcurriculum]").val(); 
                    var rowspan = 1; 
                    $(table).each(function () { 
                         var description = $row.eq(0).text(); 
                         var units = $row.eq(1).text(); 
                         var room = $row.eq(2).text(); 
                         var prev_description = $prev_row.eq(0).text(); 
                         var prev_units = $prev_row.eq(1).text(); 
                         var prev_room = $prev_row.eq(2).text(); 
                         if (idcurr == prev_idcurr) { 
                              rowspan++; 
                              if (description == prev_description) { 
                                   $row.eq(0).remove(); 
                                   $prev_row.eq(0).attr('rowspan', rowspan); 
                              } if (units == prev_units) { 
                                   $row.eq(1).remove(); 
                                   $prev_row.eq(1).attr('rowspan', rowspan);
                              } if (room == prev_room) {
                                   $row.eq(2).remove(); 
                                   $prev_row.eq(2).attr('rowspan', rowspan); 
                              } 
                              $row = $row.parent().next().find("td"); 
                              idcurr = $row.parent().find("input[name=idcurriculum]").val(); 
                         } else { 
                              rowspan = 1; 
                              $prev_row = $row.parent().find("td"); 
                              $row = $row.parent().next().find("td"); 
                              prev_idcurr = $prev_row.parent().find("input[name=idcurriculum]").val(); 
                              idcurr = $row.parent().find("input[name=idcurriculum]").val(); 
                         }
                    });
               } 
                              
               $("#btn_queue").click(function (e) {
                    $.ajax({ method:"POST", 
                            url:"include/queue_stat.php", 
                            data:{idsem_settings: $("#semester").val(),                                  
                                  idstudent: <?php echo $idstudent; ?>, 
                                  idcourse: <?php echo $idcourse; ?> }, 
                            success: function(e) { 
                                 $('#msgbox .msgbox-title').html('QUEUE STATUS...'); 
                                 $("#msgbox_content").html(e); 
                                 $('#msgbox').modal('show'); 
                            }
                    });               
               });                                                                        
                                               
               function get_encoding_stat() { 
                              $.ajax({method:"POST", 
                                      url:"include/get_encoding_stat.php", 
                                      data:{idsem_settings: $("#semester").val(),                                             
                                            idstudent: <?php echo $idstudent; ?> },
                                        success: function (e) {											
                                             if (e == 0) {
												  $("#registration").attr("class","progress-bar bg-secondary"); 
												  $("#registration i").attr("class","far fa-times-circle"); 
												  $("#assessment").attr("class","progress-bar bg-secondary"); 
												  $("#assessment i").attr("class","far fa-times-circle"); 
												  $("#officially_encoded" ) . attr( "class", "progress-bar bg-secondary" );
												  $("#officially_encoded i" ) . attr( "class", "far fa-times-circle" );
											} else if (e == 1) {
												  $("#registration").attr("class","progress-bar bg-success"); 
												  $("#registration i").attr("class","far fa-times-circle"); 
                                                  $("#assessment") . attr("class", "progress-bar bg-success");
                                                  $("#assessment i") . attr( "class", "far fa-check-circle" );                                                  
                                                  $("#officially_encoded") . attr( "class", "progress-bar bg-secondary" );
                                                  $("#officially_encoded i") . attr( "class", "far fa-check-circle" );
                                             } else if (e == 2){
												  $("#registration").attr("class","progress-bar bg-success"); 
												  $("#registration i").attr("class","far fa-times-circle");
                                                  $("#assessment") . attr("class", "progress-bar bg-success");
                                                  $("#assessment i") . attr( "class", "far fa-check-circle" );                                                  
                                                  $("#officially_encoded") . attr( "class", "progress-bar bg-success" );
                                                  $("#officially_encoded i") . attr( "class", "far fa-check-circle" );
                                             }
                                        }
                              });
		     }
               
               function totalsubj() {
                    $.ajax({ method:"POST", 
                            async:true, 
                            url:"include/get_total_stud_subj.php",
                            data:{idsem_settings: $("#semester").val(),                                  
                                  idstudent: <?php echo $idstudent; ?>}, 
                              success: function(e) { 
                                   $("#total_subj").html(e); 
                              }
                    });                           
               }
		     function recurring() {		          
		          get_encoding_stat();								                            
                    get_message();                    
                    totalsubj();
		     }
		                                                                           
               
               function get_message() {
                    var scroll_position = $(".msg_sent").scrollTop();
                    $.ajax({
                         url: "include/get_messages_for_student.php",
                         async: true,
                         method: "POST",                             
                         data: {idstudent: <?php echo $idstudent ?>,
                              idsem_settings: $("#semester").val()                           
                         },
                         beforeSend: function() {                              
                         },
                         success: function(e) {
                              $(".msg_sent").html(e);
                              $(".msg_sent").scrollTop(scroll_position);
                         }
                    }); 
               }                              
                    
               $(".cancel").click(function() {
                    $("#chatbox").hide();
               });
               
               show_section(); 
               show_sched(); 
               recurring();
		     setInterval( recurring, 3000 );
		} );
</script>
<style>
     thead th {
          padding: 10px;
          color: white;
          background-color: dimgray;
     }
     
     #overlapping_sched span {
          padding: 5px;
     }
     
     .input-group {
          margin-bottom: 5px;
     }
     
     .jumbotron {
          padding: 30px 0 0px 0;
     }
     
     #table_queue_stat {
          border-collapse: collapse;
     }
     
     #table_queue_stat tr td.label_title {
          width: 100px;
     }
</style>
</head>
<body>
     <div class="jumbotron text-center">
          <h2>Palawan State University</h2>
          <p>PRE-ENROLLMENT</p>
             <nav class="navbar navbar-expand-md bg-dark navbar-dark">            
            <a class="navbar-brand" href="#"><?php echo get_student_name($idstudent); ?></a>
            
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
              <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
               <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <ul class="navbar-nav mr-auto">                        
                         <li class="nav-item">
                              <button class="btn btn-dark btn-link btn-block text-left" type="submit" name="action" value="Grades">Grade Inventory</button>
                         </li>
                         <li class="nav-item">
                              <button class="btn btn-dark btn-link btn-block text-left" type="submit" name="action" value="COR">COR</button>
                         </li>
                         <li class="nav-item">
                              <button class="btn btn-dark btn-link btn-block text-left" type="submit" name="action" value="Logout">Logout</button>
                         </li>                
                    </ul>                    
               </form>                 
            </div>
          </nav> 
          <div class="alert alert-info">
			<?php                     
                    $col_stat = array();
                    if(is_null(is_registration_inc('email',$idstudent))) {
                         array_push($col_stat,'<small class="badge badge-danger">Email Address</small>');
                    }
                    if(is_null(is_registration_inc('dob',$idstudent))) {
                         array_push($col_stat,'<small class="badge badge-danger">Birthdate</small>');                         
                    }
                    if(is_null(is_registration_inc('cp',$idstudent))) {
                         array_push($col_stat,'<small class="badge badge-danger">Cellphone Number</small>');
                    }
                    /*if(is_null(is_registration_inc('learning_mode',$idstudent))) {
                         array_push($col_stat,'<small class="badge badge-danger">Learnining Mode</small>');
                    }*/
                    
                    $col_res='';
                    for($i=0;$i<=count($col_stat)-1;$i++){
                         $col_res .= $col_stat[$i].' | ';
                    }
                    if (count($col_stat)>0) {
                         $col_res = substr($col_res, 0, -3);
                         echo "<p class=\"alert alert-danger\"><small>INCOMPLETE Registration:  </small>".$col_res." <small>Ignoring this message may cause us to encounter problems in processing your Pre-Enrollment. Fix this by <strong>Updating your Registration Now</strong>.</small></p><form action=".htmlspecialchars($_SERVER["PHP_SELF"])." method=\"post\"><button class=\"btn btn-danger\" type=\"submit\" name=\"action\" value=\"Edit\"><i class=\"far fa-edit\"></i> <small>UPDATE REGISTRATION NOW</small></button></form>";}
               ?></div></div><div class="container"><div class="row"><div class="col-md-3"><div class="input-group"><div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Semester"> <span class="input-group-text"> <i class="far fa-calendar-alt fa-fw"></i> </span></div><select id="semester" class="form-control">
						<?php
						$stmt = $pdo->query( "SELECT sem_settings.idsem_settings, 
		CONCAT(sy.s_year,'-',sy.e_year, ' ', UPPER(sem.sem)) AS sy_period 
		FROM sem_settings
		INNER JOIN sem USING(idsem) 
		INNER JOIN sy USING(idsy)
		WHERE sem_settings.is_open=1;" );

						foreach ( $stmt as $row ) {
							echo '<option value="' . $row[ 'idsem_settings' ] . '">' . $row[ 'sy_period' ] . '</option>';
						}
						?></select></div></div><div class="col-md-3"><div class="input-group"><div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Course"> <span class="input-group-text"> <i class="fas fa-route fa-fw"></i> </span></div><select id="course" class="form-control">
						<?php
						$stmt = $pdo->query("SELECT * FROM course ORDER BY course_name ASC;");

						foreach ( $stmt as $row ) {
							if ( $idcourse == $row[ 'idcourse' ] ) {
								echo '<option value="' . $row[ 'idcourse' ] . '" selected>' . $row[ 'course_name' ] . '</option>';
							} else {
								echo '<option value="' . $row[ 'idcourse' ] . '" >' . $row[ 'course_name' ] . '</option>';
							}

						}
						?></select></div></div><div class="col-md-2"><div class="input-group"><div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Year Level"> <span class="input-group-text"> <i class="fas fa-chart-line fa-fw"></i> </span></div><select id="yl" class="form-control"><option value="0" <?php if($yl==0){echo "selected";} ?>>1st YEAR</option><option value="1" <?php if($yl==1){echo "selected";} ?>>2nd YEAR</option><option value="2" <?php if($yl==2){echo "selected";} ?>>3rd YEAR</option><option value="3" <?php if($yl==3){echo "selected";} ?>>4th YEAR</option><option value="4" <?php if($yl==4){echo "selected";} ?>>5th YEAR</option></select></div></div><div class="col-md-2 section_container"><div class="input-group"><div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Section"> <span class="input-group-text"> <i class="fas fa-chart-pie fa-fw"></i> </span></div> <select id="section" class="form-control" disabled> </select></div></div><div class="col-md-2"><button type="button" class="btn btn-primary" id="show_sched">GO!</button></div></div>     
     <div class="row">
          <div class="col-md-12">
               <hr/>
               <div class="progress" style="height:30px">
                    <div id="registration" class="progress-bar bg-secondary" role="progressbar" style="width: 33.33%; height:30px;" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">
                         <i class="far fa-times-circle"></i>
                         <small>REGISTERED</small>
                    </div>                    
                    <div id="assessment" class="progress-bar bg-secondary" role="progressbar" style="width: 33.33%; height:30px;" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">
                         <i class="far fa-times-circle"></i>
                         <small>ASSESSMENT</small>
                    </div>
				   <div id="officially_encoded" class="progress-bar bg-secondary" role="progressbar" style="width: 33.33%; height:30px;" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">
                         <i class="far fa-times-circle"></i>
                         <small>FINISH</small>
                    </div>
               </div>
               <hr/>
          </div>
     </div>
     <div class="row">
          <div class="col-md-12" id="sched_result">
          </div>
     </div>
     <div class="fixed-bottom" style="background-color: lightgray;">
          <div class="text-center" style="padding:5px 0px 5px 0px;">
               <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">                    
                    <button type="button" id="btn_selected_subject" class="btn btn-sm btn-success" value="View Subjects" data-placement="top" data-toggle="tooltip" title="View Subjects">
                         View
                         <small id="total_subj" class="badge badge-danger" style="position:absolute; top=0;"></small>
                    </button>                     
                    
                    <button type="button" id="btn_send" class="btn btn-sm btn-info" value="send" data-placement="top" data-toggle="tooltip" title="Submit">
                         Submit
                    </button>                    
               </form>
          </div>
     </div>
<div class="modal fade" id="selected_subject" tabindex="-1" role="dialog" aria-labelledby="selected_subject" aria-hidden="true">
     <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
          <div class="modal-content">
               <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">PEF SUBJECTS</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
               </div>
               <div class="modal-body">
                    <div id="stud_sched"></div>
               </div>
               <div class="modal-footer"> <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
               </div>
          </div>
     </div>
</div>
<div class="modal fade" id="conflict" tabindex="-1" role="dialog" aria-labelledby="conflict" aria-hidden="true">
     <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
          <div class="modal-content">
               <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">CONFLICT</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
               </div>
               <div class="modal-body">
                    <div id="conflict_sched"></div>
               </div>
               <div class="modal-footer"> <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
               </div>
          </div>
     </div>
</div>
<div class="modal fade" id="sub_details" tabindex="-1" role="dialog" aria-labelledby="sub_details" aria-hidden="true">
     <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
               <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">DETAILS</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
               </div>
               <div class="modal-body">
                    <div id="sub_details_content"></div>
               </div>
               <div class="modal-footer"> <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
               </div>
          </div>
     </div>
</div>
<div class="modal fade" id="msgbox" tabindex="-1" role="dialog" aria-labelledby="msgbox" aria-hidden="true">
     <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
          <div class="modal-content">
               <div class="modal-header">
                    <h5 class="msgbox-title" id="exampleModalLabel">SIZE LIMIT...</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
               </div>
               <div class="modal-body">
                    <div id="msgbox_content"></div>
               </div>
               <div class="modal-footer"> <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
               </div>
          </div>
     </div>
</div>
<div class="modal fade" id="consent" tabindex="-1" role="dialog" aria-labelledby="consent" aria-hidden="true">
     <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
          <div class="modal-content">
               <div class="modal-header">
                    <h5 class="consent-title" id="exampleModalLabel">DATA PRIVACY CONSENT FORM</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
               </div>
               <div class="modal-body">
                    <div id="consent_content">
                         <p>By agreeing to this consent form, I grant my free, voluntary and unconditional consent to the collection and processing of all personal and sensitive data, as well as accounts or transaction information or records relating to me, which was disclosed/transmitted by me in person to the information database system of the Palawan State University (PSU) by whatever lawful means in accordance with Republic Act (R.A.) 10173, otherwise known as the “Data Privacy Act of 2012” of the Republic of the Philippines, including its Implementing Rules and Regulations (IRR) as well as all other guidelines and issuances by the National Privacy Commission (NPC). </p>
                              <p>I understand that my “personal data” means any information, whether recorded in a material form or not, (a) from which the identity of an individual is apparent or can be reasonably and directly ascertained by the entity holding the information, or when put together with other information would directly and certainly identify an individual, (b) about an individual’s race, ethnic origin, marital status, age, color, gender, health, education (including academic performance) and religious and/or political affiliations, (c) referring to any proceeding for any offense committed or alleged to have been committed by such individual, the disposal of such proceedings, or the sentence of any court in such proceedings, and (d) issued by government agencies peculiar to an individual which includes, but not limited to, social security numbers and licenses.</p>
                              <p>I understand, further, that PSU shall keep the personal and sensitive data and Information that I provide with PSU in strict confidence, and that the collection and processing of all such data and/or Information by PSU may be used for educational purposes only, pursuant to the relevant provisions of RA 10173.</p>
                    </div>
               </div>
               <div class="modal-footer"> <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
               </div>
          </div>
     </div>
</div>
<div id="chatbox">
     <form name="frmchat" method="post">
          <div data-mcs-theme="dark" class="mCustomScrollbar msg_sent"></div>
          <button type="button" class="btn btn-sm btn-danger cancel">CLOSE</button>
     </form>
</div>
</div>
</body>
</html>