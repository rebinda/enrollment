<?php
session_start();
include_once("include/connect.php");
if (!isset($_SESSION['is_faculty_login'])) {
      header("Location: pef/");
}
if (isset($_SESSION['role'])) {
     if ($_SESSION['role']<> 2) {
          header("Location: pef/");
     }
}

if ( $_SERVER[ "REQUEST_METHOD" ] == "POST" ) {
	if ( isset( $_POST[ "action" ] ) ) {
		if ( $_POST[ 'action' ] == "Back" ) {
			header( "Location: advising.php" );		
		}
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="fontawesome5.9.0/css/all.min.css" rel="stylesheet">
<link href="bootstrap-4.3.1/css/bootstrap.min.css" rel="stylesheet">
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="bootstrap-4.3.1/js/bootstrap.min.js"></script>
<title>PSU Computer Studies Department PEF</title>
     <script>
          $(function() {
               var isedit = 0;
               var idcourse=0;
               var update_source='';
               var del_source='';
               $('[data-toggle="tooltip"]').tooltip();
               
               $("#find").keydown(function(e) {
                    if (e.which==13) {$("#btnfind").click();}
               });
                    
               $("#course").change(function() {
                    all_student();
               });
               
               $("#btnyes").click(function(e) {
                    $.ajax({
                         url: 'include/del_stud.php',
                         method:"POST",
                         data:{idstudent: del_source.parent().find("input[name=idstudent]").val()},
                         success: function(e) {
                              $("#course").change();
                              show_search_result();
                              $("#confirm_dialog").modal('hide');
                         }
                    });
               });
               
               $("#new").click(function() {
                    isedit=0;
                    $("#myModal select[name='sel_course']").val($("#course").val());
                    $("#lname").val('');
                    $("#fname").val('');
                    $("#idnumber").val('');
                    $("#dob").val('');
                    $("#myModal").modal("show");
                    $("#myModal .modal-title").html("New Student");
               });
                             
               $("#btnSave").click(function(e) {                    
                    var btn = $(this);
                    $.ajax({
                         url:"include/new_stud.php",
                         method:"POST",
                         dataType:"JSON",
                         data: {lname: $("#lname").val(),
                                   is_editting: isedit,
                                   fname: $("#fname").val(),
                                   idcourse:$("#sel_course").val(),
                                   idnumber: $("#idnumber").val(),
                                   dob: $("#dob").val()},
                         beforeSend: function(e) {
                              btn.html('<i class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></i> Save');
                         },
                         success: function(e) {
                              alert(e.message);
                              btn.html('Save');
                              if (e.value == 0) {                                   
                                   $("#msgbox_content").html(e.message);
                                   $("#msgbox").modal('show');
                              }
                              else {
                                   $("#lname").val('');
                                   $("#fname").val('');
                                   $("#idnumber").val('');
                                   $("#dob").val('');                              
                              }                              
                              if(isedit==1) {
                                   $("#myModal").modal('hide');
                              }
                              if (update_source=='#content') {
                                   $("#course").change();
                              }else if(update_source=='#seek_result') {
                                   show_search_result();
                              }
                         }                          
                    });
               });
               
               function bind_edit(container) {                    
                    $(container+" button[name=edit]").click(function() {
                         update_source = container;
                         isedit = 1;                         
                         $("#myModal .modal-title").html("EDITING...");                         
                         $("#myModal select[name='sel_course']").val($(this).parent().find("input[name=idcourse]").val());
                         $("#myModal input[name='lname']").val($(this).parent().find("input[name=lname]").val());
                         $("#myModal input[name='fname']").val($(this).parent().find("input[name=fname]").val());
                         $("#myModal input[name='dob']").val($(this).parent().find("input[name=dob]").val());
                         $("#myModal input[name='idnumber']").val($(this).parent().find("input[name=idnumber]").val());                         
                         $("#myModal").modal("show");
                    });                 
               }
               
               function bind_delete(container) {                    
                    $(container+" button[name=delete]").click(function() {
                         del_source = $(this);                                                  
                         $("#confirm_dialog .modal-title").html("DELETING...");                         
                         $("#confirm_dialog").modal("show");
                    });                 
               }
               
               function show_search_result() {                    
                    $.ajax({
                       url: "include/seek_student.php",
                       data: {qry: $("#find").val()},
                       method:"POST",
                       beforeSend: function(e) {
                            $("#seek_result").html('<div class="text-center"><i class="spinner-border spinner-border-lg" role="status" aria-hidden="true"></i></div>');
                       },
                       success: function(e) {
                            $("#seek_result").html(e);
                            bind_edit("#seek_result");
                            bind_delete("#seek_result");
                            $("#seek .modal-title").html(+$("#seek_result table tbody tr").length+" ROW(S) FOUND");
                       }
                  });
               }
               
               $("#btnfind").click(function() { 
                    $("#seek .modal-title").html("0 ROW(S) FOUND");
                    $("#seek").modal("show");
                    show_search_result();               
               });
               
               function all_student() {
                  $.ajax({
                       url: "include/show_students.php",
                       data: {idcourse:$("#course").val()},
                       method:"POST",
                       beforeSend: function(e) {
                            $("#content").html('<div class="text-center"><i class="spinner-border spinner-border-lg" role="status" aria-hidden="true"></i></div>');
                       },
                       success: function(e) {
                            $("#content").html(e);
                            bind_edit("#content");
                            bind_delete("#content");
                       }
                  });
               }
          });
     </script>
     <style>
          #content {
               height: 50vh;
               overflow-y: scroll;
          }
          .input-group {
               margin-bottom: 5px;
          }
          #content thead th {
               padding: 10px;
               color: white;
               background-color: dimgray;
          }         
          #content tbody tr:nth-child(even) {               
               background-color:#C5C5C5;
          }
          #search_result thead th{
               padding: 10px;
               color: white;
               background-color: dimgray;
          }
          
          #seek_result {
               height: 50vh;
               overflow-y: scroll;
          }
     </style>
</head>

<body>
     <h2 class="jumbotron text-center alert-info" style="height:100px; padding: 30px 0 30px 0;">STUDENTS</h2>
     <div class="container">
          <div class="row">
               <div class="col-md-6">
                    <div class="input-group">
                         <div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Course"> 
                              <span class="input-group-text"> 
                                   <i class="fas fa-route fa-fw"></i> 
                              </span>
                         </div>
                         <select id="course" class="form-control">
						<?php
						$stmt = $pdo->query("SELECT * FROM course ORDER BY course_name ASC;");

						foreach ( $stmt as $row ) {
							if ( $idcourse == $row[ 'idcourse' ] ) {
								echo '<option value="' . $row[ 'idcourse' ] . '" selected>' . $row[ 'course_name' ] . '</option>';
							} else {
								echo '<option value="' . $row[ 'idcourse' ] . '" >' . $row[ 'course_name' ] . '</option>';
							}

						}
						?></select>
                    </div>
               </div>
               <div class="col-md-3">
				<div class="input-group"><input class="form-control" type="text" name="find" id="find" placeholder="ID Number/Lastname">
					<div class="input-group-append"><button class="btn btn-primary" id="btnfind"><i class="fas fa-search fa-fw"></i></button>
					</div>
				</div>
			</div>
               <div class="col-md-3">
                    <button type="button" class="btn btn-success" id="new">NEW</button>                    
               </div>
          </div>
          <div class="row">
			<div class="col-md-12">
				<hr>
			</div>
		</div>
          <div class="row">
			<div class="col-md-12">
				<div id="content"></div>
			</div>
		</div>
     </div>
     <div class="fixed-bottom" style="background-color: lightgray;">
          <div class="text-center" style="padding:5px 0px 5px 0px;">
               <form id="form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <button class="btn btn-success" type="submit" name="action" value="Back"><i class="fas fa-arrow-left"></i> Back</button>					
               </form>
          </div>
     </div>
     
     <div class="modal fade" id="seek">
          <div class="modal-dialog">
               <div class="modal-content">      
                    <div class="modal-header">
                         <h4 class="modal-title">Heading</h4>
                         <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                         <div id="seek_result"></div>
                    </div>
                    <div class="modal-footer">
                         <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>                         
                    </div>
               </div>
          </div>
     </div>
     
     <div class="modal fade" id="myModal">
          <div class="modal-dialog">
               <div class="modal-content">      
                    <div class="modal-header">
                         <h4 class="modal-title">Heading</h4>
                         <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                         <div class="form-group">
                              <div class="input-group">
                                   <div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Course"> 
                                        <span class="input-group-text"> 
                                             <i class="fas fa-route fa-fw"></i> 
                                        </span>
                                   </div>
                                   <select id="sel_course" name="sel_course" class="form-control">
                                        <?php
                                        $stmt = $pdo->query("SELECT * FROM course ORDER BY course_name ASC;");

                                        foreach ( $stmt as $row ) {
                                             if ( $idcourse == $row[ 'idcourse' ] ) {
                                                  echo '<option value="' . $row[ 'idcourse' ] . '" selected>' . $row[ 'course_name' ] . '</option>';
                                             } else {
                                                  echo '<option value="' . $row[ 'idcourse' ] . '" >' . $row[ 'course_name' ] . '</option>';
                                             }

                                        }
                                        ?></select>
                              </div>
                         </div>
                         <div class="form-group">						
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Lastname"><span class="input-group-text"><i class="fas fa-align-left fa-fw"></i></span>
							</div><input type="text" class="form-control" id="lname" name="lname" placeholder="Lastname" value="" maxlength="30">
						</div>
					</div>
                         <div class="form-group">						
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Firstname"> <span class="input-group-text"> <i class="fas fa-align-right fa-fw"></i> </span>
							</div> <input type="text" class="form-control" id="fname" name="fname" placeholder="Firstname" value="">
						</div>
					</div>
                         <div class="form-group">						
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="ID Number"> <span class="input-group-text"> <i class="far fa-id-card fa-fw"></i> </span>
							</div> <input type="text" class="form-control" id="idnumber" name="idnumber" placeholder="ID Number" value="">
						</div>
					</div>
                         <div class="form-group">						
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Birthdate"> <span class="input-group-text"> <i class="far fa-calendar-alt fa-fw"></i> </span>
							</div> <input type="date" name="dob" id="dob" placeholder="mm/dd/yyyy" class="form-control" value="">
						</div>
					</div>
                    </div>
                    <div class="modal-footer">
                         <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                         <button type="button" class="btn btn-success" id="btnSave">Save</button>
                    </div>
               </div>
          </div>
     </div>
     <div class="modal fade" id="msgbox" tabindex="-1" role="dialog" aria-labelledby="msgbox" aria-hidden="true">
			<div class="modal-dialog modal-sm modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="msgbox_title">PEF</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
					</div>
					<div class="modal-body">
						<div id="msgbox_content"></div>
					</div>
					<div class="modal-footer">                               
                              <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>
     <div class="modal fade" id="confirm_dialog" tabindex="-1" role="dialog" aria-labelledby="msgbox" aria-hidden="true">
			<div class="modal-dialog modal-sm modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="msgbox_title">PEF</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
					</div>
					<div class="modal-body">
						<div id="confirm_dialog_content">Are you sure?</div>
					</div>
					<div class="modal-footer">                               
                              <button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
                              <button type="button" id="btnyes" class="btn btn-success">Yes</button>
					</div>
				</div>
			</div>
		</div>
</body>
</html>