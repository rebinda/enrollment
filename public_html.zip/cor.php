

<?php
     include_once("include/connect.php");
     require './vendor/autoload.php';
     use \Dompdf\Dompdf;
     session_start();

	if ( !isset( $_SESSION[ 'is_login' ] ) ) {
		header( "Location: /" );
	}
     $idstudent = $_SESSION['idstudent'];
     
     
     $qry = "SELECT student_sched.idstudent, 
                                            student.idnumber,
                                            CONCAT(student.fname, ' ',IFNULL(student.mname,''), ' ',student.lname) AS name, 
                                            course.course_name, 
                                            tmp.code1, 
                                            curriculum.description, 
                                            GROUP_CONCAT(CONCAT(CASE tmp.days 
                                            WHEN 0 THEN 'M' 
                                            WHEN 1 THEN 'T' 
                                            WHEN 2 THEN 'W' 
                                            WHEN 3 THEN 'TH' 
                                            WHEN 4 THEN 'F' 
                                            WHEN 5 THEN 'SA'
                                            WHEN 6 THEN 'S' END,' ',TIME_FORMAT(tmp.s_time, '%h:%i %p'),'-',TIME_FORMAT(tmp.e_time, '%h:%i %p'),' ',room.room) separator '\r\n') AS class_time_and_room, 
                                            curriculum.lec_unit,
                                            curriculum.lab_unit, 
                                            section.section_name, 
                                            room.room, 
                                            UPPER(CONCAT(faculty.lname, ', ',faculty.fname)) AS faculty 
                                FROM 
                                    (SELECT sched.idsched, 
                                        get_course_code(sched.idsched) AS code1,
                                        section.idsem_settings, 
                                        sched.days, 
                                        sched.idcurriculum, 
                                        sched.idroom, 
                                        sched.idsection, 
                                        sched.idfaculty, 
                                        sched.s_time, 
                                        sched.e_time 
                                    FROM sched 
                                    INNER JOIN section ON sched.idsection = section.idsection 
                                    WHERE section.idsem_settings =14) AS tmp 
                                    INNER JOIN curriculum USING(idcurriculum) 
                                    INNER JOIN room USING(idroom) 
                                    INNER JOIN section USING(idsection) 
                                    INNER JOIN student_sched 
                                    ON tmp.idsched = student_sched.idsched 
                                    AND tmp.idsem_settings = student_sched.idsem_settings 
                                    INNER JOIN student 
                                    ON student_sched.idstudent = student.idstudent 
                                    INNER JOIN course 
                                    ON student.idcourse = course.idcourse 
                                    LEFT JOIN faculty USING(idfaculty) 
                                    WHERE student_sched.idstudent = ? 
                                    GROUP BY curriculum.idcurriculum, student.idstudent 
                                    ORDER BY student.idstudent ASC, curriculum.idcurriculum ASC, student_sched.idsched ASC" ;
                                    
                                    $stmt = $pdo->prepare($qry);
                                    $stmt->execute([$idstudent]);
                                    
                                    
                                    $st = "select student.idnumber, CONCAT(student.lname, ', ',student.fname) as SN, student.sex AS gender, curriculum_name.name AS curriculum_name, CASE student.yl WHEN 0 THEN '1ST' WHEN 1 THEN '2ND' WHEN 2 THEN '3RD' WHEN 3 THEN '4TH' WHEN 4 THEN '5TH' END AS yl, FLOOR(datediff(date(now()),student.dob)/356) AS bdate, course.course_name AS program, college.college_name AS college from student INNER JOIN course ON student.idcourse = course.idcourse INNER JOIN dept ON course.iddept = course.iddept INNER JOIN college ON dept.idcollege = college.idcollege INNER JOIN curriculum_name ON student.idcurriculum_name = curriculum_name.idcurriculum_name WHERE student.idstudent = ? GROUP BY student.idstudent";
                                    
                                    $stud = $pdo->prepare($st);
                                    $stud->execute([$idstudent]);
                                    
                                   $sem = $pdo->query( "SELECT sem_settings.idsem_settings, CONCAT(sy.s_year,'-',sy.e_year, ' ', UPPER(sem.sem)) AS sy_period FROM sem_settings	INNER JOIN sem USING(idsem) INNER JOIN sy USING(idsy) WHERE sem_settings.is_open=1;");
                                   
                                   
                                    foreach($sem as $s){
                                    $query = "select * from assessment where idstudent = ? and idsem_settings = ?";
                                    
                                    $assess = $pdo->prepare($query);
                                    $assess->execute([$idstudent,$s['idsem_settings']]);
                            
                                    }
                                    

                            
                                    
                                    
                                    
                                    
                foreach($stmt as $q) {

                              $find = array();
                              $repl = array();
                         
                              $find[] = '%STUDENTNUMBER%';
                              $repl[] = $q['idnumber'];
                              
                              $find[] = '%NAME%';
                              $repl[] = $q['name'];
                              
                              foreach($stud as $s){
                                  //student info
                                  
                                      $find[] = '%GENDER%';
                                      $repl[] = $s['gender'];
                                      
                                      date_default_timezone_set('Asia/Manila');
                                      $date = date('Y/m/d', time());
                                      
                                      
                                      
                                      $find[] = '%AGE%';
                                      $repl[] = $s['bdate'];
                                      
                                      $find[] = '%COLLEGE%';
                                      $repl[] = $s['college'];
                                      
                                      $find[] = '%PROGRAM%';
                                      $repl[] = $s['program'];   
                                      
                                      $find[] = '%MAJOR%';
                                      $repl[] = '';
                                      
                                      $find[] = '%YEARLEVEL%';
                                      $repl[] = $s['yl']; 
                                      
                                       foreach($sem as $sem){
                                          $find[] = '%SCHOOLYEAR%';
                                          $repl[] = $sem['sy_period'];
                                       }
                                          
                                      $find[] = '%CURRICULUM%';
                                      $repl[] = $s['curriculum_name'];
                                      
                                      $find[] = '%SCHOLARSHIP%';
                                      $repl[] = '';
                                      
                              }
                              
                              
                              
                         $count=1;
                         $credit=$q['lec_unit']+$q['lab_unit'];
                              $find[] = '%TABLE'.$count.'%';
                              $repl[] ='<tr><td>'.$q['code1'].'</td><td>'.$q['description'].'</td><td style="text-align:center">'.$q['lec_unit'].'</td><td style="text-align:center">'.$q['lab_unit'].'</td><td style="text-align:center">'.$q['lec_unit']+$q['lab_unit'].'</td><td>'.$q['section_name'].'</td><td>'.$q['class_time_and_room'].'</td><td>'.$q['faculty'].'</td></tr>';
                              $totallec+=$q['lec_unit'];
                              $totallab+=$q['lab_unit'];
                         
                             foreach($stmt as $r){
                        $count++;
                        
                              $find[] = '%TABLE'.$count.'%';
                              $repl[] ='<tr><td>'.$r['code1'].'</td><td>'.$r['description'].'</td><td style="text-align:center">'.$r['lec_unit'].'</td><td style="text-align:center">'.$r['lab_unit'].'</td><td style="text-align:center">'.$r['lec_unit']+$r['lab_unit'].'</td><td>'.$r['section_name'].'</td><td>'.$r['class_time_and_room'].'</td><td>'.$r['faculty'].'</td></tr>';
                              $credit+=$r['lec_unit']+$r['lab_unit'];
                              $totallec+=$r['lec_unit'];
                              $totallab+=$r['lab_unit'];
                             }
                             
                             $i=1;
                             $total=0;
                        foreach($assess as $a) {
                         $find[] = '%ASSESS'.$i.'%';
                         $repl[] = '<tr><td style="text-align: left;">'.$a['account_name'].'</td><td></td><td></td><td style="text-align: right;">'.$a['amount'].'</td></tr>';
                         $i++;
                         
                        $total+=$a['amount'];
                        }
                                  
      
                              $find[] = '%TOTALLEC%';
                              $repl[] = $totallec;
                         
                              $find[] = '%TOTALLAB%';
                              $repl[] = $totallab;
                                                    
                              $find[] = '%TOTALCREDIT%';
                              $repl[] = $credit;
                              
                              
                              
                              $find[] = '%TOTALASSESSMENT%';
                              $repl[] = number_format((float)$total, 2, '.', '');
                              
                              $find[] = '%TOTALPAYMENT%';
                              $repl[] = number_format((float)$payment, 2, '.', '');
                              
                              $find[] = '%OUTSTANDINGBALANCE%';
                              $repl[] = number_format((float)$total-$payment, 2, '.', '');
                         
                         $paymentdetails=$total/3;
                         
                         $find[] = '%PAYMENTA%';
                         $repl[] = number_format((float)$paymentdetails, 2, '.', '');
                         
                         $find[] = '%PAYMENTB%';
                         $repl[] = number_format((float)$paymentdetails, 2, '.', '');
                         
                         $find[] = '%PAYMENTC%';
                            $repl[] = number_format($total-(float)$paymentdetails*2, 2, '.', '');
                         

                        
                        if(date('N', strtotime($date. ' +40 days'))==6){
                         $find[] = '%DUEDATEA%';
                         $repl[] = date('Y/m/d', strtotime($date. ' + 42 days')); 
                        }elseif(date('N', strtotime($date. ' +40 days'))==7){
                         $find[] = '%DUEDATEA%';
                         $repl[] = date('Y/m/d', strtotime($date. ' + 41 days'));
                        }else{
                         $find[] = '%DUEDATEA%';
                         $repl[] = date('Y/m/d', strtotime($date. ' + 40 days'));
                        }
                        
                        if(date('N', strtotime($date. ' +80 days'))==6){
                         $find[] = '%DUEDATEB%';
                         $repl[] = date('Y/m/d', strtotime($date. ' + 82 days')); 
                        }elseif(date('N', strtotime($date. ' +80 days'))==7){
                         $find[] = '%DUEDATEB%';
                         $repl[] = date('Y/m/d', strtotime($date. ' + 81 days'));
                        }else{
                         $find[] = '%DUEDATEB%';
                         $repl[] = date('Y/m/d', strtotime($date. ' + 80 days'));
                        }
                        
                        
                        if(date('N', strtotime($date. ' +120 days'))==6){
                         $find[] = '%DUEDATEC%';
                         $repl[] = date('Y/m/d', strtotime($date. ' + 122 days')); 
                        }elseif(date('N', strtotime($date. ' +120 days'))==7){
                         $find[] = '%DUEDATEC%';
                         $repl[] = date('Y/m/d', strtotime($date. ' + 121 days'));
                        }else{
                         $find[] = '%DUEDATEC%';
                         $repl[] = date('Y/m/d', strtotime($date. ' + 120 days'));
                        }
                        
                        
                        
                        
                        $find[] = '%OFFICIALRECEIPT%';
                        $repl[] = '';
                        
                        $find[] = '%PAYMENTDATE%';
                        $repl[] = '';
                        
                        
                        $find[] = '%APPROVAL%';
                        $repl[] = 'signature';
                        
                        $find[] = '%TODAY%';
                        $repl[] = $date = date('Y/m/d h:i:s a', time());
                        
                        

                         
                              $template = file_get_contents('COR.txt');
                                        $pdf = str_replace($find,$repl,$template);
                         
                         
                                        $dompdf = new DOMPDF();
                                        $dompdf->load_html($pdf);
                                        $dompdf->set_option('isRemoteEnabled',true);
                                        $dompdf->set_paper('A4','A4');
                                        $dompdf->render();
                         
                                        $dompdf->stream("COR.pdf", array("Attachment" => false));
                                        $dompdf->output();
                         
                         
                                        file_put_contents($path,$file);
                }                      
                                        

						?>