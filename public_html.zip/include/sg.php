<?php
include_once("function.php");
session_start();
$idstudent = $_SESSION[ 'idstudent' ];
$idcourse = $_POST['idcourse'];



$grade = $pdo->prepare("SELECT CONCAT(sy.s_year,'-',sy.e_year) AS sy,
                            CONCAT(CASE curriculum.yl
                            WHEN 0 THEN '1st YEAR'
                            WHEN 1 THEN '2nd YEAR' 
                            WHEN 2 THEN '3rd YEAR' 
                            WHEN 3 THEN '4th YEAR' 
                            WHEN 4 THEN '5th YEAR' 
                            END, ' - ', sem.sem) AS sem_yl,                         
                            curriculum.code,
                            curriculum.description,
                            IF(curriculum.lab_unit=0, curriculum.lec_unit, CONCAT( curriculum.lec_unit,'/',curriculum.lab_unit)) AS unit,                           
                            student_grades.tmg,
                            student_grades.tfg,
							student_grades.re_exam,
							sched.isposted
                        FROM
                            student
                        INNER JOIN 
                            student_sched on student.idstudent = student_sched.idstudent
                        INNER JOIN
                            sched on student_sched.idsched = sched.idsched
                        INNER JOIN	
                            curriculum ON sched.idcurriculum = curriculum.idcurriculum
                        INNER JOIN 
                            sem ON curriculum.idsem = sem.idsem
						INNER JOIN
							sem_settings ON student_sched.idsem_settings = sem_settings.idsem_settings
						INNER JOIN
							sy ON sem_settings.idsy = sy.idsy
                        LEFT JOIN 
                            student_grades 
                        ON curriculum.idcurriculum = student_grades.idcurriculum 
                        AND student_sched.idstudent = student_grades.idstudent
                        AND student_sched.idsem_settings = student_grades.idsem_settings
                        AND student_sched.idsection = student_grades.idsection
                        WHERE student.idstudent = ?
						AND student.idcourse = ? 
                        GROUP BY student_sched.idsection, curriculum.idcurriculum
                        ORDER BY  curriculum.yl ASC, sem.idsem ASC, curriculum.idcurriculum ASC;");

$grade->execute([$idstudent, $idcourse]);

?>

<table class="table-bordered" width="100%" id="sched_block" style="margin-bottom: 80px;">
	<thead>	
        <th>SEMESTER</th>	
		<th>CODE</th>
		<th>TITLE</th>
		<th>UNIT</th>
		<th>MG</th>
		<th>FG</th>
		<th>RE-EXAM</th>
	</thead>
	<tbody>		
		<?php		
		foreach ($grade as $row) {                
		?>
			<tr>
			<td align="center"><?php echo $row['sy'].'<br>'; echo $row['sem_yl'];?></td>
			<td><?php echo $row['code']; ?></td>					
			<td><?php echo $row['description']; ?></td>
			<td class="text-center"><?php echo $row['unit']; ?></td>			
			<td class="text-right 
                <?php 
                    if ($row['tmg']=='5') {
                        echo "text-danger";
                    }else if($row['tmg']=='INC' || $row['tmg']== '4' || $row['tmg']=='NC' || $row['tmg']=='UD' || $row['tmg']=='OD' || $row['tmg']=='W') {
                        echo "text-warning";
                    }else if (is_null($row['tmg'])) {
                        
                    }else {
                        echo "text-success";
                    }
                ?>
                "><strong>
                        <?php 
                            echo $row['tmg']; 
                        ?>
                    </strong>
            </td>
			<td class="text-right <?php 
                    if ($row['tfg']=='5') {
                        echo "text-danger";
                    }else if($row['tfg']=='INC' || $row['tfg']== '4' || $row['tfg']=='NC' || $row['tfg']=='UD' || $row['tfg']=='OD' || $row['tfg']=='W') {
                        echo "text-warning";
                    }else if (is_null($row['tfg'])) {
                        
                    }else {
                        echo "text-success";
                    }
                ?>
                "><strong>
                        <?php 
                            echo $row['tfg'];
                            if (!is_null($row["tfg"]) && $row["isposted"] == 0) {echo "*";} 
                        ?>
                    </strong>
            </td>
			<td class="text-right <?php 
                    if ($row['re_exam']=='5') {
                        echo "text-danger";
                    }else if($row['re_exam']=='INC' || $row['re_exam']== '4' || $row['re_exam']=='NC' || $row['re_exam']=='UD' || $row['re_exam']=='OD' || $row['re_exam']=='W') {
                        echo "text-warning";
                    }else if (is_null($row['re_exam'])) {
                        
                    }else {
                        echo "text-success";
                    }
                ?>
                "><strong>
                        <?php 
                            echo $row['re_exam'];
                            if (!is_null($row["re_exam"]) && $row["isposted"] == 0) {echo "*";} 
                        ?>
                    </strong>
            </td>	
			</tr>
		<?php
		}
		?>					
	</tbody>
</table>