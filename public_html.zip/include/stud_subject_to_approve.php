<?php
     include_once("function.php");
     session_start();
     if (!isset($_SESSION['is_faculty_login'])) {die("<div class=\"alert alert-danger\"><i class=\"fas fa-exclamation\" style=\"font-size:24px;\"></i> <strong> YOU NEED TO LOGIN!</strong></div>");}

     $idfaculty = $_SESSION['idfaculty'];
     $idstudent = get_idstudent($_POST['idstudent']);
     $idsem_settings = $_POST['idsem_settings'];
     //$approver = $_POST['approver'];
     
     $qry = "SELECT student.idnumber, student.idstudent, UPPER(CONCAT(student.lname, ', ', student.fname)) AS name,
                    CASE student.yl 
                         WHEN 0 THEN '1ST YR'
                         WHEN 1 THEN '2ND YR'
                         WHEN 2 THEN '3RD YR'
                         WHEN 3 THEN '4TH YR'
                         WHEN 4 THEN '5TH YR' END AS yl,
                         queue_to_approve.idqueue_to_approve
                    FROM queue_to_approve 
                    INNER JOIN student USING(idstudent) 
                    WHERE idsem_settings = ?
                    AND student.idstudent = ?                    
                    AND student.idcourse IN (SELECT idcourse FROM faculty_pef_res WHERE idfaculty = ?) ORDER BY queue_to_approve.idqueue_to_approve ASC";
     $stmt = $pdo->prepare($qry);
     $stmt->execute([$idsem_settings, $idstudent, $idfaculty]);
          
     if ($stmt->rowCount() == 0) {
          echo '<div class="alert alert-danger text-center"><strong>EMPTY!</strong></div>';
     }
     else {               
?>
<table class="table-bordered" width="100%" id="for_approval">
     <thead>
          <tr>
               <th class="text-center" colspan="2" style="width:80%">STUDENT</th>
               <th class="text-center" style="width:20%">PEF NO.</th>
          </tr>
     </thead>
	<tbody>	
     <?php
     foreach($stmt as $row) {
?>
      <tr style="font-size:0.7em;">
           <td style="width:20%">
                <button class="ok btn btn-sm btn-success"><i class="fas fa-check"></i></button>
                <button class="cancel btn btn-sm btn-danger"><i class="far fa-trash-alt"></i></button>
                <input type="hidden" name="idnumber" value="<?php echo $row["idnumber"];?>"/>
                <input type="hidden" name="idstudent" value="<?php echo $row["idstudent"];?>"/>
                <input type="hidden" name="idqueue_to_approve" value="<?php echo $row["idqueue_to_approve"];?>"/>
          </td>
          <td style="width:60%"><?php echo $row['name'].' ['.$row['yl'].']'; ?></td>
          <td style="width:20%" class="text-center"><?php echo $row["idqueue_to_approve"]; ?></td> 
     </tr>
     <?php
          }
     }
     ?>