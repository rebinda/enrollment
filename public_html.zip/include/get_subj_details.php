<?php
	include_once("connect.php");

	$idsection = $_POST['idsection'];
	$idcurriculum = $_POST['idcurriculum'];

	$qry = "SELECT tmp.idsched,		
			tmp.idcurriculum, 											
			curriculum.description,			
			IF(curriculum.lab_unit = 0, curriculum.lec_unit,CONCAT(curriculum.lec_unit,'/',curriculum.lab_unit)) AS unit,
			room.room
		FROM (SELECT sched.idsched, 
				IF(sched.is_merge = 1, get_col_of_merge_sched(sched.idsched, 3), sched.days) AS days, 
				IF(sched.is_merge = 1, get_col_of_merge_sched(sched.idsched, 4), sched.idcurriculum) AS idcurriculum,
				IF(sched.is_merge = 1, get_col_of_merge_sched(sched.idsched, 5), sched.idroom) AS idroom
		  	FROM sched 
		  WHERE sched.idsection = ?) AS tmp 
		  INNER JOIN curriculum USING(idcurriculum) 
		  INNER JOIN room USING(idroom)
		  WHERE idcurriculum = ?;";
	$stmt = $pdo->prepare($qry);
	$stmt->execute([$idsection, $idcurriculum]);	
?>

<table class="table-bordered" width="100%" style="margin-bottom: 80px;">
	<thead>				
		<th>Title</th>
		<th>Units</th>		
		<th>Room</th>
	</thead>
	<tbody>		
		<?php
		foreach($stmt as $row) {
		?>
			<tr>										
			<td class="title"><input type="hidden" name="idcurriculum" value="<?php echo $row["idcurriculum"]; ?>"/><?php echo $row['description']; ?> </td>
			<td class="unit"><?php echo $row['unit']; ?> </td>			
			<td class="room"><?php echo $row['room']; ?> </td>
			</tr>
		<?php
		}
		?>					
	</tbody>
</table>