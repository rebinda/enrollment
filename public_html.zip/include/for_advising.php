<?php
$is_encoded = false;
if (is_encoded($idstudent, $idsem_settings)>0){ $is_encoded = true;} else{?>	
<button style="margin-bottom:10px;" class="btn btn-success" id="idapprove_all"><i class="far fa-thumbs-up fa-lg"></i> <small>APPROVE ALL</small></button>
<button style="margin-bottom:10px;" class="btn btn-danger" id="iddisapprove_all"><i class="far fa-thumbs-down fa-lg"></i> <small>DISAPPROVE ALL</small></button>
<div class="clearfix"></div>
<?php
}
$day = get_pef_status($idsem_settings, 'is_day_visible');
$time =  get_pef_status($idsem_settings, 'is_time_visible');
$room =  get_pef_status($idsem_settings, 'is_room_visible');
?>
<table class="table-bordered" width="100%" id="sched_block">
	<thead>		
		<th colspan="2">Code</th>		
		<th class="title">Title</th>
		<th class="unit">Units</th>
		<th class="day" <?php if($day==0){echo 'style="display:none;"';} ?>>Day</th>
		<th class="time" <?php if($time==0){echo 'style="display:none;"';} ?>>Time</th>
		<th class="room" <?php if($room==0){echo 'style="display:none;"';} ?>>Room</th>
	</thead>
	<tbody>
		<?php
		$class = '';
		foreach($stmt as $row) {
			if($row['is_adviser_approved']==0 && $row['is_chair_approved']==0) {
				$class = "text-danger";
			}
			elseif($row['is_adviser_approved']==1 && $row['is_chair_approved']==0) {
				$class="text-warning";
			}elseif($row['is_adviser_approved']==1 && $row['is_chair_approved']==1) {
				$class="text-success";
			}
		?>	
			<tr>
			<td width="100">
				
				<?php /*if(!$is_encoded){
				if($row['is_chair_approved']==1) { echo '<small class="text-success">DONE</small>';} 
				else {?>
				<button stat="<?php if($row['is_adviser_approved']==0){echo '0';} else {echo '1';} ?>" class="btn <?php if($row['is_adviser_approved']==0) {echo 'btn-danger';} else{echo 'btn-success';} ?>"> <?php if($row['is_adviser_approved']==0){echo '<i class="far fa-thumbs-down fa-lg"></i>';} else{echo '<i class="far fa-thumbs-up fa-lg"></i>';}?> </button>
				<?php }/*}*/?>
                    <?php
                         if($row['is_chair_approved'] == 1) {
                              echo '<button name="approve" class="btn btn-success" disabled="disabled"><i class="far fa-thumbs-up fa-lg"></i></button>';
                         }else{
                    ?>
                              <button name="approve" stat="<?php 
                                                  if($row['is_adviser_approved']==0){
                                                       echo '0';} 
                                                  else {echo '1';} ?>" 
                                   class="btn <?php 
                                                  if($row['is_adviser_approved']==0) {
                                                       echo 'btn-danger';} 
                                                  else{echo 'btn-success';} ?>"> 
                                   <?php 
                                        if($row['is_adviser_approved']==0){
                                             echo '<i class="far fa-thumbs-down fa-lg"></i>';} 
                                        else{echo '<i class="far fa-thumbs-up fa-lg"></i>';}?> 
                              </button>
                              <button name="remove" class="btn btn-outline-info"><i class="fas fa-window-close"></i></button>
                         <?php
                              }
                         ?>
				<input type="hidden" name="idsched" value="<?php echo $row["idsched"]; ?>"/>
				<input type="hidden" name="idstud_sched" value="<?php echo $row["idstudent_sched"]; ?>"/>
				<input type="hidden" name="idcurriculum" value="<?php echo $row["idcurriculum"]; ?>"/>
				<input type="hidden" name="idsection" value="<?php echo $row["idsection"]; ?>"/>
			</td>			
			<td><span class="subj <?php echo $class; ?>"><?php echo $row['subj'];?> </span></td>
			<td class="title <?php echo $class; ?>"><?php echo $row['description']; ?> </td>
			<td class="unit <?php echo $class; ?>"><?php echo $row['unit']; ?> </td>
			<td class="day <?php echo $class; ?>" <?php if($day==0){echo 'style="display:none;"';} ?>><?php echo $row['week_day_name']; ?> </td>
			<td class="time <?php echo $class; ?>" <?php if($time==0){echo 'style="display:none;"';} ?>><?php echo $row['class_time']; ?> </td>
			<td class="room <?php echo $class; ?>" <?php if($room==0){echo 'style="display:none;"';} ?>><?php echo $row['room']; ?> </td>
			</tr>
		<?php
		}
		?>
	</tbody>
</table>
<div id="total_units" class="alert alert-success text-right" style="margin-bottom: 80px;"><?php echo 'TOTAL UNITS: <strong>'.get_total_student_units($idsem_settings, $idstudent, 1, $idqueue_to_approve).'</strong>'; ?></div>