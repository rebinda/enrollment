<?php
     include_once("function.php");
     $message = $_POST['message'];
     $idnumber = $_POST['idstudent'];
     $idstudent = get_idstudent($idnumber);
     $idfaculty = $_POST['idfaculty'];
     $idsem_settings = $_POST['idsem_settings'];

     $mydate = date('Y-m-d');

     if ($idstudent == '') {
          echo 'NO SELECTED STUDENT';
          exit;
     }
     if ($message == '') {
          echo 'PLEASE WRITE A MESSAGE';
          exit;
     }
     $stmt = $pdo->prepare("INSERT INTO msg(idfaculty, idstudent, message, idsem_settings, date_sent) VALUES(?, ?, ?, ?, ?);");
     $stmt->execute([$idfaculty, $idstudent, $message, $idsem_settings, $mydate]);
?>