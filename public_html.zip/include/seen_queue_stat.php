<?php
     include_once("connect.php");
     $idstudent = $_POST['idstudent'];
     $idsem_settings = $_POST['idsem_settings'];
     $idqueue_to_approve = $_POST['idqueue_to_approve'];

     $stmt = $pdo->prepare("SELECT COUNT(*) FROM queue WHERE idqueue_to_approve = ?
				AND idsem_settings=? AND is_seen_encoded=0 AND stat=1;");
     $stmt->execute([$idqueue_to_approve, $idsem_settings]);
     $row = $stmt->fetchColumn();
     if($row>0){echo '<span id="is_seen_encoded">1</span>';}
     if ($row==0) {
          $stmt = $pdo->prepare("SELECT COUNT(*) FROM queue WHERE idqueue_to_approve =?
				AND idsem_settings=? AND is_seen_issue=0 AND stat=2;");
          $stmt->execute([$idqueue_to_approve, $idsem_settings]);
          $row = $stmt->fetchColumn();
          if($row>0){echo '<span id="is_seen_issue">1</span>';}
     }

?>