<?php
     include_once('function.php');
     $idstudent = $_POST['idstudent'];
     $idsem_settings = $_POST['idsem_settings'];

     if (is_inqueue_to_approve($idstudent, $idsem_settings)>0) {
          echo '<span class="text-danger">Already in Queue.</span>';
     }else{echo "";}
?>