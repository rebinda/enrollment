<?php
     include_once("connect.php");
     $message = $_POST['message'];
     $idstudent = $_POST['idstudent'];     
     $idfaculty = $_POST['idfaculty'];
     $idsem_settings = $_POST['idsem_settings'];
     $idqueue_to_approve = $_POST['idqueue_to_approve'];

     $mydate = date('Y-m-d');

     if ($message == '') {
          echo 'PLEASE WRITE A MESSAGE';
          exit;
     }

     $stmt = $pdo->prepare("INSERT INTO msg(idfaculty, idstudent, message, idsem_settings, date_sent) VALUES(?, ?, ?, ?, ?);");
     $stmt->execute([$idfaculty, $idstudent, $message, $idsem_settings, $mydate]);

     
     $stmt = $pdo->prepare("DELETE FROM student_sched WHERE idsem_settings = ? AND idqueue_to_approve = ? AND idstudent = ?");
     $stmt->execute([$idsem_settings, $idqueue_to_approve, $idstudent]);

     $stmt = $pdo->prepare("DELETE FROM queue_to_approve WHERE idsem_settings = ? AND idqueue_to_approve = ? AND idstudent = ?");
     $stmt->execute([$idsem_settings, $idqueue_to_approve, $idstudent]);
?>