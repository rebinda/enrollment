<?php
include_once("function.php");


$idstudent = get_idstudent($_POST['idnumber']);
$idsem_settings = $_POST['idsem_settings'];
$iddept = $_POST['iddept'];

if (is_inqueue($idstudent, $idsem_settings, $iddept)==0) {
	$stmt = $pdo->prepare("INSERT INTO queue(idstudent, idsem_settings, iddept) VALUES(?, ?, ?);");
	$stmt->execute([$idstudent, $idsem_settings, $iddept]);
	echo '<span class="text-success">QUEUE was successfully SENT.</span>';
}else {
	echo '<span class="text-danger">Already in QUEUE</span>';
}
?>