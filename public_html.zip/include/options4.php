<div class="form-check">
	<label class="form-check-label">
		<input class="form-check-input" name="ans<?php echo $question['idsurvey_question']; ?>" type="radio" value="1">
		Yes
	</label>
</div>
<div class="form-check">
	<label class="form-check-label">
		<input class="form-check-input" name="ans<?php echo $question['idsurvey_question']; ?>" type="radio" value="2">
		No
	</label>
</div>
<div class="form-check">
	<label class="form-check-label">
		<input class="form-check-input" name="ans<?php echo $question['idsurvey_question']; ?>" type="radio" value="3">
		Maybe
	</label>
</div>
<div class="form-group explain <?php echo 'exp'.$question['idsurvey_question']; ?>">
  <label for="usr" class="text-danger">Why?</label>
  <input type="text" class="form-control" name="exp<?php echo $question['idsurvey_question']; ?>" maxlength="250">
</div>
