<?php
     include_once("connect.php");
     session_start();
     $idsem_settings = $_POST['idsem_settings'];
     $approver = $_POST['approver'];
     $idfaculty = $_SESSION['idfaculty'];
     $from_q = $_POST['from_queue'];
     $qry = '';

     //if ($from_q > 0) {
          $qry = "SELECT COUNT(*) FROM queue_to_approve 
          INNER JOIN student USING(idstudent)
          WHERE queue_to_approve.idsem_settings = ? 
          AND queue_to_approve.approver=?
          AND queue_to_approve.idqueue_to_approve IN (SELECT idqueue_to_approve FROM student_sched WHERE idsem_settings = ?)
          AND queue_to_approve.idqueue_to_approve NOT IN (SELECT idqueue_to_approve FROM queue WHERE idsem_settings = ?)
          AND student.idcourse IN (SELECT idcourse FROM faculty_pef_res WHERE idfaculty = ?)";
     //}else{
     /*     $qry = "SELECT COUNT(*) FROM queue_to_approve 
          INNER JOIN student USING(idstudent) 
          WHERE idsem_settings = ? 
          AND approver=?
          AND student.idstudent NOT IN (SELECT idstudent FROM queue WHERE idsem_settings = ?)
          AND student.idcourse IN (SELECT idcourse FROM faculty_pef_res WHERE idfaculty = ?)";
     }*/
     $stmt = $pdo->prepare($qry);
     $stmt->execute([$idsem_settings, $approver, $idsem_settings, $idsem_settings, $idfaculty]);
     $total = $stmt->fetchColumn();
     echo $total;
?>