<?php
     include_once("connect.php");
     $idstudent = $_POST['idstudent'];
     $idsem_settings = $_POST['idsem_settings'];

     $stmt = $pdo->prepare('SELECT COUNT(*) FROM assessment WHERE idstudent=? AND idsem_settings=?');				
     $stmt->execute([$idstudent, $idsem_settings]);
	 $rowAssess = $stmt->fetchColumn();

	 $stmt = $pdo->prepare('SELECT COUNT(*) FROM student_sched WHERE idstudent=? AND idsem_settings=?');				
     $stmt->execute([$idstudent, $idsem_settings]);
	 $rowStudSched = $stmt->fetchColumn();
     
	if ($rowStudSched == 0) {
		echo 0; 
	}
	elseif ($rowStudSched > 0 && $rowAssess == 0) {
		echo 1; /*Registered*/
	}elseif ($rowStudSched > 0 && $rowAssess > 0) {
		echo 2; /*Assessed*/
	}     
?>