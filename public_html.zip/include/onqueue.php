<?php
	include_once("function.php");
     session_start();
     if (!isset($_SESSION['is_faculty_login'])) {die("<div class=\"alert alert-danger\"><i class=\"fas fa-exclamation\" style=\"font-size:24px;\"></i> <strong> YOU NEED TO LOGIN!</strong></div>");}

	$idsem_settings = $_POST['idsem_settings'];
	$stat = $_POST['tab'];
	$iddept = $_POST['iddept'];
     $idfaculty = $_SESSION['idfaculty'];
     $date_encoded = $_POST['date_encoded'];    
	$is_single_encoding = get_pef_status($idsem_settings,'is_single_encoding');

     $qry = '';
     if ($stat==0){
          $qry = "SELECT queue.idqueue,
					UPPER(student.lname) AS lname,
					UPPER(student.fname) AS fname,
                         student.cp,
					student.idnumber,
                         queue.idstudent,
                         queue.idqueue_to_approve
				FROM student 
				INNER JOIN queue USING(idstudent)
				WHERE queue.stat = ?
				AND queue.idsem_settings=?
                    AND student.idcourse IN (SELECT idcourse FROM faculty_pef_res WHERE idfaculty = ?)
				ORDER BY queue.idqueue ASC;";
          $stmt = $pdo->prepare($qry);
	    $stmt->execute([$stat, $idsem_settings, $idfaculty]);
     }else if($stat==1){
          $qry = "SELECT queue.idqueue,
					UPPER(student.lname) AS lname,
					UPPER(student.fname) AS fname,
                         student.cp,
					student.idnumber,
                         queue.idstudent,
                         queue.idqueue_to_approve
				FROM student 
				INNER JOIN queue USING(idstudent)
				WHERE queue.stat = ?
                    AND DATE(date_encoded) = ?
				AND queue.idsem_settings=?
                    AND student.idcourse IN (SELECT idcourse FROM faculty_pef_res WHERE idfaculty = ?)
				ORDER BY queue.idqueue DESC;";
          $stmt = $pdo->prepare($qry);
	    $stmt->execute([$stat, $date_encoded, $idsem_settings, $idfaculty]);
     } else{
          $qry = "SELECT queue.idqueue,
					UPPER(student.lname) AS lname,
					UPPER(student.fname) AS fname,
                         student.cp,
					student.idnumber,
                         queue.idstudent,
                         queue.idqueue_to_approve
				FROM student 
				INNER JOIN queue USING(idstudent)
				WHERE queue.stat = ?                    
				AND queue.idsem_settings=?
                    AND student.idcourse IN (SELECT idcourse FROM faculty_pef_res WHERE idfaculty = ?)
				ORDER BY queue.idqueue DESC;";
         $stmt = $pdo->prepare($qry);
	    $stmt->execute([$stat, $idsem_settings, $idfaculty]);
     }	


	$row_count = $stmt->rowCount();
?>
		
	<table class="table-bordered" width="100%" id="<?php if($stat==0) {echo 'table_queue';}
												   elseif($stat==1){echo 'table_encoded';}
												   elseif($stat==2){echo 'table_with_issues';}?>">
		<thead>							
			<th class="student">STUDENT</th>
			<th class="course">ACTION</th>			
		</thead>
		<tbody>
			<?php
			$i=0;
			foreach($stmt as $row) {
				$i++;
			?>
			<tr <?php if($i==1) {echo 'data-toggle="collapse" data-target="#accordion"';} ?>>		
				<td class="<?php if($is_single_encoding == 1) {
										if($stat==0) { 
														if($i==1) {echo 'clickable top_most';}
									}else{
										echo 'clickable';}
									}else{echo 'clickable';} 
			?>">
			<?php echo $row['lname'].'<br>'.$row['fname'].'<br>['.$row['idnumber'].'] '.$row['cp']; ?>
				<input type="hidden" name="idq" value="<?php echo $row['idqueue'];                    
                                                           ?>"/>
                    <input type="hidden" name="idstudent" value="<?php echo $row['idstudent'];                    
                                                           ?>"/>
                    <input type="hidden" name="idqueue_to_approve" value="<?php echo $row['idqueue_to_approve'];                    
                                                           ?>"/>
				</td>
				<td <?php if($stat==0) { if($i==1) {echo 'class="top_most"';}} ?>>
					<?php 						
						if($stat==0) {
							if($is_single_encoding == 1) {
								if ($i==1) {
									echo '<button class="btn btn-success" name="done"><i class="fas fa-check"></i> <small></small></button>';
									echo ' <button class="btn btn-danger" name="unencoded"><i class="fas fa-comment"></i> <small></small></button>';
								}
							}else{
								echo '<button class="btn btn-success" name="done"><i class="fas fa-check"></i> <small></small></button>';
								echo ' <button class="btn btn-danger" name="unencoded"><i class="fas fa-comment"></i> <small></small></button>';
							}
							
						}
						elseif($stat==1) {
								echo ' <button class="btn btn-danger" name="unencoded"><i class="fas fa-comment"></i> <small></small></button>';}
						elseif($stat==2) {
								echo '<button class="btn btn-success" name="done"><i class="fas fa-check"></i> <small></small></button>';}
						 ?>
				</td>
			</tr>
				<tr class="row_sched">
					<td colspan="2">
					<div class="table_sched"></div>
					</td>
				</tr>
			<?php							 					
			} ?>			
		</tbody>
	</table>
	<?php		
		if($row_count == 0) {echo '<div class="alert alert-danger text-center"><strong class="text-danger">EMPTY</strong></td>';}
	?>