<?php
     include_once('connect.php');
     $idstudent = $_POST['idstudent'];
     $idsem_settings = $_POST['idsem_settings'];

     $stmt = $pdo->prepare('SELECT COUNT(*) FROM msg
                              WHERE idsem_settings = ?
                              AND idstudent = ?
                              AND is_seen = 0;');
     $stmt->execute([$idsem_settings, $idstudent]);
     $result = $stmt->fetchColumn();
     if($result > 0) {echo $result;}
?>