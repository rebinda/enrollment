<?php
     include_once('connect.php');
     $idstudent = $_POST['idstudent'];
     $stmt = $pdo->prepare('DELETE FROM student WHERE idstudent = ?');
     $stmt->execute([$idstudent]);
?>