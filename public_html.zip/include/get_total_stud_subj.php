<?php
     include_once("function.php");     
     $idstudent = $_POST['idstudent'];
     $idsem_settings = $_POST['idsem_settings'];
     $stmt = $pdo->prepare("SELECT idsched, idcurriculum  FROM tmp_student_sched 
                              INNER JOIN sched USING(idsched)
                              INNER JOIN curriculum USING(idcurriculum)
                              WHERE tmp_student_sched.idstudent = ? AND tmp_student_sched.idsem_settings = ?
                              GROUP BY idcurriculum;");
     $stmt->execute([$idstudent, $idsem_settings]);
     //$result = $stmt->fetchColumn();
     $result = $stmt->rowCount();
     if($result > 0) {echo $result;}
     
?>