<?php
include_once("connect.php");

$id  = $_POST['idnumber'];
$pwd = $_POST['password'];

$stmt = $pdo->prepare("SELECT COUNT(*) FROM student WHERE idnumber = ? AND pwd COLLATE utf8_bin = ?;");
$stmt->execute([$id, $pwd]);

$count = $stmt->fetchColumn();

echo $count;
?>