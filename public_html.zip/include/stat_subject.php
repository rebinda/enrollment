<?php
include_once("function.php");
$res["show"] = $_POST['show'];
$res["value"] = 0;

$idadviser = $_POST['idfaculty'];
$idsem_settings = $_POST['idsem_settings'];
$operation = $_POST['operation']; //0-disapprove 1-approve
$idstudent = get_idstudent($_POST['idnumber']);
$idcurriculum = $_POST['idcurriculum'];
$idsched = $_POST['idsched'];
$idsection = $_POST['idsection'];
$idstud_sched = $_POST['idstud_sched'];
$role = $_POST['role'];
$qry = "";

if ($role == 1) { //adviser
     if(is_valid_approver($idstud_sched, $idadviser)==0) {
          $res["value"] = 1;
          echo json_encode($res);
          return;
     }
	if($operation == 1) { //disapprove -> approve          
          /*if(is_class_full($idsem_settings, $idsched, $idcurriculum, $idsection) > 0) {
               $res["value"] = 2;
               echo json_encode($res);
               return;
          }*/
		$qry = "UPDATE student_sched SET is_adviser_approved = 1, idadviser = ? 
		WHERE idsem_settings = ? 
		AND idstudent = ?
		AND idsched IN (SELECT idsched FROM sched WHERE idcurriculum = ?) ;";
	}else{//approved -> disapprove
		$qry = "UPDATE student_sched SET is_adviser_approved = 0, idadviser = ? 
		WHERE idsem_settings = ? 
		AND idstudent = ?
		AND idsched IN (SELECT idsched FROM sched WHERE idcurriculum = ?) ;";	
	}
}
elseif($role == 3) { //chairperson
     if(is_valid_approver($idstud_sched, $idadviser)==0) {
          $res["value"] = 1;
          echo json_encode($res);
          return;
     }
	if($operation == 1) { //disapprove -> approve          
          /*if(is_class_full($idsem_settings, $idsched, $idcurriculum, $idsection) > 0) {
               $res["value"] = 2;
               echo json_encode($res);
               return;
          }*/
		$qry = "UPDATE student_sched SET is_chair_approved = 1, idchair = ? 
		WHERE idsem_settings = ? 
		AND idstudent = ?
		AND idsched IN (SELECT idsched FROM sched WHERE idcurriculum = ?) ;";
	}else{//approved -> disapprove
		$qry = "UPDATE student_sched SET is_chair_approved = 0, idchair = ? 
		WHERE idsem_settings = ? 
		AND idstudent = ?
		AND idsched IN (SELECT idsched FROM sched WHERE idcurriculum = ?) ;";	
	}
}

$stmt = $pdo->prepare($qry);
$rs = $stmt->execute([$idadviser, $idsem_settings, $idstudent, $idcurriculum]);

echo json_encode($res);
?>