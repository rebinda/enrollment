<?php
$idstudent = $_POST['idstudent'];
$idsem_settings = $_POST['idsem_settings'];
$idcourse = $_POST['idcourse'];
$idqueue_to_approve = $_POST['idqueue_to_approve'];
include_once("function.php");
?>
<table id="table_queue_stat" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td class="label_title" valign="top"><strong class="text-seconday">SERVING</strong></td>
		<td valign="top"><strong class="text-primary"><?php echo get_currently_serving_queue($idsem_settings, $idcourse); ?></strong></td>
	</tr>	
	<tr>
		<td class="label_title" valign="top"><strong class="text-seconday">MY Q NO.</strong></td>
		<td valign="top"><strong class="text-primary">
			<?php foreach(get_student_queue_q($idqueue_to_approve, $idsem_settings) as $row) {
					echo $row['idqueue'].' <small>'.get_q_stat($row['idqueue']).'</small><br>';
			}
			?></strong></td>
	</tr>	
</table>
