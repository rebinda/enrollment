<?php
	include_once("function.php");
	$idsection = $_POST['idsection'];
	$idcurriculum = $_POST['idcurriculum'];

	$idstudent = $_POST['idstudent'];
	$idsem_settings = $_POST['idsem_settings'];
	$idcourse = $_POST['idcourse'];
    $idsched = $_POST['idsched'];


	// echo "idsection: ".$idsection.
	// " idcurriculum: ".$idcurriculum.
	// " idstudent: ".$idstudent.
	// " idsem_settings: ".$idsem_settings.
	// " Idcourse: ".$idcourse.
	// " idsched: ".$idsched;
	// exit;

     //THE COMMENTED SQL is only applicable on Localhost AND NON-SHARED web hosting
     //The commented SQL does not work on Shared Web Hosting.

     //=============================================
     //Checks for Class is Full
     $res["type"] = 0;
     $res["message"] = '';
     if (is_class_full($idsem_settings, $idsched, $idcurriculum, $idsection) > 0) {
               $res["type"] = 1;
               $res["message"] = '<span class="text-danger">This Class is Full.</span>';
               echo json_encode($res);
               exit;
     }

     if (is_subject_taken($idsem_settings, $idstudent, $idcurriculum) > 0) {
          $res["type"] = 2;
          $res["message"] = '<span class="text-danger">The course you are selecting is already in your list.</span>';
          echo json_encode($res);
          exit;
     }
     if (has_submitted_courses($idsem_settings, $idstudent) > 0) {
        $res["type"] = 2;
        $res["message"] = '<span class="text-danger">YOU HAVE ALREADY SUBMITTED YOUR COURSES. <br/> <small class="text-info">Selecting a <strong>new course</strong> is no longer allowed. See your chairperson/Adviser for course correction.</small></span>';
        echo json_encode($res);
        exit;
   }

     if (is_enable_prereq($idsem_settings) == 0) {
          $prereq = get_prereq($idstudent, $idcurriculum);
          if ($prereq["rowCount"]> 0) {
          $res["type"] = 2;
          $res["message"] = '<span class="text-danger">Before taking this course, you must have taken and passed the following courses:</span>
                              <ul>'.$prereq["message"].'</ul>';
          echo json_encode($res);
          exit;
          }     
     }
   	 
//      //=============================================
//      //Checks for overlap sched in tmp_student_sched
     $day = get_pef_status($idsem_settings, 'is_day_visible');
	$time =  get_pef_status($idsem_settings, 'is_time_visible');

     $res["message"] = '';
	$stud_sched = $pdo->prepare("SELECT s_time, e_time, days FROM sched WHERE idcurriculum = ? AND idsection =? AND is_merge=0;");
	$stud_sched->execute([$idcurriculum, $idsection]);
     $qry = "SELECT
					tmp.s_time AS start_time,
					tmp.e_time AS end_time,
					tmp.code1,
					curriculum.description,
					CONCAT(TIME_FORMAT(tmp.s_time, '%h:%i %p'),'-',TIME_FORMAT(tmp.e_time, '%h:%i %p')) AS class_time,
					(CASE tmp.days
					WHEN 0 THEN 'MON'
					WHEN 1 THEN 'TUE'
					WHEN 2 THEN 'WED'
					WHEN 3 THEN 'THU'
					WHEN 4 THEN 'FRI'
					WHEN 5 THEN 'SAT'
					WHEN 6 THEN 'SUN' END) AS week_day_name
		FROM
			(SELECT sched.idsched,
				get_course_code(sched.idsched) AS code1,
				section.idsem_settings,
				sched.days,
				sched.idcurriculum,
				sched.idroom,
				sched.idsection,
				sched.idfaculty,
				sched.s_time,
				sched.e_time,
				get_merged_sched(sched.idsched) AS subj
			FROM sched LEFT join sched_merged ON sched.idsched = sched_merged.merged_with
			INNER JOIN section ON sched.idsection = section.idsection
			WHERE section.idsem_settings = :idsem_settings) AS tmp
			INNER JOIN curriculum USING(idcurriculum)
		INNER JOIN room USING(idroom)
		INNER JOIN section USING(idsection)
		INNER JOIN tmp_student_sched
		ON tmp.idsched = tmp_student_sched.idsched
		AND tmp.idsem_settings = tmp_student_sched.idsem_settings
		LEFT JOIN faculty USING(idfaculty)
		WHERE tmp_student_sched.idstudent = :idstudent
		AND days = :days AND
			(((:s_time < tmp.s_time AND :s_time < tmp.e_time) AND (:e_time > tmp.s_time AND :e_time <= tmp.e_time))
			OR
			((:s_time >= tmp.s_time AND :s_time < tmp.e_time) AND (:e_time > tmp.s_time AND :e_time >= tmp.e_time))
			OR
			((:s_time BETWEEN tmp.s_time AND tmp.e_time) AND (:e_time BETWEEN tmp.s_time AND tmp.e_time))
			OR
			((:s_time < tmp.s_time AND :s_time < tmp.e_time) AND (:e_time > tmp.s_time AND :e_time > tmp.e_time)))
		GROUP BY tmp.idsched
		ORDER BY curriculum.idcurriculum ASC, tmp.idsched ASC;";

	$pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES,true);
	$stmt = $pdo->prepare($qry);

	foreach($stud_sched as $stud_sched_row)
	{
		$stmt->execute(['idsem_settings'=>$idsem_settings,
							  'idstudent'=>$idstudent,
							  'days'=>$stud_sched_row['days'],
							  's_time'=> $stud_sched_row['s_time'],
							  'e_time'=> $stud_sched_row['e_time']]);

		foreach($stmt as $row) {
            $res["type"] = 2;
            $res["message"] .= '<div id="overlapping_sched"><span class="text-success">'.$row['code1'].'</span><span class="text-muted">'.$row['class_time'].'</span><span class="text-warning">'.$row['week_day_name'].'</span></div>';
		}
	}

	$pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
     if ($res["message"] <> '') {
          echo json_encode($res);
          exit;
     }



//      //=============================================

     $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES,true);
     $stmt = $pdo->prepare("SELECT IF(ISNULL(tmp.sched2),tmp.idsched, tmp.sched2) AS idsched,
                                    tmp.idcurriculum
                                    FROM (SELECT sched.idsched,
                                                get_idsched_merge_sched(sched.idsched, :idsection) AS sched2,
                                                sched.days,
                                                sched.idcurriculum,
                                                sched.idroom,
                                                sched.idsection,
                                                sched.idfaculty,
                                                TIME_FORMAT(sched.s_time, '%h:%i %p') AS start_time,
                                                TIME_FORMAT(sched.e_time, '%h:%i %p') AS end_time,
                                                get_merged_sched(sched.idsched) AS subj
                                            FROM sched LEFT join sched_merged ON sched.idsched = sched_merged.merged_with
                                            INNER JOIN section ON sched.idsection = section.idsection
                                            WHERE is_merge = 0 AND sched.idsection = :idsection AND section.idsem_settings = :idsem_settings
                                            UNION ALL
                                            SELECT u.* FROM (
                                                    SELECT sched.idsched,
                                                        get_idsched_merge_sched(sched.idsched, :idsection) AS sched2,
                                                        sched_merged.merged_with,
                                                        sched.days,
                                                        sched.idcurriculum,
                                                        sched.idroom,
                                                        sched.idsection,
                                                        sched.idfaculty,
                                                        TIME_FORMAT(sched.s_time, '%h:%i %p') AS start_time,
                                                        TIME_FORMAT(sched.e_time, '%h:%i %p') AS end_time,
                                                        get_merged_child(sched.idsched) AS subj
                                                    FROM sched LEFT join sched_merged ON sched.idsched = sched_merged.idsched
                                                    INNER JOIN section ON sched.idsection = section.idsection
                                                    where is_merge = 1 AND sched.idsection= :idsection AND section.idsem_settings = :idsem_settings) AS m
                                            INNER JOIN (SELECT sched.idsched,
                                                            get_idsched_merge_sched(sched.idsched, :idsection) AS sched2,
                                                            sched.days,
                                                            sched.idcurriculum,
                                                            sched.idroom,
                                                            sched.idsection,
                                                            sched.idfaculty,
                                                            TIME_FORMAT(sched.s_time, '%h:%i %p') AS start_time,
                                                            TIME_FORMAT(sched.e_time, '%h:%i %p') AS end_time,
                                                            get_merged_sched(sched.idsched) AS subj
                                            FROM sched inner join sched_merged ON sched.idsched = sched_merged.merged_with
                                            INNER JOIN section ON sched.idsection = section.idsection
                                            WHERE is_merge = 0 AND section.idsem_settings = :idsem_settings) AS u where m.merged_with = u.idsched
                                        ) AS tmp
                                    INNER JOIN curriculum USING(idcurriculum)
                                    INNER JOIN room USING(idroom)
                                    INNER JOIN section USING(idsection)
                                    WHERE tmp.idcurriculum = :idcurriculum
                                    GROUP BY tmp.idsched
                                    ORDER BY tmp.idcurriculum ASC, idsched ASC");

	//$stmt->execute([$idsection, $idcurriculum]);
    $stmt->execute(['idsem_settings'=>$idsem_settings,
							  'idsection'=>$idsection,
							  'idcurriculum'=>$idcurriculum]);

    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
	foreach($stmt as $row) {

		$ins = $pdo->prepare("INSERT INTO tmp_student_sched(idstudent, idsched, idsem_settings,idsection, idcourse) VALUES(?, ?, ?, ?, ?);");
		$ins->execute([$idstudent, $row["idsched"], $idsem_settings, $idsection, $idcourse]);
	}
     $res["type"] = 0;
     $res["message"] = '';
     echo json_encode($res);

?>