<?php
include_once("function.php");

$idstudent = $_POST['idstudent'];
$idsem_settings = $_POST['idsem_settings'];
$idcurriculum = $_POST['idcurriculum'];

$res = is_subject_exist($idstudent,$idsem_settings, $idcurriculum);

echo $res;
?>