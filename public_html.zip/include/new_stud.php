<?php
     include_once('function.php');
     $idnumber = '';
     $lname = trim($_POST['lname']);
     $fname = trim($_POST['fname']);
     $idnumber =  str_replace('-','',trim($_POST['idnumber']));
     $dob = $_POST['dob'];
     $isedit = $_POST['is_editting'];
     $idcourse = $_POST['idcourse'];
     $res["value"] = '';
     $res["message"] = '';

     if ($lname == '') {
          $res["value"] = 0;
          $res["message"] = "Lastname is EMPTY";
          echo json_encode($res);
          return;
     }

     if ($fname == '') {
          $res["value"] = 0;
          $res["message"] = "Firstname is EMPTY";
          echo json_encode($res);
          return;
     }

     if ($idnumber == '') {
          $res["value"] = 0;
          $res["message"] = "ID Number is EMPTY";
          echo json_encode($res);
          return;
     }

     if ($dob == '') {
          $res["value"] = 0;
          $res["message"] = "Birthdate is EMPTY";
          echo json_encode($res);
          return;
     }

     if ($isedit == 1) {
          
          $idstudent = get_idstudent($idnumber);
          $present_idnumber = get_idnumber($idstudent);
          if ($idnumber <> $present_idnumber) {
               if (is_idnumber_exist($idnumber) > 0) {
                    $res["value"] = 0;
                    $res["message"] = "ID NUMBER: {$idnumber} is already taken.";
                    echo json_encode($res);
                    return;
               }
          }
          
         
          $stmt = $pdo->prepare("UPDATE student SET 
                              idcourse = :idcourse, 
                              lname = :lname, 
                              idnumber = :idnumber, 
                              fname = :fname, 
                              dob = :dob 
                              WHERE idstudent = :idstudent");
          $rs = $stmt->execute(['idcourse' => $idcourse, 
                                'lname' => $lname, 
                                'idnumber' => $idnumber, 
                                'fname' => $fname, 
                                'dob' => $dob, 
                                'idstudent' => $idstudent]);          
          
          //$res["message"] = '';
          $res["message"] = $isedit.' '.$idnumber.' '.$lname.' '.$fname.' '.$dob.' '.$idcourse;
          $res["value"] = 1;     
          echo json_encode($res);
          exit;
     }


     if (is_idnumber_exist($idnumber) > 0) {
          $res["value"] = 0;
          $res["message"] = "ID NUMBER: {$idnumber} is already taken.";
          echo json_encode($res);
          return;
     }

     $stmt = $pdo->prepare("INSERT INTO student(idnumber, lname, fname, dob, idcourse, pwd)
                         VALUES(?, ?, ?, ?, ?, '123456')");
     $stmt->execute([$idnumber, $lname, $fname, $dob, $idcourse]);

     $res["value"] = 1;
     $res["message"] = '';     
     echo json_encode($res);
?>