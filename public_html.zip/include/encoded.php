<?php
include_once("function.php");
session_start();
if (!isset($_SESSION['is_faculty_login'])) {die("<div class=\"alert alert-danger\"><i class=\"fas fa-exclamation\" style=\"font-size:24px;\"></i> <strong> YOU NEED TO LOGIN!</strong></div>");}

/* if caller=0 the request is from queue.php*/
/* if caller=1 the request is from advising.php*/
$idfaculty = $_SESSION['idfaculty'];
$caller =  $_POST['caller'];
$stat = $_POST['stat'];
$stmt='';
$mydate = date('Y-m-d H:m:s');
if ($caller==0) {
	$idqueue = $_POST['idq'];
     if ($stat ==1){
          $stmt = $pdo->prepare("UPDATE queue SET stat = ?, date_encoded = ?, is_seen_encoded=0, idfaculty = ? WHERE idqueue = ?");
     }else if($stat ==2){
          $stmt = $pdo->prepare("UPDATE queue SET stat = ?, date_encoded = ?, is_seen_issue=0, idfaculty = ? WHERE idqueue = ?");
     }
     $stmt->execute([$stat,$mydate, $idfaculty, $idqueue]);
}else{
	
	$idstudent = get_idstudent($_POST['idnumber']);
	$idsem_settings = $_POST['idsem_settings'];
	$idqueue_to_approve = $_POST['idq'];
	$stmt = $pdo->prepare("UPDATE queue SET stat = ?, idfaculty = ? WHERE idstudent = ? AND idqueue_to_approve = ? AND idsem_settings = ?");
	$stmt->execute([$stat, $idfaculty, $idstudent, $idqueue_to_approve, $idsem_settings]);	
}

?>