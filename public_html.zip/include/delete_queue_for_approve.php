<?php
     include_once("connect.php");
     $idstudent = $_POST['idstudent'];
     $idsem_settings = $_POST['idsem_settings'];     
     
     $stmt = $pdo->prepare('DELETE FROM queue_to_approve WHERE idstudent=? AND idsem_settings=?');
     $stmt->execute([$idstudent, $idsem_settings]);

?>