<?php
include_once("connect.php");

function is_enable_prereq($idsem_settings) {
     $stmt = $GLOBALS['pdo']->prepare("SELECT is_enable_prereq FROM sem_settings WHERE idsem_settings = ?");
     $stmt->execute([$idsem_settings]);
     $row = $stmt->fetchColumn();
	return $row;
}
function get_prereq($idstudent, $idcurriculum_key) {
     $stmt = $GLOBALS['pdo']->prepare("CALL show_prereq(:idstudent, :idcurriculum_key)");
     $stmt->bindParam(':idstudent',$idstudent,PDO::PARAM_INT);
     $stmt->bindParam(':idcurriculum_key',$idcurriculum_key,PDO::PARAM_INT);
     $stmt->execute();
     $data = $stmt->fetchAll();
     $stmt->nextRowset();

     $scode = array("rowCount"=> 0, "message"=> "");    
     foreach($data as $row) {
          $scode["message"] .= '<li class="text-primary" style="font-size:0.8em">'.$row["code"].' - '.$row["description"].'</li>';
          $scode["rowCount"]+=1;          
     }
     return $scode;
}
function get_pef_progress($idsem_settings, $idstudent) {
     $stmt = $GLOBALS['pdo']->prepare("SELECT approver FROM queue_to_approve WHERE idsem_settings = ? AND idstudent = ?");
     $stmt->execute([$idsem_settings, $idstudent]);
     $res = $stmt->fetchColumn();
     $msg = '';
     if ($res == 0) {
          $msg = '<strong class="text-success">[1<sup>ST</sup> ADVISING]</strong>';
     }
     else if($res == 1) {
          $msg = '<strong class="text-success">[2<sup>ND</sup> ADVISING]</strong>';
     }
     else {
          $stmt = $GLOBALS['pdo']->prepare("SELECT stat FROM queue WHERE idsem_settings = ? AND idstudent = ?");
          $stmt->execute([$idsem_settings, $idstudent]);
          if ($stmt->rowCount() == 0) {
               $msg = '<strong class="text-success">[ENCODING...]</strong>';
          }
          else {
               $res = $stmt->fetchColumn();
               if ($res== 0) {
                    $msg = '<strong class="text-success">[ENCODING...]</strong>';
               }
               else if($res ==1){
                    $msg = '';
               }
               else{
                    $msg = '<strong class="text-danger">[WITH ISSUES]</strong>';
               }
          }
          
     }
     return $msg;
}

function has_submitted_courses($idsem_settings, $idstudent) {
     $stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM student_sched WHERE idsem_settings = ? AND idstudent = ?");
     $stmt->execute([$idsem_settings, $idstudent]);
     return $stmt->fetchColumn() >= 1;
}

function has_submitted_two_pef($idsem_settings, $idstudent) {
     $stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM queue_to_approve WHERE idsem_settings = ? AND idstudent = ?");
     $stmt->execute([$idsem_settings, $idstudent]);
     return $stmt->fetchColumn() >= 1;
}

function is_subject_taken($idsem_settings, $idstudent, $idcurriculum) {
     $stmt = $GLOBALS['pdo']->prepare("SELECT SUM(total_student_sched) FROM 
                                             (SELECT COUNT(*) AS total_student_sched FROM student_sched
                                             INNER JOIN sched USING(idsched)
                                             INNER JOIN curriculum USING(idcurriculum)
                                             WHERE student_sched.idsem_settings = ? 
                                             AND student_sched.idstudent = ?
                                             AND curriculum.idcurriculum = ?
                                             GROUP BY idcurriculum
                                             UNION ALL
                                             SELECT COUNT(*) AS total_student_sched FROM tmp_student_sched
                                             INNER JOIN sched USING(idsched)
                                             INNER JOIN curriculum USING(idcurriculum)
                                             WHERE tmp_student_sched.idsem_settings = ? 
                                             AND tmp_student_sched.idstudent = ?
                                             AND curriculum.idcurriculum = ?
                                        GROUP BY idcurriculum) AS tmp;");
     $stmt->execute([$idsem_settings, $idstudent, $idcurriculum, $idsem_settings, $idstudent, $idcurriculum]);
     return $stmt->fetchColumn();
}

function is_valid_queuer($idstudent, $idfaculty) {
     $stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM student                      
                                        INNER JOIN (SELECT * FROM faculty
		                            INNER JOIN faculty_pef_res USING(idfaculty)) AS tmp USING(idcourse)
                                        WHERE student.idstudent = ?
                                        AND tmp.idfaculty = ?;");
               
     $stmt->execute([$idstudent, $idfaculty]);
     return $stmt->fetchColumn();
     //if return 0, not valid queuer
}

function is_valid_approver($idstud_sched, $idfaculty) {    
	$stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) 
     FROM sched 
     INNER JOIN student_sched USING(idsched)
     INNER JOIN curriculum USING(idcurriculum)
     INNER JOIN curriculum_name USING(idcurriculum_name)
     INNER JOIN (course INNER JOIN faculty USING(iddept)) ON course.idcourse = curriculum_name.idcourse
     WHERE student_sched.idstudent_sched=?
     AND faculty.idfaculty=?;");
     
     $stmt->execute([$idstud_sched, $idfaculty]);
     return $stmt->fetchColumn();
     //if return 0, not valid approver
}

function is_class_full($idsem_settings, $idsched, $idcurriculum, $idsection) {
     if(get_class_full_settings($idsem_settings) == 0) { /*======Subject Full==========================*/
          //$student = $GLOBALS['pdo']->prepare('SELECT COUNT(*) FROM student_sched WHERE idsched = ? AND is_adviser_approved = 1');
         
           //===Count Subject in student_sched
          $student = $GLOBALS['pdo']->prepare('SELECT COUNT(*) FROM student_sched WHERE idsched = ? AND idsem_settings = ?;');
          $student->execute([$idsched, $idsem_settings]);
          $total_student = $student->fetchColumn();
          
          //===Count Subject in tmp_student_sched
          $student = $GLOBALS['pdo']->prepare('SELECT COUNT(*) FROM tmp_student_sched WHERE idsched = ? AND idsem_settings = ?;');
          $student->execute([$idsched, $idsem_settings]);
          
          //===Add results of student_sched and tmp_student_sched
          $total_student =  $total_student + $student->fetchColumn();
          
          if($total_student >= get_subject_size($idsched)) {
               return 1;
          }          

     }else{ /*======Room Full==========================*/

          $stmt = $GLOBALS['pdo']->prepare("SELECT idroom, idsched FROM sched WHERE idcurriculum = ? AND idsection = ?;");
          $stmt->execute([$idcurriculum, $idsection]);

          foreach($stmt as $row) {
               $room = $GLOBALS['pdo']->prepare('SELECT COUNT(*) FROM student_sched WHERE idsched = ? AND is_chair_approved = 1');
               $room->execute([$row['idsched']]);
               $room_size = $room->fetchColumn();

               $room_size++;

               if(($room_size) > get_room_size($row['idroom'])) {
                    return 2;
                    break;                   
               }
          }
     }
     return 0;
}
function has_selected_sched($idstudent, $idsem_settings) {
     
     $stmt = $GLOBALS['pdo']->prepare("SELECT idstudent_sched FROM tmp_student_sched WHERE idsem_settings = ? AND idstudent = ?;");          
     $stmt->execute([$idsem_settings, $idstudent]);           
     return $stmt->rowCount();
}

function has_first_adviser_approved($idstudent, $idsem_settings) {
     $stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM queue_to_approve WHERE idstudent = ? AND idsem_settings = ? AND approver > 0");
     $stmt->execute([$idstudent, $idsem_settings]);
     $row = $stmt->fetchColumn();
	return $row;
}

function is_onqueue_for_approval_q($idqueue_to_approve, $idsem_settings) {
     $stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM queue_to_approve WHERE idqueue_to_approve = ? AND idsem_settings = ? AND approver > 0");
     $stmt->execute([$idqueue_to_approve, $idsem_settings]);
     $row = $stmt->fetchColumn();
	return $row;
}

function is_onqueue_for_approval_idstudent($idstudent, $idsem_settings) {
     $stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM queue_to_approve WHERE idstudent = ? AND idsem_settings = ? AND approver > 0");
     $stmt->execute([$idstudent, $idsem_settings]);
     $row = $stmt->fetchColumn();
	return $row;
}

function is_first_advised($idstudent, $idsem_settings) {
     $stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM student_sched WHERE idstudent = ? AND idsem_settings = ? AND is_adviser_approved = 1");
     $stmt->execute([$idstudent, $idsem_settings]);
     $row = $stmt->fetchColumn();
	return $row;
}

function is_first_advised_q($idqueue_to_approve, $idsem_settings) {
     $stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM student_sched WHERE idqueue_to_approve = ? AND idsem_settings = ? AND is_adviser_approved = 1");
     $stmt->execute([$idqueue_to_approve, $idsem_settings]);
     $row = $stmt->fetchColumn();
	return $row;
}

function is_second_advised($idstudent, $idsem_settings) {
     $stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM student_sched WHERE idstudent = ? AND idsem_settings = ? AND is_adviser_approved = 1 AND is_chair_approved = 1");
     $stmt->execute([$idstudent, $idsem_settings]);
     $row = $stmt->fetchColumn();
	return $row;
}

function is_second_advised_q($idqueue_to_approve, $idsem_settings) {
     $stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM student_sched WHERE idqueue_to_approve = ? AND idsem_settings = ? AND is_adviser_approved = 1 AND is_chair_approved = 1");
     $stmt->execute([$idqueue_to_approve, $idsem_settings]);
     $row = $stmt->fetchColumn();
	return $row;
}

function is_registration_inc($col, $idstudent) {
     $stmt = $GLOBALS['pdo']->prepare("SELECT $col FROM student WHERE idstudent = ?");
     $stmt->execute([$idstudent]);
     $col = $stmt->fetchColumn();
     if ($col==""){$col=null;}
     return $col;
}

function get_responsibility($idfaculty) {
     $stmt = $GLOBALS['pdo']->prepare("SELECT course.section_prefix FROM course INNER JOIN faculty_pef_res USING(idcourse) WHERE idfaculty = ?");
	$stmt->execute([$idfaculty]);
     $res = '';    
     foreach($stmt as $row) {
          $res .= $row['section_prefix']. " | ";
     }
     $res = substr($res,0,-3);
	return $res;
}

function is_infaculty_responsibility($idcourse, $idfaculty){
     $stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM faculty_pef_res WHERE idfaculty=? AND idcourse=?");
     $stmt->execute([$idfaculty, $idcourse]);
     $row = $stmt->fetchColumn();
	return $row;
}

function get_idq($idstudent, $idsem_settings) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT idqueue FROM queue WHERE idstudent = ? AND idsem_settings = ?;");
	$stmt->execute([$idstudent, $idsem_settings]);
	$row = $stmt->fetchColumn();
	return $row;
}

function is_encoded($idstudent, $idsem_settings) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM queue WHERE idstudent = ? AND idsem_settings = ? AND stat=1;");
	$stmt->execute([$idstudent, $idsem_settings]);
	$row = $stmt->fetchColumn();
	return $row;
}

function is_inqueue_to_approve($idstudent, $idsem_settings) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM queue_to_approve WHERE idstudent = ? AND idsem_settings = ?;");    
     
	$stmt->execute([$idstudent, $idsem_settings]);
	$row = $stmt->fetchColumn();
	return $row;
}

function is_inqueue_to_approve_for_adviser($idstudent, $idsem_settings, $approver) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM queue_to_approve WHERE idstudent = ? AND idsem_settings = ? AND approver = ?;");    
     
	$stmt->execute([$idstudent, $idsem_settings, $approver]);
	$row = $stmt->fetchColumn();
	return $row;
}

function is_inqueue_to_approve_for_adviser_q($idqueue_to_approve, $idsem_settings, $approver) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM queue_to_approve WHERE idqueue_to_approve = ? AND idsem_settings = ? AND approver = ?;");    
     
	$stmt->execute([$idqueue_to_approve, $idsem_settings, $approver]);
	$row = $stmt->fetchColumn();
	return $row;
}

function is_inqueue($idstudent, $idsem_settings, $iddept) {//encoder
	$stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM queue WHERE idstudent = ? AND idsem_settings = ? AND iddept = ?;");
	$stmt->execute([$idstudent, $idsem_settings, $iddept]);
	$row = $stmt->fetchColumn();
	return $row;
}

function is_inqueue_q($idqueue_to_approve, $idsem_settings, $iddept) {//encoder
	$stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) FROM queue WHERE idqueue_to_approve = ? AND idsem_settings = ? AND iddept = ?;");
	$stmt->execute([$idqueue_to_approve, $idsem_settings, $iddept]);
	$row = $stmt->fetchColumn();
	return $row;
}

function get_idsem_settings() {
	$stmt = $GLOBALS['pdo']->query("SELECT idsem_settings FROM sem_settings WHERE is_open=1");	
	$row = $stmt->fetch();
	return $row['idsem_settings'];
}

function get_pef_status($idsem_settings, $col) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT IFNULL(".$col.",0) AS res FROM sem_settings WHERE idsem_settings = ?");
	$stmt->execute([$idsem_settings]);
	$row = $stmt->fetch();
	return $row['res'];
}

function get_class_full_settings($idsem_settings) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT class_full FROM sem_settings WHERE idsem_settings = ?");
	$stmt->execute([$idsem_settings]);
	$row = $stmt->fetch();
	return $row['class_full'];
}

function get_idcourse($idstudent) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT idcourse FROM student WHERE idstudent = ?");
	$stmt->execute([$idstudent]);
	$row = $stmt->fetch();
	return $row['idcourse'];
}

function get_idcourse_from_q($idq) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT idcourse FROM student WHERE idstudent = (SELECT idstudent FROM queue_to_approve WHERE idqueue_to_approve = ?)");
	$stmt->execute([$idq]);
	$row = $stmt->fetch();
	return $row['idcourse'];
}

function get_student_cp($idstudent) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT cp FROM student WHERE idstudent = ?");
	$stmt->execute([$idstudent]);
	$row = $stmt->fetch();
	return $row['cp'];
}

function get_student_cp_from_q($idq) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT cp FROM student WHERE idstudent = (SELECT idstudent FROM queue_to_approve WHERE idqueue_to_approve = ?)");
	$stmt->execute([$idq]);
	$row = $stmt->fetch();
	return $row['cp'];
}

function get_student_course($idstudent) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT CONCAT(course.course_name, ' [',
                                                                                CASE student.yl 
                                                                                WHEN 0 THEN '1ST YR'
                                                                                WHEN 1 THEN '2ND YR'
                                                                                WHEN 2 THEN '3RD YR'
                                                                                WHEN 3 THEN '4TH YR'
                                                                                WHEN 4 THEN '5TH YR' END,']') AS course_year  FROM student INNER JOIN course USING(idcourse) WHERE student.idstudent = ?");
	$stmt->execute([$idstudent]);
	$row = $stmt->fetch();
	return $row['course_year'];
}

function get_student_course_from_q($idq) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT CONCAT(course.course_name, ' [',
                                                                                CASE student.yl 
                                                                                WHEN 0 THEN '1ST YR'
                                                                                WHEN 1 THEN '2ND YR'
                                                                                WHEN 2 THEN '3RD YR'
                                                                                WHEN 3 THEN '4TH YR'
                                                                                WHEN 4 THEN '5TH YR' END,']') AS course_year  FROM student INNER JOIN course USING(idcourse) WHERE student.idstudent = (SELECT idstudent FROM queue_to_approve WHERE idqueue_to_approve = ?)");
	$stmt->execute([$idq]);
	$row = $stmt->fetch();
	return $row['course_year'];
}

function is_subject_exist($idstudent, $idsem_settings, $idcurriculum) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) AS row_found FROM student_sched WHERE idstudent = ? AND idsem_settings = ? AND idsched IN (SELECT idsched FROM sched WHERE idcurriculum = ?);");
	$stmt->execute([$idstudent,$idsem_settings,$idcurriculum,]);
	
	$row = $stmt->fetchColumn();
	
	return $row;
}


function is_sched_exist($idstudent, $idsem_settings, $idcurriculum, $idsection) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) AS row_found FROM student_sched WHERE idstudent = ? AND idsem_settings = ? AND idsection = ? AND idsched IN (SELECT idsched FROM sched_complete WHERE idcurriculum = ? AND idsection = ?);");
	$stmt->execute([$idstudent,$idsem_settings,$idsection,$idcurriculum,$idsection]);
	
	$row = $stmt->fetchColumn();
	
	return $row;
}

function is_sched_exist_in_tmp_sched($idstudent, $idsem_settings, $idcurriculum, $idsection) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) AS row_found FROM tmp_student_sched WHERE idstudent = ? AND idsem_settings = ? AND idsection = ? AND idsched IN (SELECT idsched FROM sched_complete WHERE idcurriculum = ? AND idsection = ?);");
	$stmt->execute([$idstudent,$idsem_settings,$idsection,$idcurriculum,$idsection]);
	
	$row = $stmt->fetchColumn();
	
	return $row;
}

function get_room_size($idroom) {
	$stmt = $GLOBALS['pdo']->prepare('SELECT size FROM room WHERE idroom = ?;');
	$stmt->execute([$idroom]);
	$row = $stmt->fetchColumn();
	
	return $row;
}

function get_subject_size($idsched) {
	$stmt = $GLOBALS['pdo']->prepare('SELECT size FROM sched WHERE idsched = ?;');
	$stmt->execute([$idsched]);
	$row = $stmt->fetchColumn();
	
	return $row;
}

function has_survey($idstudent) {
	$stmt = $GLOBALS['pdo']->prepare('SELECT COUNT(*) FROM survey WHERE idstudent = ?;');
	$stmt->execute([$idstudent]);
	$row = $stmt->fetchColumn();
	
	return $row;
}

function get_student_name($idstudent) {
	$stmt = $GLOBALS['pdo']->prepare('SELECT UPPER(CONCAT(fname,\' \',lname)) FROM student WHERE idstudent = ?;');
	$stmt->execute([$idstudent]);
	$row = $stmt->fetchColumn();
	
	return $row;
}
function get_student_name_from_q($idq) {
	$stmt = $GLOBALS['pdo']->prepare('SELECT UPPER(CONCAT(fname,\' \',lname)) FROM student WHERE idstudent = (SELECT idstudent FROM queue_to_approve WHERE idqueue_to_approve = ?);');
	$stmt->execute([$idq]);
	$row = $stmt->fetchColumn();
	
	return $row;
}

function get_faculty_name($idfaculty) {
	$stmt = $GLOBALS['pdo']->prepare('SELECT UPPER(CONCAT(fname,\' \',lname)) FROM faculty WHERE idfaculty = ?;');
	$stmt->execute([$idfaculty]);
	$row = $stmt->fetchColumn();
	
	return $row;
}

function get_queue_stat_q($idqueue_to_approve,$idsem_settings, $iddept) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT (CASE stat 
												WHEN 0 THEN '<strong class=\"text-warning\">IN QUEUE...</strong>'
												WHEN 1 THEN '<strong class=\"text-success\">OFFICIALLY ENCODED.</strong>'
												WHEN 2 THEN '<strong class=\"text-danger\">ISSUE FOUND. SEE ENCODER.</strong>'					
												END) final_stat
										FROM queue
										WHERE idqueue_to_approve = ?										
										AND idsem_settings = ?
										AND iddept = ?");
	$stmt->execute([$idqueue_to_approve, $idsem_settings, $iddept]);
	if ($stmt->rowCount() > 0) {
		$row = $stmt->fetchColumn();
	}else{
		$row = '<strong class="text-danger">NOT IN QUEUE...</strong>';
	}
		
	return $row;
}

function get_queue_stat($idstudent,$idsem_settings, $iddept) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT (CASE stat 
												WHEN 0 THEN '<strong class=\"text-warning\">IN QUEUE...</strong>'
												WHEN 1 THEN '<strong class=\"text-success\">OFFICIALLY ENCODED.</strong>'
												WHEN 2 THEN '<strong class=\"text-danger\">ISSUE FOUND. SEE ENCODER.</strong>'					
												END) final_stat
										FROM queue
										WHERE idstudent = ?										
										AND idsem_settings = ?
										AND iddept = ?");
	$stmt->execute([$idstudent, $idsem_settings, $iddept]);
	if ($stmt->rowCount() > 0) {
		$row = $stmt->fetchColumn();
	}else{
		$row = '<strong class="text-danger">NOT IN QUEUE...</strong>';
	}
		
	return $row;
}

function get_q_stat($idqueue) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT (CASE stat 
												WHEN 0 THEN '<strong class=\"text-warning\">[IN QUEUE]</strong>'
												WHEN 1 THEN '<strong class=\"text-success\">[OFFICIALLY ENCODED]</strong>'
												WHEN 2 THEN '<strong class=\"text-danger\"><br>ISSUE FOUND. <br>PLS WAIT WHILE WE ARE FIXING. <br>WE\'LL TEXT YOU IF NECESSARY.</strong>'					
												END) final_stat
										FROM queue
										WHERE idqueue = ?");
	$stmt->execute([$idqueue]);
	if ($stmt->rowCount() > 0) {
		$row = $stmt->fetchColumn();
	}else{
		$row = '<strong class="text-danger">NOT IN QUEUE...</strong>';
	}
		
	return $row;
}

function get_currently_serving_queue($idsem_settings, $idcourse) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT queue.idqueue					
				FROM queue
 				inner join course using(iddept)
				WHERE queue.stat = 0
				AND queue.idsem_settings= ?
                    AND course.idcourse = ?
				ORDER BY idqueue ASC
				LIMIT 1;");
	$stmt->execute([$idsem_settings, $idcourse]);
	if ($stmt->rowCount() > 0) {
		$row = $stmt->fetchColumn();
	}else{
		$row = '<strong class="text-danger">NONE</strong>';
	}	
	return $row;
}

function get_student_queue_q($idqueue_to_approve, $idsem_settings) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT queue.idqueue					
				FROM queue 				
				WHERE queue.idqueue_to_approve = ?
				AND queue.idsem_settings=?				
				ORDER BY idqueue ASC;");
	
	$stmt->execute([$idqueue_to_approve, $idsem_settings]);	
	$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
	return $row;
}

function get_student_queue($idstudent, $idsem_settings) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT queue.idqueue					
				FROM queue 				
				WHERE queue.idstudent = ?
				AND queue.idsem_settings=?				
				ORDER BY idqueue ASC;");
	
	$stmt->execute([$idstudent, $idsem_settings]);	
	$row = $stmt->fetchAll(PDO::FETCH_ASSOC);
	return $row;
}
function get_idnumber($idstudent) {
     $stmt = $GLOBALS['pdo']->prepare('SELECT idnumber FROM student WHERE idstudent = ?;');
	$stmt->execute([$idstudent]);
	$row = $stmt->fetchColumn();
     return $row;
}

function is_idnumber_exist($idnumber) {
	$stmt = $GLOBALS['pdo']->prepare('SELECT COUNT(*) FROM student WHERE idnumber = ?;');
	$stmt->execute([$idnumber]);
	$row = $stmt->fetchColumn();
	
	return $row;
}

function get_idstudent($idnumber) {
	$stmt = $GLOBALS['pdo']->prepare('SELECT idstudent FROM student WHERE idnumber = ?;');
	$stmt->execute([$idnumber]);
	$row = $stmt->fetchColumn();
	if ($row==''){$row=null;}
	return $row;
}

/*Viewing of Total Units*/
function get_total_student_units($idsem_settings, $idstudent, $role, $idqueue_to_approve) {
	$qry = "SELECT IFNULL(SUM(total_unit), 0) FROM 
						(SELECT total_unit FROM (SELECT sched.idsched,
                             sched.idcurriculum, 
                             section.section_name, 
                                get_merged_sched(sched.idsched) AS subj, 
                                curriculum.description, 
                                IF(curriculum.lab_unit = 0, curriculum.lec_unit,CONCAT(curriculum.lec_unit,'/',curriculum.lab_unit)) AS unit,
                                (CASE sched.days
                              WHEN 0 THEN 'MON' 
                              WHEN 1 THEN 'TUE'
                              WHEN 2 THEN 'WED'
                              WHEN 3 THEN 'THU' 
                              WHEN 4 THEN 'FRI' 
                              WHEN 5 THEN 'SAT' 
                              WHEN 6 THEN 'SUN' END) AS week_day_name, 
                                    CONCAT(TIME_FORMAT(sched.s_time, '%h:%i'),'-',TIME_FORMAT(sched.e_time, '%h:%i')) AS class_time, 
                                     room.room, 
                                     UPPER(CONCAT(faculty.lname, ', ',faculty.fname)) AS faculty_name,
                                     (curriculum.lec_unit+curriculum.lab_unit) AS total_unit
                                        FROM sched
                             LEFT JOIN faculty USING(idfaculty) 
                             INNER JOIN curriculum USING(idcurriculum) 
                             INNER JOIN curriculum_name USING(idcurriculum_name) 
                             INNER JOIN room USING(idroom) 
                             INNER JOIN section USING(idsection) 
                                        WHERE sched.is_merge = 0
                             ORDER BY faculty.lname ASC,
                               sched.idsection ASC, 
                               sched.idcurriculum ASC) AS tmp 
                            INNER JOIN student_sched USING(idsched) 
                            WHERE idsem_settings = ? AND idstudent = ? AND idqueue_to_approve = ?
							GROUP BY idcurriculum, idsection, idcourse) as TMP;";
	if ($role==1) { /*Adviser*/
		$qry = "SELECT IFNULL(SUM(total_unit),0) FROM 
						(SELECT total_unit FROM (SELECT sched.idsched,
                             sched.idcurriculum, 
                             section.section_name, 
                                get_merged_sched(sched.idsched) AS subj, 
                                curriculum.description, 
                                IF(curriculum.lab_unit = 0, curriculum.lec_unit,CONCAT(curriculum.lec_unit,'/',curriculum.lab_unit)) AS unit,
                                (CASE sched.days
                              WHEN 0 THEN 'MON' 
                              WHEN 1 THEN 'TUE'
                              WHEN 2 THEN 'WED'
                              WHEN 3 THEN 'THU' 
                              WHEN 4 THEN 'FRI' 
                              WHEN 5 THEN 'SAT' 
                              WHEN 6 THEN 'SUN' END) AS week_day_name, 
                                    CONCAT(TIME_FORMAT(sched.s_time, '%h:%i'),'-',TIME_FORMAT(sched.e_time, '%h:%i')) AS class_time, 
                                     room.room, 
                                     UPPER(CONCAT(faculty.lname, ', ',faculty.fname)) AS faculty_name,
                                     (curriculum.lec_unit+curriculum.lab_unit) AS total_unit
                                        FROM sched
                             LEFT JOIN faculty USING(idfaculty) 
                             INNER JOIN curriculum USING(idcurriculum) 
                             INNER JOIN curriculum_name USING(idcurriculum_name) 
                             INNER JOIN room USING(idroom) 
                             INNER JOIN section USING(idsection) 
                                        WHERE sched.is_merge = 0
                             ORDER BY faculty.lname ASC,
                               sched.idsection ASC, 
                               sched.idcurriculum ASC) AS tmp 
                            INNER JOIN student_sched USING(idsched) 
                            WHERE idsem_settings = ? AND idstudent = ? 
                            AND idqueue_to_approve = ?
							AND is_adviser_approved = 1 
							GROUP BY idcurriculum, idsection, idcourse) as TMP;";
	}elseif($role==2) /*Encoder & Chairperson*/
		$qry = "SELECT IFNULL(SUM(total_unit),0) FROM 
						(SELECT total_unit FROM (SELECT sched.idsched,
                             sched.idcurriculum, 
                             section.section_name, 
                                get_merged_sched(sched.idsched) AS subj, 
                                curriculum.description, 
                                IF(curriculum.lab_unit = 0, curriculum.lec_unit,CONCAT(curriculum.lec_unit,'/',curriculum.lab_unit)) AS unit,
                                (CASE sched.days
                              WHEN 0 THEN 'MON' 
                              WHEN 1 THEN 'TUE'
                              WHEN 2 THEN 'WED'
                              WHEN 3 THEN 'THU' 
                              WHEN 4 THEN 'FRI' 
                              WHEN 5 THEN 'SAT' 
                              WHEN 6 THEN 'SUN' END) AS week_day_name, 
                                    CONCAT(TIME_FORMAT(sched.s_time, '%h:%i'),'-',TIME_FORMAT(sched.e_time, '%h:%i')) AS class_time, 
                                     room.room, 
                                     UPPER(CONCAT(faculty.lname, ', ',faculty.fname)) AS faculty_name,
                                     (curriculum.lec_unit+curriculum.lab_unit) AS total_unit
                                        FROM sched
                             LEFT JOIN faculty USING(idfaculty) 
                             INNER JOIN curriculum USING(idcurriculum) 
                             INNER JOIN curriculum_name USING(idcurriculum_name) 
                             INNER JOIN room USING(idroom) 
                             INNER JOIN section USING(idsection) 
                                        WHERE sched.is_merge = 0
                             ORDER BY faculty.lname ASC,
                               sched.idsection ASC, 
                               sched.idcurriculum ASC) AS tmp 
                            INNER JOIN student_sched USING(idsched) 
                            WHERE idsem_settings = ? AND idstudent = ? 
							AND is_chair_approved = 1 
                                   AND idqueue_to_approve = ?
							GROUP BY idcurriculum, idsection, idcourse) as TMP;";
	$stmt = $GLOBALS['pdo']->prepare($qry);

$stmt->execute([$idsem_settings, $idstudent, $idqueue_to_approve]);
$unit_result = $stmt->fetchColumn();
return $unit_result;
}

function get_total_subject_units($idsem_settings, $idstudent, $role) {
	$qry = "SELECT IFNULL(SUM(total_unit), 0) FROM 
						(SELECT 
                                   curriculum.lec_unit +  curriculum.lab_unit AS total_unit
                         FROM            
                              (SELECT sched.idsched,					
                                   get_course_code(sched.idsched) AS code1,
                                   section.idsem_settings,
                                   sched.days,
                                   sched.idcurriculum,
                                   sched.idroom,
                                   sched.idsection, 
                                   sched.idfaculty,
                                   sched.s_time,
                                   sched.e_time,					
                                   get_merged_sched(sched.idsched) AS subj 
                              FROM sched LEFT join sched_merged ON sched.idsched = sched_merged.merged_with
                              INNER JOIN section ON sched.idsection = section.idsection
                              WHERE section.idsem_settings = ?) AS tmp
                              INNER JOIN curriculum USING(idcurriculum) 
                         INNER JOIN room USING(idroom) 
                         INNER JOIN section USING(idsection)
                         INNER JOIN student_sched
                         ON tmp.idsched = student_sched.idsched
                         AND tmp.idsem_settings = student_sched.idsem_settings                        
                         WHERE student_sched.idstudent = ?  
                         GROUP BY tmp.idcurriculum) AS q1;";
	if ($role==1) { /*Adviser*/
		$qry = "SELECT IFNULL(SUM(total_unit), 0) FROM 
          (SELECT 
               curriculum.lec_unit +  curriculum.lab_unit AS total_unit
     FROM            
          (SELECT sched.idsched,					
               get_course_code(sched.idsched) AS code1,
               section.idsem_settings,
               sched.days,
               sched.idcurriculum,
               sched.idroom,
               sched.idsection, 
               sched.idfaculty,
               sched.s_time,
               sched.e_time,					
               get_merged_sched(sched.idsched) AS subj 
          FROM sched LEFT join sched_merged ON sched.idsched = sched_merged.merged_with
          INNER JOIN section ON sched.idsection = section.idsection
          WHERE section.idsem_settings = ?) AS tmp
          INNER JOIN curriculum USING(idcurriculum) 
     INNER JOIN room USING(idroom) 
     INNER JOIN section USING(idsection)
     INNER JOIN student_sched
     ON tmp.idsched = student_sched.idsched
     AND tmp.idsem_settings = student_sched.idsem_settings                        
     WHERE student_sched.idstudent = ?
     AND student_sched.is_adviser_approved = 1  
     GROUP BY tmp.idcurriculum) AS q1;";
	}elseif($role==2) /*Encoder & Chairperson*/
		$qry = "SELECT IFNULL(SUM(total_unit), 0) FROM 
          (SELECT 
               curriculum.lec_unit +  curriculum.lab_unit AS total_unit
     FROM            
          (SELECT sched.idsched,					
               get_course_code(sched.idsched) AS code1,
               section.idsem_settings,
               sched.days,
               sched.idcurriculum,
               sched.idroom,
               sched.idsection, 
               sched.idfaculty,
               sched.s_time,
               sched.e_time,					
               get_merged_sched(sched.idsched) AS subj 
          FROM sched LEFT join sched_merged ON sched.idsched = sched_merged.merged_with
          INNER JOIN section ON sched.idsection = section.idsection
          WHERE section.idsem_settings = ?) AS tmp
          INNER JOIN curriculum USING(idcurriculum) 
     INNER JOIN room USING(idroom) 
     INNER JOIN section USING(idsection)
     INNER JOIN student_sched
     ON tmp.idsched = student_sched.idsched
     AND tmp.idsem_settings = student_sched.idsem_settings                        
     WHERE student_sched.idstudent = ?
     AND student_sched.is_chair_approved =  1
     GROUP BY tmp.idcurriculum) AS q1;";
	$stmt = $GLOBALS['pdo']->prepare($qry);

$stmt->execute([$idsem_settings, $idstudent]);
$unit_result = $stmt->fetchColumn();
return $unit_result;
}
?>