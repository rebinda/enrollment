<?php
     include_once("connect.php");
     $idstudent = $_POST['idstudent'];
     $idsem_settings = $_POST['idsem_settings'];
     $seen_stat = $_POST['seen_stat'];

     if($seen_stat==1) {
          $stmt = $pdo->prepare("UPDATE queue SET is_seen_encoded = 1 WHERE idstudent = ? AND idsem_settings = ?");
          
     }else{
          $stmt = $pdo->prepare("UPDATE queue SET is_seen_issue = 1 WHERE idstudent = ? AND idsem_settings = ?");
     }
     $stmt->execute([$idstudent, $idsem_settings]);
?>