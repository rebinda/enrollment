<?php
     include_once("function.php");
     //approver = 0 | Adviser
     //approver = 1 | Chair
     //approver = 2 | Done
     session_start();          
     if (!isset($_SESSION['is_faculty_login'])) {die("<div class=\"alert alert-danger\"><i class=\"fas fa-exclamation\" style=\"font-size:24px;\"></i> <strong> YOU NEED TO LOGIN!</strong></div>");}
     
     $idfaculty = $_SESSION[ 'idfaculty' ];
     $approver = $_POST['approver'];
     $idnumber = $_POST['idnumber'];
     $idsem_settings = $_POST['idsem_settings'];
     $idstudent = get_idstudent($idnumber);
     $iddept = $_POST['iddept'];
     $from_q = $_POST['from_queue'];
     $res["value"] = 0;
     $res["message"] = "";
     if(is_valid_queuer($idstudent, $idfaculty)==0) {          
          $res["message"]= '<span class="text-danger">Your RESPONSIBILITY does not support this action.</span>';
          $res["value"] = 1;
          echo json_encode($res);
          exit();
     }
     if($from_q>0) {
          if (is_inqueue_to_approve_for_adviser_q($from_q, $idsem_settings, $approver)>0) {
               $res["value"] = 1;
               $res["message"]= '<span class="text-danger">Already in Queue.</span>';
          }else{
               if ($approver==1) {
                    if (!is_first_advised_q($from_q, $idsem_settings) > 0) {
                         $res["value"] = 1;
                         $res["message"]= '<span class="text-danger">Needs to have 1 or more APPROVED subjects.</span>';
                    }else if(is_onqueue_for_approval_q($from_q, $idsem_settings) > 0) {
                         $res["value"] = 1;
                         $res["message"]= '<span class="text-danger">Already in Queue.</span>';
                    }else{                         
                         $stmt = $pdo->prepare("UPDATE queue_to_approve SET approver = 1, date_approved = now() WHERE idqueue_to_approve = ? AND idsem_settings = ?");
                         $stmt->execute([$from_q, $idsem_settings]);                                        
                         $res["message"]= '<span class="text-success">Subjects have been forwarded to Chairperson for Approval.</span>';
                    }               
               }else if($approver==2) {
                    if (!is_second_advised_q($from_q, $idsem_settings) > 0) {
                         $res["value"] = 1;
                         $res["message"]= '<span class="text-danger">Needs to have 1 or more APPROVED subjects.</span>';
                    }else if(is_inqueue_q($from_q, $idsem_settings, $iddept) > 0) {
                         //$stmt = $pdo->prepare("UPDATE queue_to_approve SET approver = 2 WHERE idstudent = ? AND idsem_settings = ?");
                         //$stmt->execute([$idstudent, $idsem_settings]);
                         $res["value"] = 1;
                         $res["message"]= '<span class="text-danger">Already in Queue.</span>';
                    }else{
                         
                         $stmt = $pdo->prepare("UPDATE queue_to_approve SET approver = 2, date_approved = now() WHERE idqueue_to_approve = ? AND idsem_settings = ?");
                         $stmt->execute([$from_q, $idsem_settings]);                                             
                         $stmt = $pdo->prepare("INSERT INTO queue(idstudent, idqueue_to_approve, idsem_settings, iddept) VALUES(?, ?, ?, ?);");
                         $stmt->execute([$idstudent, $from_q, $idsem_settings, $iddept]);
                         $res["message"]= '<span class="text-success">QUEUE was successfully SENT</span>';
                    } 
               }
          }
     }else{
          if (is_inqueue_to_approve_for_adviser($idstudent, $idsem_settings, $approver)>0) {
               $res["value"] = 1;
               $res["message"]= '<span class="text-danger">Already in Queue.</span>';
          }else{
               if ($approver==1) {
                    if (!is_first_advised($idstudent, $idsem_settings) > 0) {
                         $res["value"] = 1;
                         $res["message"]= '<span class="text-danger">Needs to have 1 or more APPROVED subjects.</span>';                         
                    }else if(is_onqueue_for_approval_idstudent($idstudent, $idsem_settings) > 0) {
                         $res["value"] = 1;
                         $res["message"]= '<span class="text-danger">Already in Queue.</span>';                         
                    }else{                         
                         $stmt = $pdo->prepare("UPDATE queue_to_approve SET approver = 1, date_approved = now() WHERE idstudent = ? AND idsem_settings = ?");
                         $stmt->execute([$idstudent, $idsem_settings]);                                        
                         $res["message"]= '<span class="text-success">Subjects have been forwarded to Chairperson for Approval.</span>';                    
                    }               
               }else if($approver==2) {
                    if (!is_second_advised($idstudent, $idsem_settings) > 0) {
                         $res["value"] = 1;
                         $res["message"]= '<span class="text-danger">Needs to have 1 or more APPROVED subjects.</span>';
                    }else if(is_inqueue($idstudent, $idsem_settings, $iddept) > 0) {
                         //$stmt = $pdo->prepare("UPDATE queue_to_approve SET approver = 2 WHERE idstudent = ? AND idsem_settings = ?");
                         //$stmt->execute([$idstudent, $idsem_settings]);
                         $res["value"] = 1;
                         $res["message"]= '<span class="text-danger">Already in Queue.</span>';
                    }else{
                         
                         $stmt = $pdo->prepare("UPDATE queue_to_approve SET approver = 2, date_approved = now() WHERE idstudent = ? AND idsem_settings = ?");
                         $stmt->execute([$idstudent, $idsem_settings]);                                             
                         $stmt = $pdo->prepare("INSERT INTO queue(idstudent, idsem_settings, idqueue_to_approve, iddept) 
                         SELECT ?, ?, idqueue_to_approve, ? FROM queue_to_approve WHERE idstudent = ? AND idsem_settings = ?;");
                         $stmt->execute([$idstudent, $idsem_settings, $iddept, $idstudent, $idsem_settings]);
                         $res["message"]= '<span class="text-success">QUEUE was successfully SENT.</span>';                    
                    } 
               }          
          }
     }
    echo json_encode($res);
?>