<?php
include_once("connect.php");

$idstudent = $_POST['idstudent'];
$idsem_settings = $_POST['idsem_settings'];
$idcurriculum = $_POST['idcurriculum'];
$source = $_POST['source'];
$qry = '';
if($source =='tmp_sched') {
     $qry = "DELETE FROM tmp_student_sched WHERE idstudent = ? AND idsem_settings = ? AND idsched IN (SELECT idsched FROM sched WHERE idcurriculum = ? );";
}else{
     $qry = "DELETE FROM student_sched WHERE idstudent = ? AND idsem_settings = ? AND idsched IN (SELECT idsched FROM sched WHERE idcurriculum = ? );";                         
}
$stmt = $pdo->prepare($qry);
//Delete Student Subject
$stmt->execute([$idstudent,$idsem_settings,$idcurriculum,]);

//Check if there are remaining subjects
$student = $pdo->prepare("SELECT * FROM student_sched WHERE idstudent = ? AND idsem_settings = ?");
$student->execute([$idstudent, $idsem_settings]);

//If no subjects then remove student from queue_to_approve
if($student->rowCount() == 0) {
     $stmt = $pdo->prepare('DELETE FROM queue_to_approve WHERE idstudent=? AND idsem_settings=?');
     $stmt->execute([$idstudent, $idsem_settings]);
     $stmt = $pdo->prepare('DELETE FROM queue WHERE idstudent=? AND idsem_settings=?');
     $stmt->execute([$idstudent, $idsem_settings]);
}


?>