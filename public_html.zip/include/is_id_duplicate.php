<?php
include_once("connect.php");
$idnumber = $_POST["idnumber"];
$stmt = $pdo->prepare("SELECT COUNT(*) AS row_found FROM student WHERE idnumber = ?");
$stmt->execute([$idnumber]);

$found = $stmt->fetch();

echo $found['row_found'];
	
?>