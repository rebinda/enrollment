<?php
include_once("connect.php");
$idsem_settings = $_POST['idsem_settings'];
$yl = $_POST['yl'];
$idcourse = $_POST['idcourse'];
$stmt = $pdo->prepare("SELECT * FROM section WHERE idsem_settings = ? AND yl = ? AND idcourse = ? AND isopen = 1 ORDER BY section_name ASC;");
$stmt->execute([$idsem_settings, $yl, $idcourse]);

foreach($stmt as $row) {
	echo '<option value="'.$row['idsection'].'">'.$row['section_name'].'</option>';
}
?>