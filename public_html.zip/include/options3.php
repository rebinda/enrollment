<div class="form-check">
	<label class="form-check-label">
		<input class="form-check-input" name="ans<?php echo $question['idsurvey_question']; ?>" type="radio" value="1">
		Less than 1 min.
	</label>
</div>
<div class="form-check">
	<label class="form-check-label">
		<input class="form-check-input" name="ans<?php echo $question['idsurvey_question']; ?>" type="radio" value="2">
		Less than 2 min.
	</label>
</div>
<div class="form-check">
	<label class="form-check-label">
		<input class="form-check-input" name="ans<?php echo $question['idsurvey_question']; ?>" type="radio" value="3">
		Less than 3 min.
	</label>
</div>
<div class="form-check">
	<label class="form-check-label">
		<input class="form-check-input" name="ans<?php echo $question['idsurvey_question']; ?>" type="radio" value="4">
		Less than 4 min.
	</label>
</div>
<div class="form-check">
	<label class="form-check-label">
		<input class="form-check-input" name="ans<?php echo $question['idsurvey_question']; ?>" type="radio" value="5">
		Less than 5 min.
	</label>
</div>
