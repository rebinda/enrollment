<?php
	include_once("function.php");
	
	$idcurriculum = $_POST['idcurriculum'];
	$idsection = $_POST['idsection'];
	$idsem_settings = $_POST['idsem_settings'];
	$idstudent = $_POST['idstudent'];

	/*$idcurriculum =2;
	$idsection =7;
	$idsem_settings = 1;
	$idstudent = 1;
*/

	$day = get_pef_status($idsem_settings, 'is_day_visible');
	$time =  get_pef_status($idsem_settings, 'is_time_visible');

	$output = '';

	$stud_sched = $pdo->prepare("SELECT * FROM sched WHERE idcurriculum = ? AND idsection=?;");	
	$stud_sched->execute([$idcurriculum, $idsection]);	

	
	/*$qry = "SELECT * FROM (SELECT sched.idsched,
                             sched.idcurriculum, 
                             section.section_name, 
                                get_merged_sched(sched.idsched) AS subj, 
                                curriculum.description, 
                                IF(curriculum.lab_unit = 0, curriculum.lec_unit,CONCAT(curriculum.lec_unit,'/',curriculum.lab_unit)) AS unit,
                                sched.days,
                                sched.s_time,
                                sched.e_time,
                                (CASE sched.days
                              WHEN 0 THEN 'MON' 
                              WHEN 1 THEN 'TUE'
                              WHEN 2 THEN 'WED'
                              WHEN 3 THEN 'THU' 
                              WHEN 4 THEN 'FRI' 
                              WHEN 5 THEN 'SAT' 
                              WHEN 6 THEN 'SUN' END) AS week_day_name, 
                                    CONCAT(TIME_FORMAT(sched.s_time, '%h:%i'),'-',TIME_FORMAT(sched.e_time, '%h:%i')) AS class_time, 
                                     room.room                                   
                                        FROM sched                              
                             INNER JOIN curriculum USING(idcurriculum)                               
                             INNER JOIN room USING(idroom) 
                             INNER JOIN section USING(idsection) 
                                        WHERE sched.is_merge = 0
                             ORDER BY sched.idsection ASC, 
                               sched.idcurriculum ASC) AS tmp 
                            INNER JOIN student_sched USING(idsched) 
                            WHERE idsem_settings = :idsem_settings AND idstudent = :idstudent
							AND days = :days AND
							(((:s_time < s_time AND :s_time < e_time) AND (:e_time > s_time AND :e_time <= e_time)) 
							OR
							((:s_time >= s_time AND :s_time < e_time) AND (:e_time > s_time AND :e_time >= e_time))
							OR
							((:s_time BETWEEN s_time AND e_time) AND (:e_time BETWEEN s_time AND e_time))
							OR
							((:s_time < s_time AND :s_time < e_time) AND (:e_time > s_time AND :e_time > e_time)));"; */
	$qry = "SELECT * FROM schedule 
			INNER JOIN student_sched USING(idsched) 
			WHERE idsem_settings = :idsem_settings AND idstudent = :idstudent
			AND days = :days AND
			(((:s_time < s_time AND :s_time < e_time) AND (:e_time > s_time AND :e_time <= e_time)) 
			OR
			((:s_time >= s_time AND :s_time < e_time) AND (:e_time > s_time AND :e_time >= e_time))
			OR
			((:s_time BETWEEN s_time AND e_time) AND (:e_time BETWEEN s_time AND e_time))
			OR
			((:s_time < s_time AND :s_time < e_time) AND (:e_time > s_time AND :e_time > e_time)));";
		
	$pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES,true);
	$stmt = $pdo->prepare($qry);	

	foreach($stud_sched as $stud_sched_row) 
	{				
		$stmt->execute(['idsem_settings'=>$idsem_settings,
							  'idstudent'=>$idstudent,
							  'days'=>$stud_sched_row['days'],
							  's_time'=> $stud_sched_row['s_time'],							
							  'e_time'=> $stud_sched_row['e_time']]);				
			
		foreach($stmt as $row) {						
			if ($day==0 && $time==1) {
				$output .= '<div id="overlapping_sched"><span class="text-success">'.$row['subj'].'</span><span class="text-muted">'.$row['class_time'].'</span></div>';
			}elseif($day==1 && $time==0) {
				$output .= '<div id="overlapping_sched"><span class="text-success">'.$row['subj'].'</span><span class="text-warning">'.$row['week_day_name'].'</span></div>';
			}elseif($day==1 && $time==1) {
				$output .= '<div id="overlapping_sched"><span class="text-success">'.$row['subj'].'</span><span class="text-warning">'.$row['week_day_name'].'</span><span class="text-muted">'.$row['class_time'].'</span></div>';
			}elseif($day==0 && $time==0) {
				$output .= '<div id="overlapping_sched"><span class="text-success">'.$row['subj'].'</span></div>';
			}
		}
	}

	$pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);	
	echo $output;						
?>