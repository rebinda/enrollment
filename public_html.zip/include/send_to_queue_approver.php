<?php
     $idstudent = $_POST['idstudent'];
     $idsem_settings = $_POST['idsem_settings'];
     $idcourse = $_POST['idcourse'];
     include_once("function.php");

     /*if (!has_survey($idstudent)) {
          echo '<span class="text-danger">TAKE SURVEY before submitting your subject(s).</span>';
     }else {*/
          if (has_selected_sched($idstudent, $idsem_settings) == 0) {
               echo '<span class="text-danger">SELECT 1 or more subjects.</span>';
          //}elseif(is_inqueue_to_approve($idstudent, $idsem_settings)>0) {
          //    echo '<span class="text-danger">Already in Queue.</span>';
          }elseif (has_submitted_courses($idsem_settings, $idstudent)==true) {
               echo '<span class="text-danger">Only 1 PEF is allowed.</span>';
          }else{
			  
			 // $stmt = $pdo->prepare("SELECT * FROM tmp_student_sched 
//                                        WHERE idstudent = ? AND idsem_settings = ?");
//			  $stmt->execute([$idstudent, $idsem_settings]);
//			  foreach($stmt as $row){
//				  
//			  }
			  //=====================================================================
			  
               $stmt = $pdo->prepare("INSERT INTO queue_to_approve(idstudent, idsem_settings) 
               VALUES(?, ?)");
               $stmt->execute([$idstudent, $idsem_settings]);
               $last_id = $pdo->lastInsertId();
              			   			  
               $stmt = $pdo->prepare("INSERT INTO student_sched(idstudent, idsched, idsem_settings,idsection, idcourse, idqueue_to_approve) 
                                        SELECT idstudent, idsched, idsem_settings,idsection, idcourse, ? FROM tmp_student_sched 
                                        WHERE idstudent = ? AND idsem_settings = ?");
               $stmt->execute([$last_id, $idstudent, $idsem_settings]);    
               
               $stmt = $pdo->prepare("DELETE FROM tmp_student_sched 
                                        WHERE idstudent = ? AND idsem_settings = ?");
               $stmt->execute([$idstudent, $idsem_settings]);
               
               echo '<span class="text-success">Your subject(s) was sent to QUEUE for approval.</span>';
          }
     //}
?>