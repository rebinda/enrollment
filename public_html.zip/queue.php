<?php
include_once("include/function.php");
session_start();

$iddept = $_SESSION['iddept'];

if (!isset($_SESSION['is_faculty_login'])) {
	header( "Location: /pef" );
}

$idfaculty = $_SESSION[ 'idfaculty' ];
$idsem_settings = get_idsem_settings();
$is_single_encoding = get_pef_status($idsem_settings,'is_single_encoding');

if ( $_SERVER[ "REQUEST_METHOD" ] == "POST" ) {
	if ( isset( $_POST[ "action" ] ) ) {
		if ( $_POST[ 'action' ] == "Logout" ) {
			header( "Location: include/logout.php" );
		} elseif ( $_POST[ 'action' ] == "Back" ) {
			header( "Location: advising.php" );		
		}
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>ENCODING QUEUE</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="fontawesome5.9.0/css/all.min.css" rel="stylesheet">
<link href="bootstrap-4.3.1/css/bootstrap.min.css" rel="stylesheet">
<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="bootstrap-4.3.1/js/bootstrap.min.js"></script>
<script src="js/devicedetector-min.js"></script>
<script src="js/moment.min.js"></script>
	<script>
		$(function() {
			$('[data-toggle="tooltip"]').tooltip();
               var btn;
               var t = moment().format('YYYY-MM-DD');               
               $("#date_encoded").val(t);
               
               $("#date_encoded" ).keydown(function(e) {
				if (e.which == 13) {
					$("#show_encoded").click();
				}
			});
               
			show_queue(0);               
               $("#show_encoded").click(function () {
				$(this).html( '<i class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></i>' );
				show_queue(1);
                    show_queue(2);
			});
			function show_queue(ntab) {				
				$.ajax({					
					method:"POST",
					url:"include/onqueue.php",
					data:{idsem_settings:$("#semester").val(), 
                               tab:ntab, 
                               date_encoded: $("#date_encoded").val(),
                               iddept:<?php echo $iddept; ?>},
                         beforeSend: function(e){
                              $("#show_encoded").html( '<i class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></i>' );
                         },
					success: function(e) {						
						if (ntab == 0) {
							$("#onqueue").html(e);
						} else if(ntab==1) {
							$("#encoded").html(e);
						} else if(ntab==2) {
							$("#with_issues").html(e);
						}						
						
						$("#table_queue .row_sched").hide();
						$("#table_encoded .row_sched").hide();
						$("#table_with_issues .row_sched").hide();
												
						bind_show_sched();
						show_sched("#table_queue");												
						show_sched("#table_encoded");												
						show_sched("#table_with_issues");
						
						bind_done();
						bind_not_encoded();
						fix_media_compatibility();
                              $("#show_encoded").html( '<i class="fas fa-search fa-fw"></i>' );
					}
				});
			}
			
			function show_sched(table) {				
				$.ajax({
					method:"POST",
					url:"include/queue_sched.php",
					data:{idq:$(table+" input[name=idq]").val(),
                               idstudent: $(table+" input[name=idstudent]").val(),                               
						 idsem_settings:$("#semester").val()},
					success:function(e) {						
						$(table+" div.table_sched").html(e);						
						merge_common_rows(table+ " div.table_sched .sched_block tbody tr");
					}
				});
			}

			function process_queue(mybtn, id, s, tab) {
				$.ajax({
						method: "POST",
						async: true,						
						url: "include/encoded.php",						
						data: {idq: id,
							  stat: s,
							  caller:0},
                              beforeSend: function(e) {
                                   $("#msgbox").modal('hide');
                                   mybtn.attr("Disabled","True");
                                   mybtn.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>');
                              },
						success: function(e) {                                     
							show_queue(tab);
						}
					});								
			}
			
               $("#btnYes").click(function() {                                       
                    if ($(this).attr("tag") == '0') {                         
                         process_queue(btn, btn.parent().parent().find("input[name=idq]").val(),1,0);
                         btn.closest('tr').next().remove();
                         btn.closest('tr').remove();
                    }else if($(this).attr("tag") == '1') {                         
                         process_queue(btn, btn.parent().parent().find("input[name=idq]").val(),1,2);
                         btn.closest('tr').next().remove();
                         btn.closest('tr').remove();
                    }else if($(this).attr("tag") == '2') {                         
                         process_queue(btn, btn.parent().parent().find("input[name=idq]").val(),2,0);
                         btn.closest('tr').next().remove();
                         btn.closest('tr').remove();
                    }else if($(this).attr("tag") == '3') {
                         process_queue(btn, btn.parent().parent().find("input[name=idq]").val(),2,1);
                         btn.closest('tr').next().remove();
                         btn.closest('tr').remove();
                    }                    
               });
                    
		  	function bind_done() {
				$("#table_queue button[name=done]").click(function(e) {
                         btn = $(this);
                         $("#msgbox_content").html('MARKING AS ENCODED...');
                         $("#btnYes").attr("tag","0");
                         $("#msgbox").modal('show');					
				});
				$("#table_with_issues button[name=done]").click(function(e) {
                         btn = $(this);
                         $("#msgbox_content").html('MARKING AS ENCODED...');
                         $("#btnYes").attr("tag","1");
                         $("#msgbox").modal('show');					
				});
			}
			
			function bind_not_encoded() {
				$("#table_queue button[name=unencoded]").click(function(e) {					
                         btn = $(this);
                         $("#msgbox_content").html('<span class="text-danger">MARKING AS WITH ISSUES...</span>');
                         $("#btnYes").attr("tag","2");
                         $("#msgbox").modal('show');					
				});
				
				$("#table_encoded button[name=unencoded]").click(function(e) {
                         btn = $(this);
                         $("#msgbox_content").html('<span class="text-danger">MARKING AS WITH ISSUES...</span>');
                         $("#btnYes").attr("tag","3");
                         $("#msgbox").modal('show');					
				});				
			}
			
			function fix_media_compatibility() {
				if (deviceDetector.device == 'desktop') {
					$("table").find("br").each(function (e){
						$(this).replaceWith(" ");
					});					
				}else{
					$( "table .title" ).hide();
					$( "table .room" ).hide();
					$( "table .unit" ).hide();
				}				
			}
			
			function bind_show_sched() {
				<?php
					if($is_single_encoding==1){
						echo '$("#table_queue .clickable").click(function (e) {					
									$("#table_queue .row_sched").toggle();
								});';
					}else{
						echo '$("#table_queue .clickable").click(function (e) {					
					$(this).parent().prevAll("tr").css("background-color","white");
					$(this).parent().css("background-color","lightcyan");
					$(this).parent().nextAll().not($(this).parent()).nextAll("tr").css("background-color","white");
					
					$(this).parent().prevAll(".row_sched").hide();									
					var t = $(this).parent().next();                     
					t.toggle();
					
					$(this).parent().nextAll().not(t).nextAll(".row_sched").hide();
					
					$.ajax({
						method:"POST",
						url:"include/queue_sched.php",                              
						data:{idq: $(this).find("input[name=idq]").val(),
                                   idqueue_to_approve: $(this).find("input[name=idqueue_to_approve]").val(),
                                   idstudent: $(this).find("input[name=idstudent]").val(),
							 idsem_settings:$("#semester").val()},
                              beforeSend: function(e) {
                                   t.find("div.table_sched").html(\'<div class="text-center"><span class="spinner-border spinner-border-lg" role="status" aria-hidden="true"></span></div>\');
                              },
						success:function(e) {						
							t.find("div.table_sched").html(e);
							merge_common_rows(t.find("div.table_sched .sched_block tbody tr"))
						}
					});						
				});';
					}
				?>		
							
				
				$("#table_encoded .clickable").click(function (e) {
					$(this).parent().prevAll('tr').css("background-color",'white');
					$(this).parent().css("background-color",'lightcyan');
					$(this).parent().nextAll().not($(this).parent()).nextAll("tr").css("background-color",'white');
					
					$(this).parent().prevAll(".row_sched").hide();									
					var t = $(this).parent().next();
                         t.toggle();
					/*t.toggle({
						speed:'fast',
						easing:'linear'
					});*/
					
					$(this).parent().nextAll().not(t).nextAll(".row_sched").hide();
					
					$.ajax({
						method:"POST",
						url:"include/queue_sched.php",                              
						data:{idq: $(this).find("input[name=idq]").val(),
                                    idqueue_to_approve: $(this).find("input[name=idqueue_to_approve]").val(),
                                    idstudent: $(this).find("input[name=idstudent]").val(),
							 idsem_settings:$("#semester").val()},
                              beforeSend: function(e) {
                                   t.find("div.table_sched").html('<div class="text-center"><span class="spinner-border spinner-border-lg" role="status" aria-hidden="true"></span></div>');
                              },
						success:function(e) {						
							t.find("div.table_sched").html(e);
							merge_common_rows(t.find("div.table_sched .sched_block tbody tr"))
						}
					});										
				});
				
				$("#table_with_issues .clickable").click(function (e) {					
					$(this).parent().prevAll('tr').css("background-color",'white');
					$(this).parent().css("background-color",'lightcyan');
					$(this).parent().nextAll().not($(this).parent()).nextAll("tr").css("background-color",'white');
					
					$(this).parent().prevAll(".row_sched").hide();
					
					var t = $(this).parent().next();							
					t.toggle();
					
					$(this).parent().nextAll().not(t).nextAll(".row_sched").hide();
					
					$.ajax({
						method:"POST",
						url:"include/queue_sched.php",
						data:{idq: $(this).find("input[name=idq]").val(),
                                    idqueue_to_approve: $(this).find("input[name=idqueue_to_approve]").val(),
                                    idstudent: $(this).find("input[name=idstudent]").val(),
							 idsem_settings:$("#semester").val()},
                              beforeSend: function(e) {
                                   t.find("div.table_sched").html('<div class="text-center"><span class="spinner-border spinner-border-lg" role="status" aria-hidden="true"></span></div>');
                              },
						success:function(e) {						
							t.find("div.table_sched").html(e);
							merge_common_rows(t.find("div.table_sched .sched_block tbody tr"))
						}
					});	
					
				});
			}
			
			function merge_common_rows( table ) {
				var $prev_row = $( table ).find( "td" );
				var prev_idcurr = $prev_row.parent().find( "input[name=idcurriculum]" ).val();
				var $row = $( table ).next().find( "td" );
				var idcurr = $row.parent().find( "input[name=idcurriculum]" ).val();
				var rowspan = 1;
				$( table ).each( function () {
					var code = $row.eq( 0 ).text();
					var description = $row.eq( 1 ).text();
					var units = $row.eq( 2 ).text();
					var day = $row.eq( 3 ).text();
					var class_time = $row.eq( 4 ).text();
					var room = $row.eq( 5 ).text();
					var prev_code = $prev_row.eq( 0 ).text();
					var prev_description = $prev_row.eq( 1 ).text();
					var prev_units = $prev_row.eq( 2 ).text();
					var prev_day = $prev_row.eq(3).text();
					var prev_class_time = $prev_row.eq( 4 ).text();
					var prev_room = $prev_row.eq( 5 ).text();
					if ( idcurr == prev_idcurr ) {
						rowspan++;
						if ( code == prev_code ) {
							$row.eq( 0 ).remove();							
							$prev_row.eq( 0 ).attr( 'rowspan', rowspan );						
						}
						if ( description == prev_description ) {
							$row.eq( 1 ).remove();
							$prev_row.eq( 1 ).attr( 'rowspan', rowspan );
						}
						if ( units == prev_units ) {
							$row.eq(2 ).remove();
							$prev_row.eq( 2 ).attr( 'rowspan', rowspan );
						}
						if ( day == prev_day ) {
							$row.eq( 3 ).remove();
							$prev_row.eq(3 ).attr( 'rowspan', rowspan );
						}
						if ( class_time == prev_class_time ) {
							$row.eq( 4 ).remove();
							$prev_row.eq( 4 ).attr( 'rowspan', rowspan );
						}
						if ( room == prev_room ) {
							$row.eq( 5 ).remove();
							$prev_row.eq( 5 ).attr( 'rowspan', rowspan );
						}
						$row = $row.parent().next().find( "td" );
						idcurr = $row.parent().find( "input[name=idcurriculum]" ).val();
					} else {
						rowspan = 1;
						$prev_row = $row.parent().find( "td" );
						$row = $row.parent().next().find( "td" );
						prev_idcurr = $prev_row.parent().find( "input[name=idcurriculum]" ).val();
						idcurr = $row.parent().find( "input[name=idcurriculum]" ).val();
					}
				});
				fix_media_compatibility();				
			}
			
			$('.nav-tabs a[href="#onqueue"]').click(function(e) {
				show_queue(0);						 
			});
		
			$('.nav-tabs a[href="#encoded"]').click(function(e) {
				show_queue(1);						 
			});
			$('.nav-tabs a[href="#with_issues"]').click(function (e){
				show_queue(2);						 
			});
		});
	</script>
</head>
	<style>
		#table_queue thead th, #table_encoded thead th, #table_with_issues thead th {
			padding: 10px;
			color: white;
			background-color: dimgray
		}
		#table_queue td, #table_encoded td, #table_with_issues td {
			padding: 7px 0 7px 0;			
		}	
		
		.sched_block thead th {
			padding: 10px;
			color: white;
			background-color:#110764;
		}
		.sched_block td {
			background-color:#F0F0F0;
			padding: 3px 0 3px 0;
			font-size: .8em;
		}
		.jumbotron {
			padding: 30px 0 0px 0
		}
		.top_most {
			background-color:lightcyan;
			padding: 10px 0 10px 0;
			color:green;
			font-weight: bold;
		}
		#table_queue tr td:hover, #table_encoded tr:hover, #table_with_issues tr:hover{
			cursor:pointer;
			background-color:lightcyan;
			color:green;
		}
          .input-group {
			margin-bottom: 5px;
		}
	</style>
<body>
	<div class="jumbotron text-center" style="margin-bottom: 0px;">
		<h2>ENCODING QUEUE</h2>
		<div class="alert alert-info">
			<p style="margin: 0; padding: 0;"><strong>Welcome</strong>
				<?php echo get_faculty_name($idfaculty); ?> </p>
			<p style="margin: 0; padding: 0;">
				<small class="text-muted">[ENCODER]</small>
			</p>
               <p style="margin: 0; padding: 0;"><small>RESPONSIBILITY:</small> <span class="badge badge-danger"><?php echo get_responsibility($idfaculty); ?></span></p>
		</div>
	</div>
	
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<div class="input-group">
					<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Semester"><span class="input-group-text"><i class="far fa-calendar-alt fa-fw"></i></span>
					</div>
					<select id="semester" class="form-control">
						<?php
						$stmt = $pdo->query( "SELECT sem_settings.idsem_settings, 
								CONCAT(sy.s_year,'-',sy.e_year, ' ', UPPER(sem.sem)) AS sy_period 
								FROM sem_settings
								INNER JOIN sem USING(idsem) 
								INNER JOIN sy USING(idsy)
								WHERE sem_settings.is_open=1;" );

						foreach ( $stmt as $row ) {
							echo '<option value="' . $row[ 'idsem_settings' ] . '">' . $row[ 'sy_period' ] . '</option>';
						}
						?>
					</select>
				</div>
                    
			</div>
               <div class="col-md-6">
				<div class="input-group">
                         <div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Date Encoded"> <span class="input-group-text"> <i class="far fa-calendar-alt fa-fw"></i> </span>
							</div>                         
                         <input name="date_encoded" class="form-control" type="date" id="date_encoded" placeholder="mm/dd/yyyy">
					<div class="input-group-append"><button class="btn btn-primary" id="show_encoded"><i class="fas fa-search fa-fw"></i></button>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<hr>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<!-- Nav pills -->
				<ul class="nav nav-tabs">
				  <li class="nav-item">
					<a class="nav-link active" data-toggle="tab" href="#onqueue">QUEUE</a>
				  </li>
				  <li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#encoded">ENCODED</a>
				  </li>
				  <li class="nav-item">
					<a class="nav-link" data-toggle="tab" href="#with_issues">WITH ISSUES</a>
				  </li>
				</ul>
				<!-- Tab panes -->
				<div class="tab-content" style="margin-top:10px;">
					<div class="tab-pane container active" id="onqueue"></div>				 
					<div class="tab-pane container fade" id="encoded"></div>
					<div class="tab-pane container fade" id="with_issues"></div>
				</div>
			</div>			
		</div>
		
		<div style="margin-bottom: 80px;"></div>
		<div class="fixed-bottom" style="background-color: lightgray;">
			<div class="text-center" style="padding:5px 0px 5px 0px;">
				<form id="form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
					<button class="btn btn-success" type="submit" name="action" value="Back"><i class="fas fa-arrow-left"></i> Back</button>
					<button class="btn btn-danger" type="submit" name="action" value="Logout"><i class="fas fa-power-off"></i> Logout</button>
				</form>
			</div>
		</div>
		<div class="modal fade" id="msgbox" tabindex="-1" role="dialog" aria-labelledby="msgbox" aria-hidden="true">
			<div class="modal-dialog modal-sm modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="msgbox_title">ARE YOU SURE?</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
					</div>
					<div class="modal-body">
						<div id="msgbox_content"></div>
					</div>
					<div class="modal-footer"> 
                              <button type="button" class="btn btn-success" tag="0" id="btnYes">Yes</button>
                              <button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
					</div>
				</div>
			</div>
		</div>
	</div>	
</body>
</html>