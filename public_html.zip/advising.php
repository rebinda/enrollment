<?php
include_once( 'include/function.php' );
session_start();
$role = $_SESSION['role'];
$idsem_settings = get_idsem_settings();
if (!isset($_SESSION[ 'is_faculty_login'])) {
	header("Location: /pef");
}

$idfaculty = $_SESSION[ 'idfaculty' ];
$iddept = $_SESSION['iddept'];
if ($_SERVER["REQUEST_METHOD"] == "POST" ) {
	if (isset($_POST["action"])) {
		if (strtoupper($_POST[ 'action' ]) == strtoupper("Logout")) {
               $_SESSION['is_faculty_login']=false;
			header("Location: include/logout.php");              
		} elseif (strtoupper($_POST[ 'action' ]) == strtoupper("Open")) {
			header( "Location: queue.php" );		
		} elseif(strtoupper($_POST['action']) == strtoupper("New")) {
               header("Location: new.php");
          }
	}
}

$approver = '';
if($role==1){$approver=0;}if($role==3){$approver=1;}
?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="fontawesome5.9.0/css/all.min.css" rel="stylesheet">
	<link href="bootstrap-4.3.1/css/bootstrap.min.css" rel="stylesheet">
     <link href="scrollbar/jquery.mCustomScrollbar.css" rel="stylesheet">     
     <link href="css/cb.css" rel="stylesheet">     
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="bootstrap-4.3.1/js/bootstrap.min.js"></script>
	<script src="js/devicedetector-min.js"></script>     
     <script src="scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
	<title>
		<?php 		
		if($role==1 || $role==3) {
			echo 'PEF Advising';
		} 
		else{
			echo 'CS PEF';
		}?>
	</title>
	<script>
		$(function() {
         var from_q = 0;
         var selbutton = '';
         var mybtn = '';
          $(".msg_sent").mCustomScrollbar();              
                         
         $("#queue").click(function(e) {
             mybtn = $(this);
             selbutton = e.target.id;
         });
         $("#open_queue").click(function(e) {
             selbutton = e.target.id;
         });
         $("#queue_to_chair").click(function(e) {
             mybtn = $(this);
             selbutton = e.target.id;
         });           
          $("#chat").click(function(e) {
               mybtn = $(this);
               selbutton = e.target.id;
          });          
               
         $("#form").submit(function(e) {              
             if (selbutton == 'queue_to_chair') {
                 selbutton = '';
                 change_queue_approver(1);
                 e.preventDefault();
             }
              if (selbutton == 'open_queue') {
                 showForQueueApproval();
                 selbutton = '';
                 e.preventDefault();
             } 
              if (selbutton == 'queue') {
                 selbutton = '';
                 change_queue_approver(2);
                 e.preventDefault();
             }
              if (selbutton == 'chat') {
                    selbutton = '';
                    $("#chatbox").show();
                    get_sent_messages();
                    $('.msg_sent').animate({scrollTop: $('.msg_sent')[0].scrollHeight}, "fast");
                    e.preventDefault();
             }                           
                            
         });
         $('[data-toggle="tooltip"]').tooltip();
         $("#idnumber").keydown(function(e) {
             if (e.which == 13) {
                 $("#show_sched").html('<i class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></i>'); /*how_sched( "#show_sched", 0, 0);*/
                 show_stud_subject_for_approval();
             }
         });
         $("#show_sched").click(function() {
             $(this).html('<i class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></i>');
             show_stud_subject_for_approval();
         });

         function show_stud_subject_for_approval() {             
              $(".div_cbo").hide();                    
             $.ajax({
                 url: "include/stud_subject_to_approve.php",
                 method: "POST",
                 data: {
                     idsem_settings: $("#semester").val(),
                     idstudent: $("#idnumber").val(),
                 },
                 beforeSend: function(e) {},
                 success: function(e) {
                     $("#show_sched").attr("class", "btn btn-primary");
                     $("#show_sched").html('<i class="fas fa-search fa-fw"></i>');
                     $("#approval h5").html("PEF");
                     $("#approval_content").css({
                         "overflow-y": "scroll",
                         "height": "230px"
                     });
                     $("#approval_content").html(e);
                     bindShowSchedForApproval();
                     bindCancelSchedForApproval();                     
                     $("#approval").modal("show");
                 }
             });
         }

         function show_sched(my_button, show_type, idq) {
             /*show_type 0 - search | 1 - approve_all | 2-disapprove_all | 3 - approve/disapprove_single*/
             $(my_button).attr("disabled", "true");
             $.ajax({
                 method: "POST",
                 async: true,
                 url: "include/stud_sched_for_advising.php",
                 data: {
                     idqueue_to_approve: idq,
                     idsem_settings: $("#semester").val(),
                     idnumber: $("#idnumber").val(),
                     role: <?php echo $role; ?> ,
                     iddept : <?php echo $iddept; ?>
                 },
                 beforeSend: function() {},
                 success: function(e) {
                     $("#sched_result").html("");
                     $("#sched_result").html(e);
                     add_click_handler();
                     remove_subject_confirmation(); /*=================*/
                     merge_common_rows("#sched_block tbody tr");
                     $(my_button).removeAttr("disabled");
                     if (show_type == 0) {
                         $("#show_sched").attr("class", "btn btn-primary");
                         $("#show_sched").html('<i class="fas fa-search fa-fw"></i>');
                     } else if (show_type == 1) {
                         $(my_button).html('<i class="far fa-thumbs-up fa-lg"> <small>APPROVE ALL</small>');
                     } else if (show_type == 2) {
                         $(my_button).html('<i class="far fa-thumbs-down fa-lg"> <small>DISAPPROVE ALL</small>');
                     }
                     bind_approve_all();
                     bind_disapprove_all();
                     update_btn_approve_all();                     
                 }
             });
         }
          
          /*==============================*/
         function remove_subject_confirmation() {
               $("#sched_block td button[name=remove]").click(function() {
                    var id = $(this).parent().find("input[name=idcurriculum]").val();
                    var code = $(this).parent().parent().find("span.subj").html();
                    var arow = $(this);
                    $("#remove_subject_dialog p.reason").html('<strong><span class="text-primary">REASON: </span><span class="text-danger">You are not eligible to take </span><ins>'+$.trim(code)+'</ins><span class="text-danger">. Because...</span></strong>');
                    $("#remove_subject_msg").val("");
                    $("#remove_subject_dialog").modal("show");                    
                    
                    $("#remove_subject_dialog button.remove").click(function() {                        
                         if (!$.trim($("#remove_subject_msg").val())) {
                              $("#class_full_title").html('REQUEST DENIED...');
                              $("#class_full_content").html('<strong class="text-danger">STATE YOUR REASON</strong>');
                              $("#class_full").modal("show");
                              return;
                         }
                         $.ajax({
                               url: "include/remove_subject.php",
                               async: false,
                               method: "POST",
                               dataType: "JSON",
                               data: {idcurr: id,
                                      codes: code,
                                      message: $("#remove_subject_msg").val(),
                                      idstudent: $("#idnumber").val(),
                                      idfaculty: <?php echo $idfaculty ?>,                                      
                                      idsem_settings: $("#semester").val()                                      
                                     },
                               beforeSend: function() {
                                   $("#sched_block button").attr('disabled', true);
                                   $("#iddisapprove_all").attr('disabled', true);
                                   $("#idapprove_all").attr('disabled', true);
                               },
                               success: function(e) {                                    
                                   $("#sched_block button").removeAttr('disabled');
                                   $("#iddisapprove_all").removeAttr('disabled');
                                   $("#idapprove_all").removeAttr('disabled');
                                   $("#remove_subject_dialog .close").click();
                                   get_sent_messages();
                                   arow.parent().parent().remove();                                   
                               }
                         });
                         //show_sched($(this), 3, from_q);
                         
                    });                   
               });
          }          
          /*==============================*/                                                    
         function add_click_handler() {
             $("#sched_block td button[name=approve]").click(function() {
                 $(this).html('<i class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></i>');
                 var ope = 0;
                 if ($(this).attr('stat') == '0') {
                     ope = 1;
                     $(this).attr('stat', "1");
                 } else {
                     ope = 0;
                     $(this).attr('stat', "0");
                 }
                 $.ajax({
                     url: "include/stat_subject.php",
                     async: true,
                     method: "POST",
                     dataType: "JSON",
                     data: {
                         idsem_settings: $("#semester").val(),
                         show: 1,
                         idsection: $(this).parent().find("input[name=idsection]").val(),
                         idsched: $(this).parent().find("input[name=idsched]").val(),
                         idstud_sched: $(this).parent().find("input[name=idstud_sched]").val(),
                         idcurriculum: $(this).parent().find("input[name=idcurriculum]").val(),
                         operation: ope,
                         role: <?php echo $role; ?> ,
                         idnumber : $("#idnumber").val(),
                         idfaculty: <?php echo $idfaculty; ?>
                     },
                     beforeSend: function() {
                         $("#sched_block button").attr('disabled', true);
                         $("#iddisapprove_all").attr('disabled', true);
                         $("#idapprove_all").attr('disabled', true);
                     },
                     success: function(e) {
                         if (e.value == 1) {
                             if (e.show == 1) {
                                 $("#class_full_title").html("UNAUTHORIZED...");
                                 $("#class_full_content").html('<strong class="text-danger">THIS ACTION IS NOT SUPPORTED BY YOUR PRIVILEGE.</strong>');
                                 $("#class_full").modal("show");
                             }
                         } else if (e.value == 2) {
                             if (e.show == 1) {
                                 $("#class_full_title").html("SIZE LIMIT...");
                                 $("#class_full_content").html('<span class="text-danger">THE CLASS IS FULL.</span>');
                                 $("#class_full").modal("show");
                             }
                         }
                         show_sched($(this), 3, from_q);
                     }
                 });
             });
         }

               
         function bind_subject_details_click(table) {
             $(table + " span.subj").css({
                 "text-decoration": "underline",
                 "color": "#0000FF"
             });
             $(table + " span.subj").click(function() {
                 $.ajax({
                     url: "include/get_subj_details.php",
                     async: true,
                     method: "POST",
                     data: {
                         idsection: $(this).parent().parent().find("input[name=idsection]").val(),
                         idcurriculum: $(this).parent().parent().find("input[name=idcurriculum]").val()
                     },
                     success: function(e) {
                         $('#sub_details_content').html("");
                         $('#sub_details_content').html(e);
                         merge_table_sub_details_content("#sub_details_content table tbody tr");
                         $('#sub_details').modal('show');
                     }
                 });
             });
         }

         function fix_media_compatibility() {
             if (deviceDetector.device == 'desktop') {} else {
                 $("table .title").hide();
                 $("table .room").hide();
                 $("table .unit").hide();
             }
         }

         function merge_table_sub_details_content(table) {
             var $prev_row = $(table).find("td");
             var prev_idcurr = $prev_row.parent().find("input[name=idcurriculum]").val();
             var $row = $(table).next().find("td");
             var idcurr = $row.parent().find("input[name=idcurriculum]").val();
             var rowspan = 1;
             $(table).each(function() {
                 var description = $row.eq(0).text();
                 var units = $row.eq(1).text();
                 var room = $row.eq(2).text();
                 var prev_description = $prev_row.eq(0).text();
                 var prev_units = $prev_row.eq(1).text();
                 var prev_room = $prev_row.eq(2).text();
                 if (idcurr == prev_idcurr) {
                     rowspan++;
                     if (description == prev_description) {
                         $row.eq(0).remove();
                         $prev_row.eq(0).attr('rowspan', rowspan);
                     }
                     if (units == prev_units) {
                         $row.eq(1).remove();
                         $prev_row.eq(1).attr('rowspan', rowspan);
                     }
                     if (room == prev_room) {
                         $row.eq(2).remove();
                         $prev_row.eq(2).attr('rowspan', rowspan);
                     }
                     $row = $row.parent().next().find("td");
                     idcurr = $row.parent().find("input[name=idcurriculum]").val();
                 } else {
                     rowspan = 1;
                     $prev_row = $row.parent().find("td");
                     $row = $row.parent().next().find("td");
                     prev_idcurr = $prev_row.parent().find("input[name=idcurriculum]").val();
                     idcurr = $row.parent().find("input[name=idcurriculum]").val();
                 }
             });
         }

         function merge_common_rows(table) {
             var $prev_row = $(table).find("td");
             var prev_idcurr = $prev_row.parent().find("input[name=idcurriculum]").val();
             var $row = $(table).next().find("td");
             var idcurr = $row.parent().find("input[name=idcurriculum]").val();
             var rowspan = 1;
             $(table).each(function() {
                 var code = $row.eq(1).text();
                 var description = $row.eq(2).text();
                 var units = $row.eq(3).text();
                 var day = $row.eq(4).text();
                 var class_time = $row.eq(5).text();
                 var room = $row.eq(6).text();
                 var prev_code = $prev_row.eq(1).text();
                 var prev_description = $prev_row.eq(2).text();
                 var prev_units = $prev_row.eq(3).text();
                 var prev_day = $prev_row.eq(4).text();
                 var prev_class_time = $prev_row.eq(5).text();
                 var prev_room = $prev_row.eq(6).text();
                 if (idcurr == prev_idcurr) {
                     rowspan++;
                     $row.eq(0).remove();
                     $prev_row.eq(0).attr('rowspan', rowspan);
                     if (code == prev_code) {
                         /*$row.eq( 0 ).remove(); $prev_row.eq( 0 ).attr( 'rowspan', rowspan );*/
                         $row.eq(1).remove();
                         $prev_row.eq(1).attr('rowspan', rowspan);
                     }
                     if (description == prev_description) {
                         $row.eq(2).remove();
                         $prev_row.eq(2).attr('rowspan', rowspan);
                     }
                     if (units == prev_units) {
                         $row.eq(3).remove();
                         $prev_row.eq(3).attr('rowspan', rowspan);
                     }
                     if (day == prev_day) {
                         $row.eq(4).remove();
                         $prev_row.eq(4).attr('rowspan', rowspan);
                     }
                     if (class_time == prev_class_time) {
                         $row.eq(5).remove();
                         $prev_row.eq(5).attr('rowspan', rowspan);
                     }
                     if (room == prev_room) {
                         $row.eq(6).remove();
                         $prev_row.eq(6).attr('rowspan', rowspan);
                     }
                     $row = $row.parent().next().find("td");
                     idcurr = $row.parent().find("input[name=idcurriculum]").val();
                 } else {
                     rowspan = 1;
                     $prev_row = $row.parent().find("td");
                     $row = $row.parent().next().find("td");
                     prev_idcurr = $prev_row.parent().find("input[name=idcurriculum]").val();
                     idcurr = $row.parent().find("input[name=idcurriculum]").val();
                 }
             });
             fix_media_compatibility();
             if (deviceDetector.isMobile) {
                 if (deviceDetector.device == "phone") {
                     bind_subject_details_click(table);
                 }
             }
         }

         function bind_disapprove_all() {
             $("#iddisapprove_all").click(function(e) {
                 $("#sched_block tbody tr td button").each(function() {
                     if ($(this).attr("stat") == 1) {
                         $(this).attr('stat', "0");
                         $.ajax({
                             url: "include/stat_subject.php",
                             async: true,
                             method: "POST",
                             dataType: "JSON",
                             data: {
                                 idsem_settings: $("#semester").val(),
                                 show: 0,
                                 idsection: $(this).parent().find("input[name=idsection]").val(),
                                 idsched: $(this).parent().find("input[name=idsched]").val(),
                                 idstud_sched: $(this).parent().find("input[name=idstud_sched]").val(),
                                 idcurriculum: $(this).parent().find("input[name=idcurriculum]").val(),
                                 operation: 0,
                                 role: <?php echo $role; ?> ,
                                 idnumber : $("#idnumber").val(),
                                 idfaculty: <?php echo $idfaculty; ?>
                             },
                             beforeSend: function() {
                                 $("#iddisapprove_all").html('<i class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></i> <small>DISAPPROVING..</small>');
                                 $("#iddisapprove_all").attr("disabled", "true");
                                 $("#idapprove_all").attr("disabled", "true");
                                 $("#queue_to_chair").attr("disabled", "true");
                                 $("#sched_block button").attr('disabled', true);
                             },
                             success: function(e) {
                                 show_sched($(this), 2, from_q);
                                 $("#queue").removeAttr("disabled");
                                 $("#queue_to_chair").removeAttr("disabled");
                                 $("#iddisapprove_all").html('<i class="far fa-thumbs-down fa-lg"></i> <small>DISAPPROVE ALL</small>');
                             }
                         });
                     }
                 });
             });
         }

         function bind_approve_all() {
             $("#idapprove_all").click(function(e) {
                 $(this).html('<i class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></i> <small>APPROVING..</small>');
                 var total_approve = $("button[stat='1']").length;
                 var total_subj = $("button[stat]").length;
                 var total_closed_subject = 0;
                 var total_cant_approved = 0;
                 $("#sched_block tbody tr td button").each(function() {
                     if ((total_approve + total_closed_subject) == total_subj) {
                         $("#idapprove_all").html('<i class="far fa-thumbs-up fa-lg"></i> <small>APPROVE ALL</small>');
                     }
                     if ($(this).attr("stat") == 0) {
                         $(this).attr('stat', "1");
                         $.ajax({
                             url: "include/stat_subject.php",
                             async: true,
                             method: "POST",
                             dataType: "JSON",
                             data: {
                                 idsem_settings: $("#semester").val(),
                                 show: 0,
                                 idsection: $(this).parent().find("input[name=idsection]").val(),
                                 idsched: $(this).parent().find("input[name=idsched]").val(),
                                 idstud_sched: $(this).parent().find("input[name=idstud_sched]").val(),
                                 idcurriculum: $(this).parent().find("input[name=idcurriculum]").val(),
                                 operation: 1,
                                 role: <?php echo $role; ?> ,
                                 idnumber : $("#idnumber").val(),
                                 idfaculty: <?php echo $idfaculty; ?>
                             },
                             beforeSend: function() {
                                 $("#queue").attr("disabled", "true");
                                 $("#queue_to_chair").attr("disabled", "true");
                                 $("#iddisapprove_all").attr("disabled", "true");
                                 $("#idapprove_all").attr("disabled", "true");
                                 $("#sched_block button").attr('disabled', true);
                                 $("#idapprove_all").html('<i class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></i> <small>APPROVING..</small>');
                             },
                             success: function(e) {
                                 if (from_q == 0) {
                                     show_sched($(this), 1, 0);
                                 } else {
                                     show_sched($(this), 1, from_q);
                                 }
                                 $("#idapprove_all").html('<i class="far fa-thumbs-up fa-lg"></i> <small>APPROVE ALL</small>');
                                 $("#queue").removeAttr("disabled");
                                 $("#queue_to_chair").removeAttr("disabled");
                             }
                         });
                     }
                 });
             });
         }

          function get_sent_messages() { 
               var scroll_pos = $(".msg_sent").scrollTop(); 
               $.ajax({
                    url: "include/get_messages.php", 
                    async: false, 
                    method: "POST", 
                    data: {idfaculty: <?php echo $idfaculty ?>, 
                           idsem_settings: $("#semester").val()
                          }, 
                    success: function(e) { 
                         $(".msg_sent").html(e); 
                         $(".msg_sent").scrollTop(scroll_pos);
                    }
               });
          }
               
          $(".cancel").click(function() {
               $("#chatbox").hide();
               $("#chatbox textarea").val("");
          });
               
          $(".send").click(function() {
               $.ajax({
                    url: "include/send_message.php",
                    async: true,
                    method: "POST", 
                    data: {idfaculty: <?php echo $idfaculty ?>, 
                           idstudent: $("#idnumber").val(), 
                           idsem_settings: $("#semester").val(), 
                           message: $("#msg").val()
                          },
                    beforeSend: function() {
                         $(".send").html('<i class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></i> SENDING...'); 
                    }, 
                    success: function(e) { 
                         $(".send").html('SEND'); 
                         if (e!= '') { 
                              $("#class_full_title").html("SENDING FAILED..."); 
                              $("#class_full_content").html('<span class="text-danger">'+ e +'</span>');
                              $("#class_full").modal("show"); 
                              return; 
                         } 
                         $("#msg").val(''); 
                         get_sent_messages(); 
                         $('.msg_sent').animate({scrollTop: $('.msg_sent')[0].scrollHeight}, "fast"); 
                    }
               });
          });
               
         function update_btn_approve_all() {
             if ($("#sched_block tbody tr td button").length == 0) {
                 $("#idapprove_all").attr("disabled", "true");
                 $("#iddisapprove_all").attr("disabled", "true");
                 $("#idapprove_all").hide();
                 $("#iddisapprove_all").hide();
             } else {
                 $("#idapprove_all").removeAttr("disabled");
                 $("#iddisapprove_all").removeAttr("disabled");
                 $("#iddisapprove_all").show();
                 $("#idapprove_all").show();
             }
         }
          
               //================================
          $("#sel_course").change(function() {
              $("#sel_yl").trigger("change");
         });
          //================================
               
         $("#sel_yl").change(function() {
             $.ajax({
                 url: "include/get_queue_for_approval.php",
                 data: {
                     idsem_settings: $("#semester").val(),
                     sel_yl: $("#sel_yl").val(),
                     sel_course: $("#sel_course").val(),
                     approver: <?php
                     if ($approver <> '') {
                         echo $approver;
                     } else {
                         echo 0;
                     } ?>
                 },
                 async: true,
                 method: "POST",
                 dataType: "html",
                 beforeSend: function() {
                     $("#sel_yl").prop("disabled", true);
                     $("#sel_course").prop("disabled", true);
                     $("#approval_content").html('<div class="text-center"><span class="spinner-border spinner-border-lg" role="status" aria-hidden="true"></span></div>');
                 },
                 success: function(e) {
                     $("#approval h5").html("FOR APPROVAL");
                     $("#approval_content").html(e);
                     bindShowSchedForApproval();
                     $("#sel_yl").prop("disabled", false);
                     $("#sel_course").prop("disabled", false);
                     $("#approval").modal("show");
                 }
             });
         });

         function bindShowSchedForApproval() {
             $("table#for_approval button.ok").click(function() {
                 $("input#idnumber").val($(this).parent().find("input[name=idnumber]").val());
                 from_q = $(this).parent().find("input[name=idqueue_to_approve]").val(); /*$("#approval").modal("hide");*/
                 $("#approval .close").click();
                 $(this).html('<i class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></i>');
                 $("#sched_result").html('<div class="text-center"><i class="spinner-border spinner-border-lg" role="status" aria-hidden="true"></i></div>');
                 show_sched("#show_sched", 0, $(this).parent().find("input[name=idqueue_to_approve]").val());
             });
         } 
         
              //========================
          function bindCancelSchedForApproval() {
             $("table#for_approval button.cancel").click(function() {
                  var arow = $(this);
                  $("#cancel_msg").val('');                  
                 from_q = $(this).parent().find("input[name=idqueue_to_approve]").val(); /*$("#approval").modal("hide");*/
                  $("#cancel_msg_dialog").modal("show");
                  $("#cancel_msg_dialog button.ok").click(function() {
                     $.ajax({
                              url: "include/cancel_queue.php",
                              async: true,
                              method: "POST",                             
                              data: {idfaculty: <?php echo $idfaculty ?>,
                              idstudent: arow.parent().parent().find("[name=idstudent]").val(),
                              idsem_settings: $("#semester").val(),
                              message: $("#cancel_msg").val(),
                              idqueue_to_approve: from_q
                              },
                              beforeSend: function() {
                                   $("#cancel_msg_dialog button.ok").html('<i class="spinner-border spinner-border-sm"></i>');
                              },
                              success: function(e) {
                                   $("#cancel_msg_dialog button.ok").html('OK');
                                   if (e!= '') {
                                        $("#class_full_title").html("UNABLE TO REMOVE");
                                        $("#class_full_content").html('<span class="text-danger">'+ e +'</span>');
                                        $("#class_full").modal("show");
                                        return;
                                   }
                                   arow.parent().parent().remove();
                                   $("#cancel_msg_dialog").modal("hide");                                                                      
                                   get_sent_messages();
                                   $('.msg_sent').animate({scrollTop: $('.msg_sent')[0].scrollHeight}, "fast");
                              }
                     });  
                  });                 
             });
         }
          //==========================    
          <?php
         if ($role == 1 || $role == 3) {              
             echo 'function showForQueueApproval() { $(".div_cbo").show(); $(".div_btn").hide(); $.ajax({url: "include/get_queue_for_approval.php", data: { idsem_settings: $( "#semester" ).val(), approver:'.$approver.
             ' }, async: true, method: "POST", dataType: "html", beforeSend: function() { $("#open_queue i").addClass("spinner-border spinner-border-sm"); }, success: function(e) { $( "#approval h5").html("FOR APPROVAL"); $( "#approval_content" ).css({"overflow-y":"scroll","height":"230px"}); $( "#approval_content" ).html(e); bindShowSchedForApproval(); bindCancelSchedForApproval(); $("#open_queue i").removeClass("spinner-border spinner-border-sm"); $( "#approval" ).modal("show"); } }); };';              
             echo 'function change_queue_approver(approber) { $.ajax({ url: "include/update_queue_approver.php", data: { approver:approber, idnumber: $( "#idnumber" ).val(), idsem_settings: $("#semester").val(), from_queue: from_q, iddept: '.$iddept.
             ' }, async: false, method: "POST", dataType: "JSON", beforeSend: function(e){ mybtn.html(\'<i class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></i> Queue\'); }, success: function (e) {$( "#class_full_title" ).html("QUEUE FOR APPROVAL"); if(e.value==0){$("#sched_result").html(""); $("#idnumber").val("");} $( "#class_full_content" ).html(e.message); $( "#class_full" ).modal( "show" ); mybtn.html(\'Queue\'); } }); }';              
             echo 'function get_total_queue_for_approval(){ $.ajax({ url: "include/total_queue_for_approval.php", data: { idsem_settings: $("#semester").val(), from_queue: from_q, approver:'.$approver.
             ' }, async: true, method: "POST", dataType: "html", success: function (e) { if(e>0) {$(".total_for_approval").html(e);} else{$(".total_for_approval").html("");} get_total_queue_for_approval(); } }); }';
             echo 'get_total_queue_for_approval();';
             echo 'setInterval(get_total_queue_for_approval,3000);';
         } ?>
});
	</script>
	<style>
		thead th {
			padding: 10px;
			color: white;
			background-color: dimgray
		}
		
		.input-group {
			margin-bottom: 5px;
		}
		
		.jumbotron {
			padding: 30px 0 0px 0;
		}
          
	</style>
</head>

<body>
	<div class="jumbotron text-center" style="margin-bottom: 0px;">
		<h2>
			<?php
			if ( $role == 1 || $role == 3 ) {
				echo 'SUBJECT ADVISING';
			} else {
				echo 'CS PEF';
			}
			?>
		</h2>
		<div class="alert alert-info">
			<p style="margin: 0; padding: 0;"><strong>Welcome</strong>
				<?php echo get_faculty_name($idfaculty); ?> </p>
			<p style="margin: 0; padding: 0;">
				<small class="text-muted">
					<?php if($role==1){echo ' [ADVISER]';}elseif($role==2){echo ' [ENCODER]';}elseif($role==3){echo ' [CHAIRPERSON]';} ?>
				</small>
			</p>
               <p style="margin: 0; padding: 0;"><small>RESPONSIBILITY:</small> <span class="badge badge-danger"><?php echo get_responsibility($idfaculty); ?></span></p>
		</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<div class="input-group">
					<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Semester"><span class="input-group-text"><i class="far fa-calendar-alt fa-fw"></i></span>
					</div>
					<select id="semester" class="form-control">
						<?php
						$stmt = $pdo->query( "SELECT sem_settings.idsem_settings, 
								CONCAT(sy.s_year,'-',sy.e_year, ' ', UPPER(sem.sem)) AS sy_period 
								FROM sem_settings
								INNER JOIN sem USING(idsem) 
								INNER JOIN sy USING(idsy)
								WHERE sem_settings.is_open=1;" );

						foreach ( $stmt as $row ) {
							echo '<option value="' . $row[ 'idsem_settings' ] . '">' . $row[ 'sy_period' ] . '</option>';
						}
						?>
					</select>
				</div>
			</div>
			<div class="col-md-4">
				<div class="input-group"><input class="form-control" type="text" name="idnumber" id="idnumber" placeholder="Id Number">
					<div class="input-group-append"><button class="btn btn-primary" id="show_sched"><i class="fas fa-search fa-fw"></i></button>
					</div>
				</div>
			</div>
               <div class="col-md-4">
				<button class="btn btn-info float-right" id="cross_enrolled"><i class="fas fa-exchange-alt fa-lg"></i> <small>CROSS ENROLLED</small></button>
			</div>               
		</div>
		<div class="row">
			<div class="col-md-12">
				<hr>
			</div>
		</div>		
		<div class="row">
			<div class="col-md-12" id="sched_result"></div>
		</div>
		<div class="fixed-bottom" style="background-color: lightgray;">
			<div class="text-center" style="padding:5px 0px 5px 0px;">                    
				<form id="form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
					
                         <?php 
                         if($role==2) { //encoder
                              echo '<button id="idregister" class="btn btn-sm btn-primary" type="submit" value="New" name="action">New</button>
                              <button class="btn btn-success btn-sm" type="submit" name="action" value="Open">Open Queue</button>'; }
                         elseif($role==1) { //ADVISER
                              echo '<button id="open_queue" class="btn btn-sm btn-success" type="submit" name="action" value="open_queue"><i></i>Approval<small class="total_for_approval badge badge-danger" style="position:absolute; top:0;"></small></button>
                              <button id="queue_to_chair" class="btn btn-sm btn-info" type="submit" name="action" value="Queue">Queue</button>';} 
                         elseif($role==3){ //chairperson
                              echo '<button id="open_queue" class="btn btn-sm btn-success" type="submit" name="action" value="open_queue"><i></i>Approval<small class="total_for_approval badge badge-danger" style="position:absolute; top:0;"></small></button>
                              <button id="queue" class="btn btn-sm btn-info" type="submit" name="action" value="Queue">Queue</button>';
                         }?>
                         <button id="chat" class="btn btn-sm btn-primary" type="submit" name="action" value="Chat">Chat</button>
                         <button class="btn btn-sm btn-danger" type="submit" name="action" value="Logout">Logout</button>                         
				</form>
			</div>
		</div>
		<div class="modal fade" id="sub_details" tabindex="-1" role="dialog" aria-labelledby="sub_details" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">DETAILS</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
					</div>
					<div class="modal-body">
						<div id="sub_details_content"></div>
					</div>
					<div class="modal-footer"> <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>
		
          <div class="modal fade" id="approval" tabindex="-1" role="dialog" aria-labelledby="approval" aria-hidden="true">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">DETAILS</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
					</div>
					<div class="modal-body">
                              <!--==============-->
                              <div class="row">
                                   <div class="col div_cbo"><div class="form-group">                             
                                        <div class="input-group">                                             
                                             <select class="form-control" name="sel_course" id="sel_course">
                                                  <option value="0">[All Course]</option>
                                                  <?php
                                                       $stmt = $pdo->prepare( "SELECT course.idcourse, course.section_prefix
                                                                      FROM course INNER JOIN faculty_pef_res USING(idcourse)
                                                                      WHERE faculty_pef_res.idfaculty = ?" );
                                                       $stmt->execute([$idfaculty]);
                                                       foreach ( $stmt as $row ) {
                                                            echo '<option value="' . $row[ 'idcourse' ] . '">' . $row[ 'section_prefix' ] . '</option>';
                                                       }
                                                  ?>
                                             </select>                                        
                                        </div>                                  
                                   </div></div>                                   
                              </div>
                              <!--==============-->
                              <div class="row">
                                   <div class="col div_cbo"><div class="form-group">                             
                                        <div class="input-group">                                             
                                             <select class="form-control" name="sel_yl" id="sel_yl">
                                                  <option value="5">[All Year Level]</option>
                                                  <option value="0">1st Year</option>
                                                  <option value="1">2nd Year</option>
                                                  <option value="2">3rd Year</option>
                                                  <option value="3">4th Year</option>
                                                  <option value="4">5th Year</option>
                                             </select>                                        
                                        </div>                                  
                                   </div></div>
                                   <div class="col div_btn"><div class="form-group">                                                                          
                                   </div></div>
                              </div>                              
						<div id="approval_content">                                   
                              </div>
					</div>
					<div class="modal-footer"> <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>          
          <div id="chatbox">
               <form name="frmchat" method="post">
                    <div data-mcs-theme="dark" class="mCustomScrollbar msg_sent"></div>
                    <div class="form-group">                     
                      <textarea class="form-control" rows="5" id="msg"></textarea>
                    </div>
                    <button type="button" class="btn btn-sm btn-primary send">SEND</button>
                    <button type="button" class="btn btn-sm btn-danger cancel">CLOSE</button>
               </form>
          </div>
          <!--///// -->
          <div class="modal fade" id="remove_subject_dialog" tabindex="-1" role="dialog" aria-labelledby="remove_msg" aria-hidden="true">
			<div class="modal-dialog modal-sm modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="remove_subject_dialog_title">NOTIFYING STUDENT...</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
					</div>
					<div class="modal-body">
						<div id="content">
                                   <p class="reason text-success"><strong>Reason</strong></p>
                                   <textarea class="form-control" rows="5" id="remove_subject_msg"></textarea>
                              </div>
					</div>
					<div class="modal-footer"> <button type="button" class="remove btn btn-secondary">OK</button>
					</div>
				</div>
			</div>
		</div>
          <!--///// -->
          <div class="modal fade" id="cancel_msg_dialog" tabindex="-1" role="dialog" aria-labelledby="cancel_msg" aria-hidden="true">
			<div class="modal-dialog modal-sm modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="cancel_msg_dialog_title">REASON...</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
					</div>
					<div class="modal-body">
						<div id="content">
                                   <textarea class="form-control" rows="5" id="cancel_msg">
                                   </textarea>
                              </div>
					</div>
					<div class="modal-footer"> <button type="button" class="ok btn btn-secondary">OK</button>
					</div>
				</div>
			</div>
		</div>
          <div class="modal fade" id="class_full" tabindex="-1" role="dialog" aria-labelledby="class_full" aria-hidden="true">
			<div class="modal-dialog modal-sm modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="class_full_title">SIZE LIMIT...</h5> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
					</div>
					<div class="modal-body">
						<div id="class_full_content"></div>
					</div>
					<div class="modal-footer"> <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>
	</div>     
</body>
</html>