<?php
include_once( "include/connect.php" );

function is_user_a_chairperson($idfaculty) {
	$stmt = $GLOBALS['pdo']->prepare("SELECT COUNT(*) AS found 
	FROM dept WHERE idfaculty = ?;");
	
	$stmt->execute([$idfaculty]);
	$row = $stmt->fetch();
	return $row['found'];
}

session_start();

$status = '';
$days_left = '';
$login = '';
$check_state = 'checked';


if ($_SERVER['REQUEST_METHOD']=="POST") {
	if(isset($_POST['user_type'])) {$check_state = "checked";}
	else{$check_state='';}
}

$_SESSION['idstudent'] = 0;
$_SESSION['is_edit_profile'] = false;
$_SESSION['view_edit'] = false;
$_SESSION['idnumber'] = 0;
$_SESSION['yl']=0;

if (isset($_SESSION['is_faculty_login'])) {
     if ($_SESSION['is_faculty_login']==true) {header("Location: advising.php");}
}

if (isset($_SESSION['is_login'])) {
     if ($_SESSION['is_login']==true) {header("Location: pef.php");}
}

$res = $pdo->query("SELECT DATEDIFF(date_close, now()) AS rem_days, date_close FROM sem_settings WHERE is_open = 1;")->fetch();

$date_close = '<span class="text-info">Closing Date: </span><span class="text-success">'.$res["date_close"]."</span>";
$days_left = "";
$login = '<div class="center_elements"><form id="login" role="form" method="POST" action="'.htmlspecialchars($_SERVER["PHP_SELF"]).'"><div class="form-group"><div class="input-group"><div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Id Number"><span class="input-group-text"><i class="far fa-id-card fa-lg fa-fw"></i></span></div><input class="form-control" type="text" placeholder="ID Number" name="idnumber"></div></div><div class="form-group"><div class="input-group"><div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Password"><span class="input-group-text"><i class="fas fa-key fa-lg fa-fw"></i></span></div><input class="form-control" type="password" placeholder="Password" name="password"></div></div><div class="form-group"><button id="idsubmit" class="btn btn-success" type="submit" value="Submit" name="submit"><i class="fas fa-check fa-lg"></i> Login</button> </div></form><div class="alert alert-info"><p><i class="fas fa-unlock-alt fa-md fa-fw"></i> <small>Recover your Password <a href="recover.php">HERE!.</a></small></p><p><i class="far fa-id-card fa-md fa-fw"></i><small> Get your ID Number <a href="student.php">HERE!</a></small></p><p><i class="fas fa-question-circle fa-md fa-fw"></i> <small>Frequently asked questions <a href="instructions.php#id">(FAQ)</a></small></p> <p><i class="fas fa-video fa-md fa-fw"></i> <small><a href="instructions.php#video">Tutorial</a> on how to use PEF</small></p></div></div>';

if($res["rem_days"] > 0 && $res["rem_days"] <= 31) {
	$days_left = "<span class=\"text-danger\">$res[rem_days] day(s) Left</span>";
}elseif($res["rem_days"]<=0){
	$days_left = '<h3 class="text-danger text-center">CLOSED</h3>';
	$date_close = "";     
	//$login = "";
}

?>
<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1.0"><link href="fontawesome5.9.0/css/all.min.css" rel="stylesheet"><link href="bootstrap-4.3.1/css/bootstrap.min.css" rel="stylesheet"><link href="bootstrap4-toggle-3.5.0/css/bootstrap4-toggle.min.css" rel="stylesheet"> <script src="js/jquery-3.3.1.min.js"></script> <script src="js/popper.min.js"></script> <script src="bootstrap-4.3.1/js/bootstrap.min.js"></script> <script src="bootstrap4-toggle-3.5.0/js/bootstrap4-toggle.min.js"></script> <meta charset="utf-8"><title>PSU Computer Studies Department PEF</title><script>$(function(){var selbutton='';$('[data-toggle="tooltip"]').tooltip(); $("#idsubmit").click(function(e){selbutton=e.target.id;});$("#login").submit(function(e){if(selbutton=="idsubmit"){selbutton='';var id=$.trim($("[name=idnumber]").val());var pwd=$.trim($("[name=password]").val());if(id==""||pwd==""){$("#status").text('ID Number or Password is INVALID');e.preventDefault();}}});});</script>
     <style>.center_elements{margin-left:auto;margin-right:auto;width:270px} .center_elements p{margin-bottom: 5px;}</style></head><body><div class="jumbotron text-center alert-info" style="height:100px; padding: 30px 0 30px 0;"><h3>PALAWAN STATE UNIVERSITY</h3><p>PRE-ENROLLMENT</p></div><div class="container"><div class="row"> <?php echo($login); ?></div><div class="row"><div class="col-md-12">
				<?php
					$id='';
					$pwd='';
					if ($_SERVER['REQUEST_METHOD']=="POST") {						
						if (isset($_POST['submit'])) {
                                   if($_POST['idnumber']=="" || $_POST['password']=="") {
								$status="ID Number or Password is INVALID";
							} else{
								$id = $_POST['idnumber'];
								$pwd = $_POST['password'];
								$iduser = "";
								$idnumber = "";
																
								 if ($res["rem_days"]<=0) {
									 $status="THE PORTAL IS CLOSED"; 
								 }else{
									  $stmt = $pdo->prepare("SELECT idstudent, idnumber, idcourse, yl FROM student WHERE idnumber = ? AND pwd COLLATE utf8_bin = ?;");
									  $stmt->execute([$id, $pwd]);

									  if ($stmt->rowCount() >0) {
										$row = $stmt->fetch();
										$iduser = $row["idstudent"];
										$idnumber = $row['idnumber'];
										$idcourse = $row['idcourse'];
										$yl = $row['yl'];

										$_SESSION['idstudent'] = $iduser;
										$_SESSION['is_login'] = true;
										$_SESSION['idnumber'] = $idnumber;
										$_SESSION['idcourse'] = $idcourse;
										$_SESSION['yl'] = $yl;
										header("Location: pef.php");}
									  else{
										   $status = "ID Number or Password is INVALID";}
								 }
								}								
							}														
						}										
				?><p id="status" class="text-center text-danger font-weight-bold"><?php echo($status); ?></p><div class="alert alert-warning" style="width:270px; margin-left:auto; margin-right:auto;"><p class="text-center text-warning font-weight-bold"><small><?php echo("$date_close<BR>$days_left"); ?></small></p></div></div></div><div class="row"><div class="col-md-12"><p class="text-center text-primary small">Powered by Computer Studies. Copyright 2019</p></div></div></div></body></html>