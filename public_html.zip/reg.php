<?php
session_start();
if ( !isset( $_SESSION[ 'idstudent' ] ) ) {
	header( "Location: /pef" );
}
$success = '';
$error = false;
$id_status='';
$pwd_status = '';
$pwd_status_confirm = '';
$lname_status = '';
$fname_status = '';
$email_status = '';
$dob_status = '';
$cp_status = '';
$learning_mode_status='';
$res = '';
include_once( "include/function.php" );

$idstudent = $_SESSION[ 'idstudent' ];
$is_edit = $_SESSION['is_edit_profile'];
$view_edit = $_SESSION[ 'view_edit' ];

$idcourse = '';
$idnumber = '';
$lname = '';
$fname = '';
$pwd = '';
$sex = '';
$religion = '';
$address = '';
$nationality = '';
$yl = '';
$civil_stat = '';
$sports1 = '';
$sports2 = '';
$talent = '';
$admission_stat = '';
$email = '';
$dob = '';
$pob = '';
$cp = '';
$father = '';
$mother = '';
$guardian = '';
$parent_address = '';
$guardian_address = '';
$contact_no = '';
$high_school = '';
$high_school_date = '';
$college = '';
$college_date = '';
$learning_mode = '';

if ($view_edit) {
	if ($is_edit) {
		$stmt = $pdo->prepare( "SELECT * FROM student WHERE idstudent = ?" );
		$stmt->execute( [ $idstudent ] );
		$row = $stmt->fetch();

		$idcourse = $row[ 'idcourse' ];
		$idnumber = $row[ 'idnumber' ];
		$lname = $row[ 'lname' ];
		$fname = $row[ 'fname' ];
		$pwd = $row[ 'pwd' ];
		$sex = $row[ 'sex' ];
		$religion = $row[ 'religion' ];
		$address = $row[ 'address' ];
		$nationality = $row[ 'nationality' ];
		$yl = $row[ 'yl' ];
		$civil_stat = $row[ 'civil_stat' ];
		$sports1 = $row[ 'sports1' ];
		$sports2 = $row[ 'sports2' ];
		$talent = $row[ 'talent' ];
		$admission_stat = $row[ 'admission_stat' ];
		$email = $row[ 'email' ];
		$dob = $row[ 'dob' ];
		$pob = $row[ 'pob' ];
		$cp = $row[ 'cp' ];
		$father = $row[ 'father' ];
		$mother = $row[ 'mother' ];
		$guardian = $row[ 'guardian' ];
		$parent_address = $row[ 'parent_address' ];
		$guardian_address = $row[ 'guardian_address' ];
		$contact_no = $row[ 'contact_no' ];
		$high_school = $row[ 'high_school' ];
		$high_school_date = $row[ 'high_school_date' ];
		$college = $row[ 'college' ];
		$college_date = $row[ 'college_date' ];
          $learning_mode = $row['learning_mode'];
          
		if ( $dob == '' ) {
			$dob = NULL;
		}
		if ( $high_school_date == '' ) {
			$high_school_date = NULL;
		}
		if ( $college_date == '' ) {
			$college_date = NULL;
		}
	}
}

if ( $_SERVER[ 'REQUEST_METHOD' ] == "POST" ) {
	if ( $_POST[ 'action' ] == "Logout" ) {
		header( "Location: include/logout.php" );
	}

	if ( $_POST[ 'idnumber' ] == '' ) {
		$id_status = 'Invalid Id Number';
		$error = true;
	} elseif ( $_POST[ 'password' ] == '' ) {
		$pwd_status = 'Invalid Password';
		$error = true;
	} elseif ( $_POST[ 'password_confirm' ] <> $_POST[ 'password' ] ) {
		$pwd_status_confirm = 'Confirm your password correctly';
		$error = true;
	} elseif ( $_POST[ 'lname' ] == '' ) {
		$lname_status = 'Invalid Lastname';
		$error = true;
	} elseif ( $_POST[ 'fname' ] == '' ) {
		$fname_status = 'Invalid Firstname';
		$error = true;
     /*} elseif ( $_POST[ 'learning_mode' ] == 0 ) {
		$learning_mode_status = 'Select your preferred Learning Mode';
		$error = true;*/
     }elseif ( $_POST[ 'cp' ] == '' ) {
		$cp_status = 'Invalid Cellphone Number';
		$error = true;
	}elseif ( $_POST[ 'email' ] == '' ) {
		$email_status = 'Invalid Email';
		$error = true;
     }elseif ( $_POST[ 'dob' ] == '' ) {
		$dob_status = 'Invalid Date of Birth';
		$error = true;     
     }

	if ($is_edit) {
		if ($_POST[ 'idnumber' ] <> $idnumber) {
			if (is_idnumber_exist($_POST['idnumber'] ) ) {
				$id_status = 'Id Number is already taken.';
				$error = true;
			}
		}
	} else {
		if ( is_idnumber_exist( $_POST[ 'idnumber' ] ) ) {
			$id_status = 'Id Number is already taken.';
			$error = true;
		}
	}


	$idcourse = $_POST[ 'course' ];
	$idnumber = $_POST[ 'idnumber' ];
	$lname = $_POST[ 'lname' ];
	$fname = $_POST[ 'fname' ];
	$pwd = $_POST[ 'password' ];
	$sex = $_POST[ 'sex' ];
	$religion = $_POST[ 'religion' ];
	$address = $_POST[ 'address' ];
	$nationality = $_POST[ 'nationality' ];
	$yl = $_POST[ 'yl' ];
	$civil_stat = $_POST[ 'civil_stat' ];
	$sports1 = $_POST[ 'sports1' ];
	$sports2 = $_POST[ 'sports2' ];
	$talent = $_POST[ 'talent' ];
	$admission_stat = $_POST[ 'admission_stat' ];
	$email = $_POST[ 'email' ];
	$dob = $_POST[ 'dob' ];
	$pob = $_POST[ 'pob' ];
	$cp = $_POST[ 'cp' ];
	$father = $_POST[ 'father' ];
	$mother = $_POST[ 'mother' ];
	$guardian = $_POST[ 'guardian' ];
	$parent_address = $_POST[ 'parent_address' ];
	$guardian_address = $_POST[ 'guardian_address' ];
	$contact_no = $_POST[ 'contact_no' ];
	$high_school = $_POST[ 'high_school' ];
	$high_school_date = $_POST[ 'high_school_date' ];
	$college = $_POST[ 'college' ];
	$college_date = $_POST[ 'college_date' ];
     $learning_mode = $_POST['learning_mode'];
     
	if ( $dob == '' ) {
		$dob = NULL;
	}

	if ( $high_school_date == '' ) {
		$high_school_date = NULL;
	}
	if ( $college_date == '' ) {
		$college_date = NULL;
	}

	if ( $is_edit ) {
		$stmt = $pdo->prepare( "UPDATE student SET idcourse = :idcourse, 
		idnumber = :idnumber, 
		lname = :lname, 
		fname = :fname,
		pwd = :pwd, 
		sex = :sex,
		religion= :religion,
		address = :address,
		nationality = :nationality,
		yl = :yl, 
		civil_stat = :civil_stat,
		sports1 = :sports1, 
		sports2 = :sports2,
		talent = :talent,
		admission_stat = :admission_stat, 
		email = :email, 
		dob = :dob, 
		pob = :pob, 
		cp = :cp, 
		father = :father, 
		mother = :mother, 
		guardian = :guardian, 
		parent_address = :parent_address,
		guardian_address = :guardian_address, 
		contact_no = :contact_no, 
		high_school = :high_school, 
		high_school_date = :high_school_date, 
		college = :college, 
		college_date = :college_date,
          learning_mode = :learning_mode
		WHERE idstudent = :idstudent" );

		if ( $error ) {} else {
			$res = $stmt->execute(['idcourse' => $idcourse, 'idnumber' => $idnumber, 'lname' => $lname, 'fname' => $fname, 'pwd' => $pwd, 'sex' => $sex, 'religion' => $religion, 'address' => $address, 'nationality' => $nationality, 'yl' => $yl, 'civil_stat' => $civil_stat, 'sports1' => $sports1, 'sports2' => $sports2, 'talent' => $talent, 'admission_stat' => $admission_stat, 'email' => $email, 'dob' => $dob, 'pob' => $pob, 'cp' => $cp, 'father' => $father, 'mother' => $mother, 'guardian' => $guardian, 'parent_address' => $parent_address, 'guardian_address' => $guardian_address, 'contact_no' => $contact_no, 'high_school' => $high_school, 'high_school_date' => $high_school_date, 'college' => $college, 'college_date' => $college_date, 'learning_mode' => $learning_mode, 'idstudent' => $idstudent]);
		}

	} else {

		$stmt = $pdo->prepare("INSERT INTO student(idcourse, idnumber, lname, fname, pwd, sex, religion, address, nationality, yl, civil_stat, sports1, sports2, talent, admission_stat, email, dob, pob, cp, father, mother, guardian, parent_address, guardian_address, contact_no, high_school, high_school_date, college, college_date, learning_mode) VALUES(:idcourse, :idnumber, :lname, :fname, :pwd, :sex, :religion, :address, :nationality, :yl, :civil_stat, :sports1, :sports2, :talent, :admission_stat, :email, :dob, :pob, :cp, :father, :mother, :guardian, :parent_address, :guardian_address, :contact_no, :high_school, :high_school_date, :college, :college_date, :learning_mode)" );

		if ($error) {} else {
			$res = $stmt->execute(['idcourse' => $idcourse, 'idnumber' => $idnumber, 'lname' => $lname, 'fname' => $fname, 'pwd' => $pwd, 'sex' => $sex, 'religion' => $religion, 'address' => $address, 'nationality' => $nationality, 'yl' => $yl, 'civil_stat' => $civil_stat, 'sports1' => $sports1, 'sports2' => $sports2, 'talent' => $talent, 'admission_stat' => $admission_stat, 'email' => $email, 'dob' => $dob, 'pob' => $pob, 'cp' => $cp, 'father' => $father, 'mother' => $mother, 'guardian' => $guardian, 'parent_address' => $parent_address, 'guardian_address' => $guardian_address, 'contact_no' => $contact_no, 'high_school' => $high_school, 'high_school_date' => $high_school_date, 'college' => $college, 'college_date' => $college_date, 'learning_mode' => $learning_mode]);
		}

	}

	if ( $res ) {
          $success = '<div class="alert alert-success text-center">
          <h5>Registration Complete.</h5>
          <p class="text-primary">REDIRECT to Login...</p>
          </div>';
          $_SESSION[ 'view_edit' ] = false;
     }
}

?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>Registration</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="fontawesome5.9.0/css/all.min.css" rel="stylesheet">
	<link href="bootstrap-4.3.1/css/bootstrap.min.css" rel="stylesheet">
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="bootstrap-4.3.1/js/bootstrap.min.js"></script>
	<script>
		$( function () {
               <?php
                    if($res) {
                         if ($is_edit) {echo 'function redirect() {window.location="pef.php";}';}
                         else{echo 'function redirect() {window.location="/";}';}
                         echo 'setInterval(redirect,3000);';
                    }
               ?>
               $("[name=cp]").keypress(function (e){
                    if (e.which != 8 && e.which !=0 && (e.which <48 || e.which > 57)) {
                        return false;
                    }
               }); 
               
			var selbutton = '';
			<?php if(!$error) {echo '$( ".error" ).text( "" );';} ?>
			
			function scroll_now( elem ) {				
				$( "html, body" ).animate( {
					scrollTop: elem.offset().top / 2
				}, 1000 );
				elem.focus();
			}
			$( "button[type=reset]" ).click( function ( e ) {
				$( ".error" ).text( "" );
			} );
			$("#idsubmit").click( function ( e ) {
				selbutton = e.target.id;
			});
			$( "#reg" ).submit( function ( e ) {
				$( ".error" ).text( "" );
				if ( selbutton == "idsubmit" ) {
					selbutton = '';
					if ( $.trim( $( "[name=idnumber]" ).val() ) == "" ) {
						$( "#error_id" ).text( "Invalid Id Number" );
						e.preventDefault();
						scroll_now( $( "[name=idnumber]" ) );
						return;
					}
					if ( $( "[name=idnumber]" ).val() != '<?php echo $_SESSION['idnumber'];?>' ) {
						if ( not_valid_id() == true ) {
							$( "#error_id" ).text( "Id Number is already taken." );
							e.preventDefault();
							scroll_now( $( "[name=idnumber]" ) );
							return;
						}
					}
					if ($.trim( $( "[name=password]" ).val() ) == "") {
						$("#error_pass").text("Invalid Password");
						e.preventDefault();
						scroll_now($("[name=password]"));
						return;
					}
					if ( $.trim( $( "[name=password_confirm]" ).val() ) !== $.trim( $( "[name=password]" ).val() ) ) {
						$( "#error_pass_confirm" ).text( "Confirm your password correctly" );
						e.preventDefault();
						scroll_now( $( "[name=password_confirm]" ) );
						return;
					}
					if ($.trim($("[name=lname]").val()) == "") {
						$("#error_lname").text( "Invalid Lastname" );
						e.preventDefault();
						scroll_now($("[name=lname]"));
						return;
					}
					if ($.trim($("[name=fname]").val()) == "") {
						$("#error_fname").text( "Invalid Firstname");
						e.preventDefault();
						scroll_now($("[name=fname]"));
						return;
					}
                         
                         /*if ($("[name=learning_mode]").val() == 0) {
						$("#error_fname").text( "Select your preferred Learning Mode");
						e.preventDefault();
						scroll_now($("[name=learning_mode]"));
						return;
					}*/
                         
                         if ($.trim($("[name=cp]").val()) == "") {
						$("#error_cp").text("Invalid Cellphone Number");
						e.preventDefault();
						scroll_now($("[name=cp]"));
						return;
					}
                         
                         if ($.trim($("[name=email]").val()) == "") {
						$("#error_email").text("Invalid Email");
						e.preventDefault();
						scroll_now($("[name=email]"));
						return;
					}
                         
                         if ($.trim($("[name=dob]").val()) == "") {
						$("#error_dob").text("Invalid Date of Birth");
						e.preventDefault();
						scroll_now($("[name=dob]"));
						return;
					}
                         
				}
			} );

			function not_valid_id() {
				var res = false;
				$.ajax( {
					method: "POST",
					async: false,
					url: "include/is_id_duplicate.php",
					data: {
						idnumber: $( "[name=idnumber]" ).val()
					},
					success: function ( e ) {
						if ( e != 0 ) {
							res = true;
						}
					}
				} );
				return res;
			}
			$( '[data-toggle="tooltip"]' ).tooltip();
		} );
	</script>
	<style>
		.spacer {
			height: 50px;
		}
	</style>
</head>

<body>
	<h2 class="alert alert-info text-center">PEF REGISTRATION</h2>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
                    <?php echo $success; ?>
				<form role="form" id="reg" method="post" action="<?php echo( htmlspecialchars($_SERVER["PHP_SELF"])); ?>">
					<div class="form-group">
						<small class="badge badge-danger error" id="error_id">
							<?php echo $id_status; ?>
						</small>
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Id Number"><span class="input-group-text"><i class="far fa-id-card fa-fw"></i></span>
							</div><input type="text" class="form-control" name="idnumber" placeholder="ID Number" value="<?php if($is_edit){echo $idnumber;} ?>" maxlength="20">
						</div>
					</div>
					<div class="form-group">
						<small class="badge badge-danger error" id="error_pass">
							<?php echo $pwd_status; ?>
						</small>
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Password"><span class="input-group-text"><i class="fas fa-key fa-fw"></i></span>
							</div><input type="password" class="form-control" name="password" placeholder="Password" value="<?php if($is_edit){echo $pwd;} ?>" maxlength="20">
						</div>
					</div>
					<div class="form-group">
						<small class="badge badge-danger error" id="error_pass_confirm">
							<?php echo $pwd_status_confirm; ?>
						</small>
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Confirm Password"><span class="input-group-text"><i class="fas fa-lock fa-fw"></i></span>
							</div><input type="password" class="form-control" name="password_confirm" placeholder="Confirm Password" value="<?php if($is_edit){echo $pwd;} ?>" maxlength="20">
						</div>
					</div>
					<div class="form-group">
						<small class="badge badge-danger error" id="error_lname">
							<?php echo $lname_status; ?>
						</small>
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Lastname"> <span class="input-group-text"> <i class="fas fa-align-left fa-fw"></i> </span>
							</div> <input type="text" class="form-control" name="lname" placeholder="Lastname" value="<?php if($is_edit){echo $lname;} ?>">
						</div>
					</div>
					<div class="form-group">
						<small class="badge badge-danger error" id="error_fname">
							<?php echo $fname_status; ?>
						</small>
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Firstname"> <span class="input-group-text"> <i class="fas fa-align-right fa-fw"></i> </span>
							</div> <input type="text" class="form-control" name="fname" placeholder="Firstname" value="<?php if($is_edit){echo $fname;} ?>">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Sex"> <span class="input-group-text"> <i class="fas fa-mars fa-fw"></i> </span>
							</div>
							<select class="form-control" name="sex">
								<option value="F" <?php if($is_edit){if($sex=='F' ){echo "selected";}} ?>>Female</option>
								<option value="M" <?php if($is_edit){if($sex=='M' ){echo "selected";}} ?>>Male</option>
							</select>
						</div>
					</div>
                         <div class="form-group">                             
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Learning Mode"> <span class="input-group-text"> <i class="fas fa-book"></i> </span>
							</div>
							<select class="form-control" name="learning_mode">
                                        <option value="0" <?php if($is_edit){if($learning_mode==0 ){echo "selected";}} ?>>None</option>
								<option value="1" <?php if($is_edit){if($learning_mode==1 ){echo "selected";}} ?>>Face-to-Face</option>
								<option value="2" <?php if($is_edit){if($learning_mode==2 ){echo "selected";}} ?>>Modular</option>
								<option value="3" <?php if($is_edit){if($learning_mode==3 ){echo "selected";}} ?>>Online</option>
								<option value="4" <?php if($is_edit){if($learning_mode==4 ){echo "selected";}} ?>>Flexible/Blended</option>
					          </select>
						</div>
					</div>
                         <div class="form-group">
                              <small class="badge badge-danger error" id="error_cp">
							<?php echo $cp_status; ?>
						</small>
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Cellphone Number"> <span class="input-group-text"> <i class="fas fa-mobile-alt fa-fw"></i> </span>
							</div><input type="text" class="form-control" name="cp" placeholder="Cellphone Number" value="<?php if($is_edit){echo $cp;} ?>">
						</div>
					</div>
                         <div class="form-group">
                              <small class="badge badge-danger error" id="error_email">
							<?php echo $email_status; ?>
						</small>
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Email"> <span class="input-group-text"> <i class="far fa-envelope fa-fw"></i> </span>
							</div> <input type="email" name="email" placeholder="Email" class="form-control" value="<?php if($is_edit){echo $email;} ?>">
						</div>
					</div>
					<div class="form-group">
                              <small class="badge badge-danger error" id="error_dob">
							<?php echo $dob_status; ?>
						</small>
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Birthdate"> <span class="input-group-text"> <i class="far fa-calendar-alt fa-fw"></i> </span>
							</div> <input type="date" name="dob" placeholder="Birthdate" class="form-control" value="<?php if($is_edit){echo $dob;} ?>">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Place of Birth"> <span class="input-group-text"> <i class="fas fa-globe-asia fa-fw"></i> </span>
							</div> <input type="text" class="form-control" name="pob" placeholder="Place of Birth" value="<?php if($is_edit) {echo $pob;} ?>">
						</div>
					</div>
					<div class="form-group">						
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Religion"> <span class="input-group-text"> <i class="fas fa-church fa-fw"></i> </span>
							</div>
							<select class="form-control" name="religion">
								<option value="0" <?php if($is_edit){if($religion==0 ){echo "selected";}} ?>>[Others]</option>
								<option value="1" <?php if($is_edit){if($religion==1 ){echo "selected";}} ?>>Adventist</option>
								<option value="2" <?php if($is_edit){if($religion==2 ){echo "selected";}} ?>>Baptist</option>
								<option value="3" <?php if($is_edit){if($religion==3 ){echo "selected";}} ?>>Born Again</option>
								<option value="4" <?php if($is_edit){if($religion==4 ){echo "selected";}} ?>>Muslim</option>
								<option value="5" <?php if($is_edit){if($religion==5 ){echo "selected";}} ?>>River of Life</option>
								<option value="6" <?php if($is_edit){if($religion==6 ){echo "selected";}} ?>>Roman Catholic</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Address"> <span class="input-group-text"> <i class="fas fa-map-marked-alt fa-fw"></i> </span>
							</div> <input type="text" class="form-control" name="address" placeholder="Address" value="<?php if($is_edit){echo $address;} ?>">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Nationality"> <span class="input-group-text"> <i class="fas fa-flag fa-fw"></i> </span>
							</div> <input type="text" class="form-control" name="nationality" placeholder="Nationality" value="<?php if($is_edit){echo $nationality;} ?>">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Course"> <span class="input-group-text"> <i class="fas fa-route fa-fw"></i> </span>
							</div>
							<select class="form-control" name="course">
								<?php $course = $pdo->query("SELECT * FROM course;");foreach($course as $row ) {if ($is_edit){if($idcourse == $row['idcourse']){echo '<option value="'.$row["idcourse"].'" selected>'.$row["course_name"].'['.$row["section_prefix"].']</option>';continue;}}echo '<option value="'.$row["idcourse"].'">'.$row["course_name"].'['.$row["section_prefix"].']</option>';}?>
							</select>
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Year Level"> <span class="input-group-text"> <i class="fas fa-chart-line fa-fw"></i> </span>
							</div>
							<select class="form-control" name="yl">
								<option value="0" <?php if($is_edit){if($yl==0){echo "selected";}} ?>>1st Year</option>
								<option value="1" <?php if($is_edit){if($yl==1){echo "selected";}} ?>>2nd Year</option>
								<option value="2" <?php if($is_edit){if($yl==2){echo "selected";}} ?>>3rd Year</option>
								<option value="3" <?php if($is_edit){if($yl==3){echo "selected";}} ?>>4th Year</option>
								<option value="4" <?php if($is_edit){if($yl==4){echo "selected";}} ?>>5th Year</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Civil Status"> <span class="input-group-text"> <i class="fas fa-user-friends fa-fw"></i> </span>
							</div>
							<select class="form-control" name="civil_stat">
								<option value="0" <?php if($is_edit){if($civil_stat==0){echo "selected";}} ?>>Single</option>
								<option value="1" <?php if($is_edit){if($civil_stat==1){echo "selected";}} ?>>Married</option>
								<option value="2" <?php if($is_edit){if($civil_stat==2){echo "selected";}} ?>>Separated</option>
								<option value="3" <?php if($is_edit){if($civil_stat==3){echo "selected";}} ?>>Widow</option>
								<option value="4" <?php if($is_edit){if($civil_stat==4){echo "selected";}} ?>>Widower</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Admission Status"> <span class="input-group-text"> <i class="far fa-file fa-fw"></i> </span>
							</div>
							<select class="form-control" name="admission_stat">
								<option value="0" <?php if($is_edit){if($admission_stat==0){echo "selected";}} ?>>New</option>
								<option value="1" <?php if($is_edit){if($admission_stat==1){echo "selected";}} ?>>Transferee</option>
								<option value="2" <?php if($is_edit){if($admission_stat==2){echo "selected";}} ?>>Re-Admission</option>
								<option value="3" <?php if($is_edit){if($admission_stat==3){echo "selected";}} ?>>Old</option>
							</select>
						</div>
					</div>
										
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Primary Sports"> <span class="input-group-text"> <i class="fas fa-futbol fa-fw"></i> </span>
							</div>
							<select class="form-control" name="sports1">
								<option value="Not Physically Fit" <?php if($is_edit){if($sports1=='Not Physically Fit' ){echo "selected";}} ?>>[Not Physically Fit]</option>
								<option value="PWD" <?php if($is_edit){if($sports1=='PWD' ){echo "selected";}} ?>>[PWD]</option>
								<option value="Archery" <?php if($is_edit){if($sports1=='Archery' ){echo "selected";}} ?>>Archery</option>
								<option value="Athletics" <?php if($is_edit){if($sports1=='Athletics' ){echo "selected";}} ?>>Athletics</option>
								<option value="Badminton" <?php if($is_edit){if($sports1=='Badminton' ){echo "selected";}} ?>>Badminton</option>
								<option value="Basketball" <?php if($is_edit){if($sports1=='Basketball' ){echo "selected";}} ?>>Basketball</option>
								<option value="Baseball/Softball" <?php if($is_edit){if($sports1=='Baseball/Softball' ){echo "selected";}} ?>>Baseball/Softball</option>
								<option value="Boxing" <?php if($is_edit){if($sports1=='Boxing' ){echo "selected";}} ?>>Boxing</option>
								<option value="Football/Futsal" <?php if($is_edit){if($sports1=='Football/Futsal' ){echo "selected";}} ?>>Football/Futsal</option>
								<option value="Karate" <?php if($is_edit){if($sports1=='Karate' ){echo "selected";}} ?>>Karate</option>
								<option value="Lawn Tennis" <?php if($is_edit){if($sports1=='Lawn Tennis' ){echo "selected";}} ?>>Lawn Tennis</option>
								<option value="Pageant" <?php if($is_edit){if($sports1=='Pageant' ){echo "selected";}} ?>>Pageant</option>
								<option value="Softball" <?php if($is_edit){if($sports1=='Softball' ){echo "selected";}} ?>>Softball</option>
								<option value="Swimming" <?php if($is_edit){if($sports1=='Swimming' ){echo "selected";}} ?>>Swimming</option>
								<option value="Taekwondo" <?php if($is_edit){if($sports1=='Taekwondo' ){echo "selected";}} ?>>Taekwondo</option>
								<option value="Table Tennis" <?php if($is_edit){if($sports1=='Table Tennis' ){echo "selected";}} ?>>Table Tennis</option>
								<option value="Volleyball/Beach Volleyball" <?php if($is_edit){if($sports1=='Volleyball/Beach Volleyball' ){echo "selected";}} ?>>Volleyball/Beach Volleyball</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Secondary Sports"> <span class="input-group-text"> <i class="fas fa-volleyball-ball fa-fw"></i> </span>
							</div>
							<select class="form-control" name="sports2">
								<option value="Not Physically Fit" <?php if($is_edit){if($sports2=='Not Physically Fit' ){echo "selected";}} ?>>[Not Physically Fit]</option>
								<option value="PWD" <?php if($is_edit){if($sports2=='PWD' ){echo "selected";}} ?>>[PWD]</option>
								<option value="Archery" <?php if($is_edit){if($sports2=='Archery' ){echo "selected";}} ?>>Archery</option>
								<option value="Athletics" <?php if($is_edit){if($sports2=='Athletics' ){echo "selected";}} ?>>Athletics</option>
								<option value="Badminton" <?php if($is_edit){if($sports2=='Badminton' ){echo "selected";}} ?>>Badminton</option>
								<option value="Basketball" <?php if($is_edit){if($sports2=='Basketball' ){echo "selected";}} ?>>Basketball</option>
								<option value="Baseball/Softball" <?php if($is_edit){if($sports2=='Baseball/Softball' ){echo "selected";}} ?>>Baseball/Softball</option>
								<option value="Boxing" <?php if($is_edit){if($sports2=='Boxing' ){echo "selected";}} ?>>Boxing</option>
								<option value="Football/Futsal" <?php if($is_edit){if($sports2=='Football/Futsal' ){echo "selected";}} ?>>Football/Futsal</option>
								<option value="Karate" <?php if($is_edit){if($sports2=='Karate' ){echo "selected";}} ?>>Karate</option>
								<option value="Lawn Tennis" <?php if($is_edit){if($sports2=='Lawn Tennis' ){echo "selected";}} ?>>Lawn Tennis</option>
								<option value="Pageant" <?php if($is_edit){if($sports2=='Pageant' ){echo "selected";}} ?>>Pageant</option>
								<option value="Softball" <?php if($is_edit){if($sports2=='Softball' ){echo "selected";}} ?>>Softball</option>
								<option value="Swimming" <?php if($is_edit){if($sports2=='Swimming' ){echo "selected";}} ?>>Swimming</option>
								<option value="Taekwondo" <?php if($is_edit){if($sports1=='Taekwondo' ){echo "selected";}} ?>>Taekwondo</option>
								<option value="Table Tennis" <?php if($is_edit){if($sports2=='Table Tennis' ){echo "selected";}} ?>>Table Tennis</option>
								<option value="Volleyball/Beach Volleyball" <?php if($is_edit){if($sports2=='Volleyball/Beach Volleyball' ){echo "selected";}} ?>>Volleyball/Beach Volleyball</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Talent"> <span class="input-group-text"> <i class="fas fa-music fa-fw"></i> </span>
							</div>
							<select class="form-control" name="talent">
								<option value="Dancing" <?php if($is_edit){if($talent=='Dancing' ){echo "selected";}} ?>>Dancing</option>
								<option value="Singing" <?php if($is_edit){if($talent=='Singing' ){echo "selected";}} ?>>Singing</option>
								<option value="NONE" <?php if($is_edit){if($talent=='NONE' ){echo "selected";}} ?>>NONE</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Father's Name"> <span class="input-group-text"> <i class="fas fa-male fa-fw"></i> </span>
							</div> <input type="text" class="form-control" name="father" placeholder="Father's Name" value="<?php if($is_edit) {echo $father;} ?>">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Mother's Name"> <span class="input-group-text"> <i class="fas fa-female fa-fw"></i> </span>
							</div> <input type="text" class="form-control" name="mother" placeholder="Mother's Name" value="<?php if($is_edit){echo $mother;} ?>">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Guardian"> <span class="input-group-text"> <i class="fas fa-user-shield fa-fw"></i> </span>
							</div> <input type="text" class="form-control" name="guardian" placeholder="Guardian" value="<?php if($is_edit) {echo $guardian;} ?>">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Parent's Address"> <span class="input-group-text"> <i class="fas fa-address-book fa-fw"></i> </span>
							</div> <input type="text" class="form-control" name="parent_address" placeholder="Parent's Address" value="<?php if($is_edit) {echo $parent_address;}?>">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Guardian's Address"> <span class="input-group-text"> <i class="far fa-address-book fa-fw"></i> </span>
							</div> <input type="text" class="form-control" name="guardian_address" placeholder="Guardian's Address" value="<?php if($is_edit) {echo $guardian_address;} ?>">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Contact Number"> <span class="input-group-text"> <i class="fas fa-phone fa-fw"></i> </span>
							</div> <input type="text" class="form-control" name="contact_no" placeholder="Contact Number" value="<?php if($is_edit){echo $contact_no;} ?>">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="High School/Senior High School"> <span class="input-group-text"> <i class="fas fa-school fa-fw"></i> </span>
							</div> <input type="text" class="form-control" name="high_school" placeholder="High School/Senior High School" maxlength="90" value="<?php if ($is_edit) {echo $high_school;} ?>">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Date Graduated (High School/Senior High School)"> <span class="input-group-text"> <i class="far fa-calendar-alt fa-fw"></i> </span>
							</div> <input type="Date" class="form-control" name="high_school_date" placeholder="High School/Senior High School" value="<?php if($is_edit) {echo $high_school_date;} ?>">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="For 2nd Course Takers: College"> <span class="input-group-text"> <i class="fas fa-university fa-fw"></i> </span>
							</div> <input type="text" class="form-control" name="college" placeholder="For 2nd Course Takers: College School" maxlength="90" value="<?php if($is_edit) {echo $college;} ?>">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="For 2nd Course Takers: Date Graduated (College)"> <span class="input-group-text"> <i class="far fa-calendar-alt fa-fw"></i> </span>
							</div> <input type="Date" class="form-control" name="college_date" placeholder="For 2nd Course Takers: Date Graduated" value="<?php if($is_edit) {echo $college_date;} ?>">
						</div>
					</div>
					<div class="form-group">
						<div class="spacer"></div>
					</div>
					<div class="fixed-bottom" style="background-color: lightgray;">
						<div class="text-center" style="padding:5px 0 5px 0;"> <button id="idsubmit" class="btn btn-success" type="submit" value="Register" name="action"><i class="fas fa-save"></i> Update</button> <button id="idreset" class="btn btn-danger" type="reset" value="Reset" name="reset"><i class="fas fa-eraser"></i> Reset</button> <button id="idlogout" class="btn btn-primary" type="submit" value="Logout" name="action"><i class="fas fa-power-off"></i> Logout</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>