<?php
     include_once('connect.php');
     $qry =  $_POST['qry'];
          
     $stmt = $pdo->prepare("SELECT idstudent, idcourse, idnumber, lname, fname, dob FROM student WHERE lname LIKE :lname OR idnumber = :idnumber ORDER BY lname ASC, fname ASC;");
     $stmt->bindValue(':lname', $qry.'%');
     $stmt->bindValue(':idnumber', $qry);
     $stmt->execute();
     if ($stmt->rowCount() == 0) {die('<div class="alert alert-danger text-center"><strong>EMPTY</strong></div>');}
?>

<table class="table-bordered" width="100%" id="search_result">
	<thead>
          <th style="width:100px;">ACTION</th>
		<th>NAME</th>
		<th style="width:140px;">ID NUMBER</th>			
	</thead>
	<tbody>	
<?php		
		foreach($stmt as $row) {
		?>
			<tr>
                    <td>                         
                         <button type="button" class="btn btn-info btn-sm" name="edit"><i class="fas fa-pen fa-sm"></i></button>
                         <button type="button" class="btn btn-danger btn-sm" name="delete"><i class="far fa-trash-alt fa-sm"></i></button>
                         <input type="hidden" name="idstudent" value="<?php echo $row["idstudent"]; ?>"/>
                         <input type="hidden" name="idcourse" value="<?php echo $row["idcourse"]; ?>"/>
                         <input type="hidden" name="lname" value="<?php echo $row["lname"]; ?>"/>
                         <input type="hidden" name="fname" value="<?php echo $row["fname"]; ?>"/>
                         <input type="hidden" name="dob" value="<?php echo $row["dob"]; ?>"/>
                         <input type="hidden" name="idnumber" value="<?php echo $row["idnumber"]; ?>"/>
                    </td>
                    <td>				                          				
                         <?php echo strtoupper($row['lname']).', '.strtoupper($row['fname']); ?>
                    </td>			
                    <td><?php echo $row['idnumber']; ?> </td>                    		
			</tr>
		<?php
		}
		?>					
	</tbody>
</table>