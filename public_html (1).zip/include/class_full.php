<?php
		
include_once("function.php");	
$idcurriculum = $_POST['idcurriculum'];
$idsection = $_POST['idsection'];
$idsem_settings = $_POST['idsem_settings'];
$idsched = $_POST['idsched'];

/*$idcurriculum = 2;
$idsection = 4;*/
$res = "";

if(get_class_full_settings($idsem_settings) == 0) { /*======Subject Full==========================*/
	$student = $pdo->prepare('SELECT COUNT(*) FROM student_sched WHERE idsched = ? AND is_chair_approved = 1');

	$student->execute([$idsched]);
	$total_student = $student->fetchColumn();				
	$total_student++;

	if(($total_student) > get_subject_size($idsched)) {
		$res = '<span class="text-danger">THE CLASS IS FULL.</span>';
	}
	
}else{ /*======Room Full==========================*/
	
	$stmt = $pdo->prepare("SELECT idroom, idsched FROM sched WHERE idcurriculum = ? AND idsection = ?;");
	$stmt->execute([$idcurriculum, $idsection]);

	foreach($stmt as $row) {
		$room = $pdo->prepare('SELECT COUNT(*) FROM student_sched WHERE idsched = ? AND is_chair_approved = 1');
		$room->execute([$row['idsched']]);
		$room_size = $room->fetchColumn();
				
		$room_size++;
		
		if(($room_size) > get_room_size($row['idroom'])) {
			$res = '<span class="text-danger">THE CLASS IS FULL.</span>';
			break;
		}
	}
}

	
echo $res;
?>