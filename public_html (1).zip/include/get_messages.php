<?php
     include_once("connect.php");     
     $idfaculty = $_POST['idfaculty'];
     $idsem_settings = $_POST['idsem_settings'];
     $stmt = $pdo->prepare("SELECT msg.*, UPPER(CONCAT(student.fname,' ',student.lname)) AS stud_name,                              
                              date_format(msg.date_sent, '%b %d') AS date_msg_sent
                              FROM msg 
                              INNER JOIN student USING(idstudent) 
                              WHERE msg.idfaculty = ? AND msg.idsem_settings = ?");
     $stmt->execute([$idfaculty, $idsem_settings]);

     foreach($stmt as $row) {
?>
     <div style="margin-bottom: 5px;" class="text-left">          
          <span style="padding: 3px 10px 10px 10px; line-height:1.2em; font-family:Century Gothic; font-weight:normal;" class="text-left badge badge-primary">
               <i style="display:inline-block;font:normal 0.6em tahoma; margin-bottom:10px;">TO <?php echo $row['stud_name'].' ['.$row['date_msg_sent'].']' ?></i>
               <br>
               <?php echo wordwrap($row['message'],25,'<br />',true); ?>
               <?php if($row['is_seen']==1) { echo '<br/><i style="display:inline-block;font:normal 0.6em tahoma; margin-top:10px;" class="badge badge-warning">SEEN</i>';} ?>
          </span>
     </div>
<?php
}
?>