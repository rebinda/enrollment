<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

//$host = 'localhost';
//$db = 'bcaabayc_psusched';
//$user = 'bcaabayc_psusched';
//$pwd = 'T0p53cr3t';
//$charset = 'utf8mb4';
//$port = 3303;
date_default_timezone_set("Asia/Manila");
//$host = 'localhost';
//$db = 'psu_sched';
//$user = 'root';
//$pwd = '';
//$charset = 'utf8mb4';
//$port = 3306;

$host = 'localhost';
$db = 'u502118279_psu_sched';
$user = 'u502118279_root';
$pwd = 'T0p53cret12345';
$charset = 'utf8mb4';
$port = 3306;

$dsn = "mysql:host=$host;dbname=$db;charset=$charset;port=$port";

$option =[PDO::ATTR_ERRMODE 			=> PDO::ERRMODE_EXCEPTION,
		 PDO::ATTR_DEFAULT_FETCH_MODE	=> PDO::FETCH_ASSOC,
		 PDO::ATTR_EMULATE_PREPARES		=> false];


/*$option =[PDO::ATTR_DEFAULT_FETCH_MODE	=> PDO::FETCH_ASSOC,
		 PDO::ATTR_EMULATE_PREPARES		=> false];

*/
$pdo= new PDO($dsn,$user,$pwd,$option);

?>