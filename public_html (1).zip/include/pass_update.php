<?php
include_once("function.php");
	$idstudent = $_POST['idstudent'];
	$pass = $_POST['pass'];
	$stmt = $pdo->prepare("UPDATE student SET pwd = ? WHERE idstudent = ?");
     
$res = $stmt->execute([$pass, $idstudent]);

echo $res;
?>