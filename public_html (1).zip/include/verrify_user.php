<?php
include_once("function.php");
	$idstudent = $_POST['idstudent'];
	$pass = $_POST['pass'];
	$stmt = $pdo->prepare("SELECT COUNT(*) 
FROM student 
WHERE idstudent=?
AND pwd = ?;");
     
$stmt->execute([$idstudent, $pass]);

echo $stmt->fetchColumn();
?>