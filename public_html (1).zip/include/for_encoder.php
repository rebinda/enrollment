
<table class="table-bordered" width="100%" id="sched_block">
	<thead>		
		<th colspan="2">Code</th>		
		<th class="title">Title</th>
		<th class="unit">Units</th>
		<th>Day</th>
		<th>Time</th>
		<th class="room">Room</th>
	</thead>
	<tbody>
		<?php
		foreach($stmt as $row) {
			if($row['is_chair_approved']==1 && $row['is_adviser_approved']==1) {
		?>	
			<tr>
			<td>
				<small class="text-success"><strong>DONE</strong></small>
				<input type="hidden" name="idsched" value="<?php echo $row["idsched"]; ?>"/>
				<input type="hidden" name="idcurriculum" value="<?php echo $row["idcurriculum"]; ?>"/>
				<input type="hidden" name="idsection" value="<?php echo $row["idsection"]; ?>"/>
			</td>
			<td><span class="subj text-success"><strong><?php echo $row['subj'];?></strong></span></td>
				<td class="title text-success"><strong><?php echo $row['description']; ?></strong></td>
			<td class="unit text-success"><strong><?php echo $row['unit']; ?></strong> </td>
			<td class="text-success"><strong><?php echo $row['week_day_name']; ?> </strong></td>
			<td class="text-success"><strong><?php echo $row['class_time']; ?> </strong></td>
			<td class="room text-success"><strong><?php echo $row['room']; ?> </strong></td>
			</tr>
		<?php
		} elseif($row['is_chair_approved']==0 && $row['is_adviser_approved']==1) { ?>
			<tr>
			<td>
				<small class="text-warning">PENDING</small>
				<input type="hidden" name="idsched" value="<?php echo $row["idsched"]; ?>"/>
				<input type="hidden" name="idcurriculum" value="<?php echo $row["idcurriculum"]; ?>"/>
				<input type="hidden" name="idsection" value="<?php echo $row["idsection"]; ?>"/>
			</td>
			<td><span class="subj text-warning"><?php echo $row['subj'];?> </span></td>
			<td class="title text-warning"><?php echo $row['description']; ?> </td>
			<td class="unit text-warning"><?php echo $row['unit']; ?> </td>
			<td class="text-warning"><?php echo $row['week_day_name']; ?> </td>
			<td class="text-warning"><?php echo $row['class_time']; ?> </td>
			<td class="room text-warning"><?php echo $row['room']; ?> </td>
			</tr>
		<?php				
			}elseif($row['is_chair_approved']==0 && $row['is_adviser_approved']==0) { ?>
			<tr>
			<td>
				<small class="text-danger">PENDING</small>
				<input type="hidden" name="idsched" value="<?php echo $row["idsched"]; ?>"/>
				<input type="hidden" name="idcurriculum" value="<?php echo $row["idcurriculum"]; ?>"/>
				<input type="hidden" name="idsection" value="<?php echo $row["idsection"]; ?>"/>
			</td>
			<td><span class="subj text-danger"><?php echo $row['subj'];?> </span></td>
			<td class="title text-danger"><?php echo $row['description']; ?> </td>
			<td class="unit text-danger"><?php echo $row['unit']; ?> </td>
			<td class="text-danger"><?php echo $row['week_day_name']; ?> </td>
			<td class="text-danger"><?php echo $row['class_time']; ?> </td>
			<td class="room text-danger"><?php echo $row['room']; ?> </td>
			</tr>
		<?php				
			}
		}
		?>
	</tbody>
</table>
<div id="total_units" class="alert alert-success text-right" style="margin-bottom: 80px;"><?php echo 'TOTAL UNITS: <strong>'.get_total_student_units($idsem_settings, $idstudent,2, $idqueue_to_approve).'</strong>'; ?></div>