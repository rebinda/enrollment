<?php
     include_once("connect.php");     
     $idstudent = $_POST['idstudent'];
     $idsem_settings = $_POST['idsem_settings'];     

     $stmt = $pdo->prepare("SELECT msg.*, UPPER(CONCAT(faculty.fname,' ',faculty.lname)) AS adviser,
                              date_format(msg.date_sent,'%b %d') AS date_received
                              FROM msg 
                              INNER JOIN faculty USING(idfaculty) 
                              WHERE msg.idstudent = ? AND msg.idsem_settings = ?");
     $stmt->execute([$idstudent, $idsem_settings]);

     foreach($stmt as $row) {
?>
     <div style="margin-bottom: 3px;" class="text-left ">          
          <span style="padding: 3px 10px 10px 10px; line-height:1.2em; font-family:Century Gothic; font-weight:normal;" class="text-left badge badge-primary">
               <i style="display:inline-block;font:normal 0.6em tahoma; margin-bottom:10px;"><?php echo $row['adviser'].' ['.$row['date_received'].']'; ?></i>
               <br>
               <?php echo wordwrap($row['message'],25,'<br />',true); ?>
          </span>
     </div>
<?php
}
?>