<?php
include_once("function.php");
session_start();
if (!isset($_SESSION['is_faculty_login'])) {die("<div class=\"alert alert-danger\"><i class=\"fas fa-exclamation\" style=\"font-size:24px;\"></i> <strong> YOU NEED TO LOGIN!</strong></div>");}

$idsem_settings = $_POST['idsem_settings'];
$idq = $_POST['idq'];
$idstudent = $_POST['idstudent'];
$idqueue_to_approve = $_POST['idqueue_to_approve'];
//THE COMMENTED SQL is only applicable on Localhost AND NON-SHARED web hosting
//The commented SQL does not work on Shared Web Hosting.

/*$qry = "SELECT sched_complete.*		
		FROM sched_complete
		INNER JOIN student_sched USING(idsched)
		INNER JOIN queue USING(idstudent)		
		WHERE student_sched.is_adviser_approved = 1
			AND student_sched.is_chair_approved = 1
			AND queue.idsem_settings = ? 
			AND queue.idqueue = ? 
		ORDER BY sched_complete.idcurriculum ASC;";*/
$qry = "SELECT tmp_sched.*, UPPER(faculty.lname) AS adviser
		FROM (SELECT 
        tmp.idsched AS idsched,
        tmp.days AS days,
        tmp.idsection AS idsection,
        (CASE tmp.days
            WHEN 0 THEN 'MON'
            WHEN 1 THEN 'TUE'
            WHEN 2 THEN 'WED'
            WHEN 3 THEN 'THU'
            WHEN 4 THEN 'FRI'
            WHEN 5 THEN 'SAT'
            WHEN 6 THEN 'SUN'
        END) AS week_day_name,
        tmp.idcurriculum AS idcurriculum,
        CONCAT(TIME_FORMAT(tmp.start_time, '%h:%i'),'-', TIME_FORMAT(tmp.end_time, '%h:%i')) AS class_time,
        tmp.subj AS subj,
		curriculum.description AS description,
        IF((curriculum.lab_unit = 0),curriculum.lec_unit, CONCAT(curriculum.lec_unit, '/', curriculum.lab_unit)) AS unit,
        room.room AS room
    FROM
        (((SELECT 
            sched.idsched AS idsched,
                sched.days AS days,
                sched.idcurriculum AS idcurriculum,
                sched.idroom AS idroom,
                sched.idsection AS idsection,
                TIME_FORMAT(sched.s_time, '%h:%i %p') AS start_time,
                TIME_FORMAT(sched.e_time, '%h:%i %p') AS end_time,
                GET_MERGED_SCHED(sched.idsched) AS subj
        FROM
            (sched
        LEFT JOIN sched_merged ON sched.idsched = sched_merged.merged_with)
        WHERE
            sched.is_merge = 0) UNION ALL SELECT 
            u.idsched AS idsched,
                u.days AS days,
                u.idcurriculum AS idcurriculum,
                u.idsection AS idsection,
                u.idroom AS idroom,
                u.start_time AS start_time,
                u.end_time AS end_time,
                u.subj AS subj
        FROM
            ((SELECT 
            sched.idsched AS idsched,
                sched_merged.merged_with AS merged_with,
                sched.days AS days,
                sched.idcurriculum AS idcurriculum,
                sched.idsection AS idsection,
                sched.idroom AS idroom,
                TIME_FORMAT(sched.s_time, '%h:%i %p') AS start_time,
                TIME_FORMAT(sched.e_time, '%h:%i %p') AS end_time,
                GET_MERGED_CHILD(sched.idsched) AS subj
        FROM
            (sched
        LEFT JOIN sched_merged ON sched.idsched = sched_merged.idsched)
        WHERE sched.is_merge = 1) m
        JOIN (SELECT 
            sched.idsched AS idsched,
                sched.days AS days,
                sched.idcurriculum AS idcurriculum,
                sched.idsection AS idsection,
                sched.idroom AS idroom,
                TIME_FORMAT(sched.s_time, '%h:%i %p') AS start_time,
                TIME_FORMAT(sched.e_time, '%h:%i %p') AS end_time,
                GET_MERGED_SCHED(sched.idsched) AS `subj`
        FROM
            (sched
        JOIN sched_merged ON sched.idsched = sched_merged.merged_with)
        WHERE
            sched.is_merge = 0) u)
        WHERE
            m.merged_with = u.idsched) tmp
        JOIN curriculum ON tmp.idcurriculum = curriculum.idcurriculum)
        JOIN room ON tmp.idroom = room.idroom
    GROUP BY tmp.idsched
    ORDER BY tmp.idcurriculum) AS tmp_sched
		INNER JOIN student_sched USING(idsched)
		INNER JOIN queue USING(idstudent)
          INNER JOIN faculty ON student_sched.idadviser = faculty.idfaculty 
		WHERE student_sched.is_adviser_approved = 1
			AND student_sched.is_chair_approved = 1
               AND student_sched.idsem_settings = ? 
               AND student_sched.idqueue_to_approve = ? 
			AND queue.idsem_settings = ? 
			AND queue.idqueue = ? 
		ORDER BY tmp_sched.idcurriculum ASC;";


$stmt = $pdo->prepare($qry);	
$stmt->execute([$idsem_settings, $idqueue_to_approve, $idsem_settings, $idq]);
?>

<table class="sched_block table-bordered" width="100%">
	<thead>		
		<th>Code</th>		
		<th class="title">Title</th>
		<th class="unit">Units</th>
		<th>Day</th>
		<th>Time</th>
		<th class="room">Room</th>
          <th>Adviser</th>
	</thead>
	<tbody>
		<?php
		foreach($stmt as $row) {			
		?>	
			<tr>		
			<td><span class="subj text-info"><strong><?php echo $row['subj'];?></strong></span>
				<input type="hidden" name="idsched" value="<?php echo $row["idsched"]; ?>"/>
				<input type="hidden" name="idcurriculum" value="<?php echo $row["idcurriculum"]; ?>"/>
				<input type="hidden" name="idsection" value="<?php echo $row["idsection"]; ?>"/>
			</td>
				<td class="title text-info"><?php echo $row['description']; ?></td>
			<td class="unit text-info"><?php echo $row['unit']; ?></td>
			<td class="text-info"><?php echo $row['week_day_name']; ?></td>
			<td class="text-info"><?php echo $row['class_time']; ?></td>
			<td class="room text-info"><?php echo $row['room']; ?></td>
               <td class="text-info"><?php echo $row['adviser']; ?></td>
			</tr>
		<?php		
		}
		?>
	</tbody>
</table>
<div id="total_units" class="alert alert-success text-right" style="margin-bottom: 0px;"><?php echo 'TOTAL UNITS: <strong>'.get_total_student_units($idsem_settings, $idstudent, 2, $idqueue_to_approve).'</strong>'; ?></div>