<?php
     include_once("connect.php");
     $idstudent = $_POST['idstudent'];
     $idsem_settings = $_POST['idsem_settings'];

     $stmt = $pdo->prepare('SELECT COUNT(*) FROM student_sched WHERE idstudent=? AND idsem_settings=?');
     $stmt->execute([$idstudent, $idsem_settings]);
          
     $row = $stmt->fetchColumn();
     
     echo $row;     
?>