<?php
     include_once("connect.php");     
     $idstudent = $_POST['idstudent'];
     $idsem_settings = $_POST['idsem_settings'];

     $stmt = $pdo->prepare("UPDATE msg SET is_seen = 1 WHERE idstudent = ? AND idsem_settings = ?");
     $stmt->execute([$idstudent, $idsem_settings]);
?>