<?php
	include_once("function.php");
	$idfaculty = $_POST['idfaculty'];
	$idstud_sched = $_POST['idstud_sched'];
	$stmt = $pdo->prepare("SELECT COUNT(*) 
FROM sched 
INNER JOIN student_sched USING(idsched)
INNER JOIN curriculum USING(idcurriculum)
INNER JOIN curriculum_name USING(idcurriculum_name)
INNER JOIN (course INNER JOIN faculty USING(iddept)) ON course.idcourse = curriculum_name.idcourse
WHERE student_sched.idstudent_sched=?
AND faculty.idfaculty=?;");
     
$stmt->execute([$idstud_sched, $idfaculty]);

echo $stmt->fetchColumn();

?>