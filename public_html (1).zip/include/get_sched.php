<?php
include_once("function.php");
$idsection = $_POST['idsection'];
$idstudent = $_POST['idstudent'];
$idsem_settings = $_POST['idsem_settings'];

/*======NOTE: Working with merged subjects
     In order for is_sched_exist and 
     is_sched_exist_in_tmp_sched functions to work,
     the first encoded subject must be the parent
     of the second encoded subject.
========*/

/*$qry = "SELECT tmp.idsched,
		(CASE tmp.days
			  WHEN 0 THEN 'MON'
			  WHEN 1 THEN 'TUE'
			  WHEN 2 THEN 'WED'
			  WHEN 3 THEN 'THU'
			  WHEN 4 THEN 'FRI'
			  WHEN 5 THEN 'SAT'
			  WHEN 6 THEN 'SUN' END) AS week_day_name, 
			tmp.idcurriculum, 
			tmp.idroom, 
			tmp.idsection, 
			tmp.idfaculty, 
			CONCAT(TIME_FORMAT(tmp.start_time, '%h:%i'),'-',TIME_FORMAT(tmp.end_time, '%h:%i')) AS class_time,
			tmp.subj, 
			curriculum.description,
			section.section_name,
			IF(curriculum.lab_unit = 0, curriculum.lec_unit,CONCAT(curriculum.lec_unit,'/',curriculum.lab_unit)) AS unit,
			room.room, 
			UPPER(CONCAT(faculty.lname, ', ',faculty.fname)) AS faculty_name 
		FROM (SELECT sched.idsched, 
			IF(sched.is_merge = 1, get_col_of_merge_sched(sched.idsched, 3), sched.days) AS days, 
			IF(sched.is_merge = 1, get_col_of_merge_sched(sched.idsched, 4), sched.idcurriculum) AS idcurriculum,
			IF(sched.is_merge = 1, get_col_of_merge_sched(sched.idsched, 5), sched.idroom) AS idroom, 
			sched.idsection, 
			IF(sched.is_merge = 1, get_col_of_merge_sched(sched.idsched, 7), sched.idfaculty) AS idfaculty, 
			IF(sched.is_merge = 1, get_col_of_merge_sched(sched.idsched, 1), TIME_FORMAT(sched.s_time, '%h:%i %p')) AS start_time, 
			IF(sched.is_merge = 1, get_col_of_merge_sched(sched.idsched, 2), TIME_FORMAT(sched.e_time, '%h:%i %p')) AS end_time, 
			IF(sched.is_merge = 1, get_merged_child(sched.idsched), get_merged_sched(sched.idsched)) AS subj 
		  FROM sched 
		  WHERE sched.idsection = ?) AS tmp 
		  INNER JOIN curriculum USING(idcurriculum) 
		  INNER JOIN room USING(idroom) 
		  INNER JOIN section USING(idsection) 
		  LEFT JOIN faculty USING(idfaculty)
		  ORDER BY idcurriculum, idroom ASC;"; */

$stmt = $pdo->prepare("CALL show_sched(:idsection, :idsem_settings)");
$stmt->bindParam(':idsection',$idsection,PDO::PARAM_INT);
$stmt->bindParam(':idsem_settings',$idsem_settings,PDO::PARAM_INT);
$stmt->execute();
$data = $stmt->fetchAll();
$stmt->nextRowset();

$day = get_pef_status($idsem_settings, 'is_day_visible');
$time =  get_pef_status($idsem_settings, 'is_time_visible');
$room =  get_pef_status($idsem_settings, 'is_room_visible');
?>
<?php
/*if (has_survey($idstudent)) {
}else {
	echo '<button class="btn btn-danger" style="margin-bottom:10px;" onclick="document.location = \'dp.php\'"><i class="fas fa-edit fa-lg"></i> Take Survey</button>';
}*/
?>
<table class="table-bordered" width="100%" id="sched_block" style="margin-bottom: 80px;">
	<thead>		
		<th colspan="2">Code</th>
		<th class="title">Title</th>
		<th class="unit">Units</th>
		<th class="day" <?php if($day==0){echo 'style="display:none;"';} ?>>Day</th>
		<th class="time" <?php if($time==0){echo 'style="display:none;"';} ?>>Time</th>		
		<th class="room" <?php if($room==0){echo 'style="display:none;"';} ?>>Room</th>
	</thead>
	<tbody>		
		<?php		
		foreach($data as $row) {
		?>
			<tr>
			<td>
				<?php                         
                         //echo $idstudent.' '.$idsem_settings.' '.$row["idcurriculum"].' '.$idsection;
					/*if ((is_sched_exist($idstudent, $idsem_settings, $row["idcurriculum"], $idsection)> 0) || (is_sched_exist_in_tmp_sched($idstudent, $idsem_settings, $row["idcurriculum"], $idsection)> 0)) {
						echo '<button class="btn btn-dark" disabled="disabled" chosen="2">GET</button>';
					}
					else {*/
						echo '<button class="btn btn-success" chosen="0">GET</button>';						
					/*}*/               
				?>	
					<input type="hidden" name="idsched" value="<?php echo $row["idsched"]; ?>"/>
					<input type="hidden" name="idcurriculum" value="<?php echo $row["idcurriculum"]; ?>"/>
					<input type="hidden" name="idsection" value="<?php echo $row["idsection"]; ?>"/>							
			</td>
			<td>				
				<span class="subj"><?php echo $row['subj']; ?> </span>
			</td>					
			<td class="title"><?php echo $row['description']; ?> </td>
			<td class="unit"><?php echo $row['unit']; ?> </td>
			<td class="day" <?php if($day==0){echo 'style="display:none;"';} ?>><?php echo $row['week_day_name']; ?> </td>
			<td class="time" <?php if($time==0){echo 'style="display:none;"';} ?>><?php echo $row['class_time']; ?> </td>
			<td class="room" <?php if($room==0){echo 'style="display:none;"';} ?>><?php echo $row['room']; ?> </td>
			</tr>
		<?php
		}
		?>					
	</tbody>
</table>