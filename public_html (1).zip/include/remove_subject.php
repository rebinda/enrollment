<?php
     include_once("function.php");

     $message = 'You are not eligible to take '.$_POST['codes'].'. Because '.$_POST['message'];
     $idnumber = $_POST['idstudent'];
     $idstudent = get_idstudent($idnumber);
     $idfaculty = $_POST['idfaculty'];     
     $idsem_settings = $_POST['idsem_settings'];

     $mydate = date('Y-m-d');
     $idcurriculum = $_POST['idcurr'];
     
     $stmt = $pdo->prepare("DELETE FROM student_sched WHERE idstudent = ? AND idsem_settings = ? AND idsched IN (SELECT idsched FROM sched WHERE idcurriculum = ? );");
     $stmt->execute([$idstudent, $idsem_settings, $idcurriculum]);

     //Check if there are remaining subjects
     $student = $pdo->prepare("SELECT * FROM student_sched WHERE idstudent = ? AND idsem_settings = ?");
     $student->execute([$idstudent, $idsem_settings]);

     //If no subjects then remove student from queue_to_approve
     if($student->rowCount() == 0) {
          $stmt = $pdo->prepare('DELETE FROM queue_to_approve WHERE idstudent=? AND idsem_settings=?');
          $stmt->execute([$idstudent, $idsem_settings]);
     }

     $stmt = $pdo->prepare("INSERT INTO msg(idfaculty, idstudent, message, idsem_settings, date_sent) VALUES(?, ?, ?, ?, ?);");
     $stmt->execute([$idfaculty, $idstudent, $message, $idsem_settings, $mydate]);     
     echo($idcurriculum); 
?>