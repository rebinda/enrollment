<?php
//$is_encoded = false;
//if (is_encoded($idstudent, $idsem_settings)>0){ $is_encoded = true;} else{?>
<button style="margin-bottom:10px;" class="btn btn-success" id="idapprove_all"><i class="far fa-thumbs-up fa-lg"></i> <small>APPROVE ALL</small></button>
<button style="margin-bottom:10px;" class="btn btn-danger" id="iddisapprove_all"><i class="far fa-thumbs-down fa-lg"></i> <small>DISAPPROVE ALL</small></button>
<div class="clearfix"></div>
<?php
//}
?>

<?php
     if (!has_first_adviser_approved($idstudent, $idsem_settings)>0) {
          echo '<div class="alert alert-danger"><i class="fas fa-exclamation" style="font-size:24px;"></i> <strong> Request Denied. The 1<sup>st</sup> Adviser did not add this student into the QUEUE.</strong></div>';
     }else{
?>          

<table class="table-bordered" width="100%" id="sched_block">
	<thead>		
		<th colspan="2">Code</th>		
		<th class="title">Title</th>
		<th class="unit">Units</th>
		<th>Day</th>
		<th>Time</th>
		<th class="room">Room</th>
	</thead>
	<tbody>
		<?php
		$class='';
		foreach($stmt as $row) {
			if($row['is_adviser_approved']==0 && $row['is_chair_approved']==0) {
				$class = "text-danger";
			}
			elseif($row['is_adviser_approved']==1 && $row['is_chair_approved']==0) {
				$class="text-warning";
			}elseif($row['is_adviser_approved']==1 && $row['is_chair_approved']==1) {
				$class="text-success";
			}
		?>	
			<tr>
			<td>
				<?php /*if(!$is_encoded) {*/if($row['is_adviser_approved']==0) {echo '<small class="text-muted">PENDING</small>';} else {?>
				<button name="approve" stat="<?php if($row['is_chair_approved']==0){echo '0';} else {echo '1';} ?>" class="btn <?php if($row['is_chair_approved']==0) {echo 'btn-danger';} else{echo 'btn-success';} ?>"> <?php if($row['is_chair_approved']==0){echo '<i class="far fa-thumbs-down fa-lg"></i>';} else{echo '<i class="far fa-thumbs-up fa-lg"></i>';}?> </button>
				<?php }/*}*/?>
				<input type="hidden" name="idsched" value="<?php echo $row["idsched"]; ?>"/>
				<input type="hidden" name="idstud_sched" value="<?php echo $row["idstudent_sched"]; ?>"/>
				<input type="hidden" name="idcurriculum" value="<?php echo $row["idcurriculum"]; ?>"/>
				<input type="hidden" name="idsection" value="<?php echo $row["idsection"]; ?>"/>
			</td>			
			<td><span class="subj <?php echo $class; ?>"><?php echo $row['subj'];?> </span></td>
			<td class="title <?php echo $class; ?>"><?php echo $row['description']; ?> </td>
			<td class="unit <?php echo $class; ?>"><?php echo $row['unit']; ?> </td>
			<td class="<?php echo $class; ?>"><?php echo $row['week_day_name']; ?> </td>
			<td class="<?php echo $class; ?>"><?php echo $row['class_time']; ?> </td>
			<td class="room <?php echo $class; ?>"><?php echo $row['room']; ?> </td>
			</tr>
		<?php
		}
		?>
	</tbody>
</table>
<div id="total_units" class="alert alert-success text-right" style="margin-bottom: 80px;"><?php echo 'TOTAL UNITS: <strong>'.get_total_student_units($idsem_settings, $idstudent, 2, $idqueue_to_approve).'</strong>'; ?></div>
<?php
     }
?>