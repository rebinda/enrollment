<?php
include_once("function.php");
session_start();
if (!isset($_SESSION['is_faculty_login'])) {die("<div class=\"alert alert-danger\"><i class=\"fas fa-exclamation\" style=\"font-size:24px;\"></i> <strong> YOU NEED TO LOGIN!</strong></div>");}

$idfaculty = $_SESSION['idfaculty'];
$idsem_settings = $_POST['idsem_settings'];
$idstudent = get_idstudent($_POST['idnumber']);
$idqueue_to_approve = $_POST['idqueue_to_approve'];
$iddept = $_POST['iddept'];
$role = $_POST['role'];

//$criteria = 'student_sched.idstudent';
$idcourse = get_idcourse_from_q($idqueue_to_approve);
$criteria = 'student_sched.idqueue_to_approve';


/*$stmt = $pdo->prepare("SELECT idsched, 
idcurriculum, section_name, subj, description, unit, week_day_name, class_time, room, faculty_name,
idstudent_sched, idstudent, idsem_settings, idsection, idcourse, IFNULL(is_adviser_approved,0) AS is_adviser_approved, IFNULL(is_chair_approved, 0) AS is_chair_approved, idadviser, idchair
FROM (SELECT sched.idsched,
                             sched.idcurriculum, 
                             section.section_name, 
                                get_merged_sched(sched.idsched) AS subj, 
                                curriculum.description, 
                                IF(curriculum.lab_unit = 0, curriculum.lec_unit,CONCAT(curriculum.lec_unit,'/',curriculum.lab_unit)) AS unit,
                                (CASE sched.days
                              WHEN 0 THEN 'MON' 
                              WHEN 1 THEN 'TUE'
                              WHEN 2 THEN 'WED'
                              WHEN 3 THEN 'THU' 
                              WHEN 4 THEN 'FRI' 
                              WHEN 5 THEN 'SAT' 
                              WHEN 6 THEN 'SUN' END) AS week_day_name, 
                                    CONCAT(TIME_FORMAT(sched.s_time, '%h:%i'),'-',TIME_FORMAT(sched.e_time, '%h:%i')) AS class_time, 
                                     room.room, 
                                     UPPER(CONCAT(faculty.lname, ', ',faculty.fname)) AS faculty_name
							 FROM sched 
                             LEFT JOIN faculty USING(idfaculty) 
                             INNER JOIN curriculum USING(idcurriculum) 
                             INNER JOIN curriculum_name USING(idcurriculum_name) 
                             INNER JOIN room USING(idroom) 
                             INNER JOIN section USING(idsection) 
                                        WHERE sched.is_merge = 0) AS tmp 
                            INNER JOIN student_sched USING(idsched) 
                            WHERE idsem_settings = ? AND idstudent = ? 
							ORDER BY idcurriculum ASC;");	*/

//THE COMMENTED SQL below is only applicable on Localhost AND NON-SHARED web hosting
//The commented SQL below (MySQL View) does not work on Shared Web Hosting.

/*$qry = "SELECT sched_complete.*, student_sched.idstudent_sched, 
			IFNULL(student_sched.is_adviser_approved, 0) AS is_adviser_approved,
			IFNULL(student_sched.is_chair_approved, 0) AS is_chair_approved
		FROM sched_complete
		INNER JOIN student_sched USING(idsched) 
		WHERE student_sched.idsem_settings = ? 
		AND student_sched.idstudent = ? 
		ORDER BY sched_complete.idcurriculum ASC;";*/

$qry = "SELECT tmp_sched.*, student_sched.idstudent_sched, 
			IFNULL(student_sched.is_adviser_approved, 0) AS is_adviser_approved,
			IFNULL(student_sched.is_chair_approved, 0) AS is_chair_approved
		FROM (SELECT 
        tmp.idsched AS idsched,
        tmp.days AS days,
        tmp.idsection AS idsection,
        (CASE tmp.days
            WHEN 0 THEN 'MON'
            WHEN 1 THEN 'TUE'
            WHEN 2 THEN 'WED'
            WHEN 3 THEN 'THU'
            WHEN 4 THEN 'FRI'
            WHEN 5 THEN 'SAT'
            WHEN 6 THEN 'SUN'
        END) AS week_day_name,
        tmp.idcurriculum AS idcurriculum,
        CONCAT(TIME_FORMAT(tmp.start_time, '%h:%i'),'-', TIME_FORMAT(tmp.end_time, '%h:%i')) AS class_time,
        tmp.subj AS subj,
		curriculum.description AS description,
        IF((curriculum.lab_unit = 0),curriculum.lec_unit, CONCAT(curriculum.lec_unit, '/', curriculum.lab_unit)) AS unit,
        room.room AS room
    FROM
        (((SELECT 
            sched.idsched AS idsched,
                sched.days AS days,
                sched.idcurriculum AS idcurriculum,
                sched.idroom AS idroom,
                sched.idsection AS idsection,
                TIME_FORMAT(sched.s_time, '%h:%i %p') AS start_time,
                TIME_FORMAT(sched.e_time, '%h:%i %p') AS end_time,
                GET_MERGED_SCHED(sched.idsched) AS subj
        FROM
            (sched
        LEFT JOIN sched_merged ON sched.idsched = sched_merged.merged_with)
        WHERE
            sched.is_merge = 0) UNION ALL SELECT 
            u.idsched AS idsched,
                u.days AS days,
                u.idcurriculum AS idcurriculum,
                u.idsection AS idsection,
                u.idroom AS idroom,
                u.start_time AS start_time,
                u.end_time AS end_time,
                u.subj AS subj
        FROM
            ((SELECT 
            sched.idsched AS idsched,
                sched_merged.merged_with AS merged_with,
                sched.days AS days,
                sched.idcurriculum AS idcurriculum,
                sched.idsection AS idsection,
                sched.idroom AS idroom,
                TIME_FORMAT(sched.s_time, '%h:%i %p') AS start_time,
                TIME_FORMAT(sched.e_time, '%h:%i %p') AS end_time,
                GET_MERGED_CHILD(sched.idsched) AS subj
        FROM
            (sched
        LEFT JOIN sched_merged ON sched.idsched = sched_merged.idsched)
        WHERE sched.is_merge = 1) m
        JOIN (SELECT 
            sched.idsched AS idsched,
                sched.days AS days,
                sched.idcurriculum AS idcurriculum,
                sched.idsection AS idsection,
                sched.idroom AS idroom,
                TIME_FORMAT(sched.s_time, '%h:%i %p') AS start_time,
                TIME_FORMAT(sched.e_time, '%h:%i %p') AS end_time,
                GET_MERGED_SCHED(sched.idsched) AS `subj`
        FROM
            (sched
        JOIN sched_merged ON sched.idsched = sched_merged.merged_with)
        WHERE
            sched.is_merge = 0) u)
        WHERE
            m.merged_with = u.idsched) tmp
        JOIN curriculum ON tmp.idcurriculum = curriculum.idcurriculum)
        JOIN room ON tmp.idroom = room.idroom
    GROUP BY tmp.idsched
    ORDER BY tmp.idcurriculum) AS tmp_sched
		INNER JOIN student_sched USING(idsched) 
		WHERE student_sched.idsem_settings = ? 
		AND {$criteria} = ? 
		ORDER BY tmp_sched.idcurriculum ASC;";
$stmt = $pdo->prepare($qry);
$student_name = '';
$course = '';
$cp = '';


$stmt->execute([$idsem_settings, $idqueue_to_approve]);     
$student_name = get_student_name_from_q($idqueue_to_approve);
$course = get_student_course_from_q($idqueue_to_approve);
$cp = get_student_cp_from_q($idqueue_to_approve);

?>

<div class="text-primary alert <?php if($student_name == "") {echo "alert-danger";} else{echo "alert-success";} ?>"><p style="padding:0px; margin:1px;"><small><strong>NAME: </strong><strong class="<?php if($student_name == "") {echo 'text-danger';} else {echo 'text-success';} ?>"><?php if($student_name == "") {echo "NOT FOUND!";} else {echo $student_name;}?></strong></small></p>
	<p style="padding:0px; margin:1px;"><small><strong>PROG: </strong><strong class="text-success"><?php echo strtoupper($course); ?></strong></small></p>
<?php if($student_name <> "") {?>
     <p style="padding:0px; margin:1px;"><small><strong>QSTAT: </strong><?php echo get_queue_stat_q($idqueue_to_approve, $idsem_settings, $iddept).' '.get_pef_progress($idsem_settings,$idstudent);?></small></p>
     <p style="padding:0px; margin:1px;"><small><strong>CP NO: </strong><strong class="text-success"><?php echo $cp; ?></strong></small></p>
     <p style="padding:0px; margin:1px;"><small><strong>PEF NO: </strong><strong class="text-success"><?php echo $idqueue_to_approve; ?></strong></small></p>
	<?php } ?>
</div>

<?php     
     if(!has_survey($idstudent) && $student_name<>"") {
         echo '<div class="alert alert-danger"><i class="fas fa-exclamation" style="font-size:24px;"></i> <strong> Advise the student to TAKE SURVEY so you can view the subjects.</strong></div>';
     }else{
          //if(is_infaculty_responsibility($idcourse, $idfaculty)>0) {                    
               if($role==1) {include_once('for_advising.php');}
               elseif($role==2) {include_once('for_encoder.php');}
               elseif($role==3) {include_once('for_chairperson.php');}
          /*}else {
               if ($student_name<>""){
                    echo '<div class="alert alert-danger"><small><i class="fas fa-exclamation" style="font-size:24px;"></i> <strong>'.get_faculty_name($idfaculty).'. You are <ins>NOT ELIGIBLE</ins> to approve subjects from <ins>'.strtoupper($course).'</ins>. The <ins>COURSE</ins> of the student was <ins>NOT DEFINED</ins> in your <ins>PEF RESPONSIBITY</ins>.</strong></small></div>';
               }
          }*/
     }	
?>