<?php
     include_once("connect.php");
     $idsem_settings = $_POST['idsem_settings'];
     $idstudent = $_POST['idstudent'];     
     $stmt = $pdo->prepare("SELECT idqueue_to_approve FROM queue_to_approve WHERE idsem_settings = ? AND idstudent = ?;");
     $stmt->execute([$idsem_settings, $idstudent]);

     echo '<option value="0">PEF Number</option>';
     if($stmt->rowCount() == 0) {return;}     
     foreach($stmt as $row) {
          echo '<option value="'.$row['idqueue_to_approve'].'">'.$row['idqueue_to_approve'].'</option>';
     }
?>