<?php
include_once("function.php");
$idsem_settings = $_POST['idsem_settings'];
$idstudent = $_POST['idstudent'];
//THE COMMENTED SQL is only applicable on Localhost AND NON-SHARED web hosting
//The commented SQL does not work on Shared Web Hosting.

/*$stmt = $pdo->prepare("SELECT sched_complete.*, 
		student_sched.is_adviser_approved,
		student_sched.is_chair_approved
	FROM sched_complete
	INNER JOIN student_sched USING(idsched) 
	WHERE student_sched.idsem_settings = ? 
	AND student_sched.idstudent = ? 
	ORDER BY sched_complete.idcurriculum ASC;");*/

$stmt = $pdo->prepare("SELECT 
                            * 
                            FROM 
                            (SELECT tmp.idsched,				
                                    tmp.idcurriculum,            
                                    tmp.days,           
                                    'main_sched' AS table_name,
                                    tmp.subj,        
                                    curriculum.description,            
                                    CONCAT(TIME_FORMAT(tmp.s_time, '%h:%i %p'),'-',TIME_FORMAT(tmp.e_time, '%h:%i %p')) AS class_time,
                                    (CASE tmp.days
                                    WHEN 0 THEN 'MON'
                                    WHEN 1 THEN 'TUE'
                                    WHEN 2 THEN 'WED'
                                    WHEN 3 THEN 'THU'
                                    WHEN 4 THEN 'FRI'
                                    WHEN 5 THEN 'SAT'
                                    WHEN 6 THEN 'SUN' END) AS week_day_name, 
                                    IF(curriculum.lab_unit = 0, curriculum.lec_unit,CONCAT(curriculum.lec_unit,'/',curriculum.lab_unit)) AS unit,
                                    room.room			
                            FROM            
                                (SELECT sched.idsched,					
                                    get_course_code(sched.idsched) AS code1,
                                    section.idsem_settings,
                                    sched.days,
                                    sched.idcurriculum,
                                    sched.idroom,
                                    sched.idsection, 
                                    sched.idfaculty,
                                    sched.s_time,
                                    sched.e_time,					
                                    get_merged_sched(sched.idsched) AS subj 
                                FROM sched LEFT join sched_merged ON sched.idsched = sched_merged.merged_with
                                INNER JOIN section ON sched.idsection = section.idsection
                                WHERE section.idsem_settings = ?
                                ) AS tmp
                            INNER JOIN curriculum USING(idcurriculum) 
                            INNER JOIN room USING(idroom) 
                            INNER JOIN section USING(idsection)
                            INNER JOIN student_sched
                            ON tmp.idsched = student_sched.idsched
                            AND tmp.idsem_settings = student_sched.idsem_settings  
                            WHERE student_sched.idstudent = ?  
                            GROUP BY tmp.idsched
                            ORDER BY idcurriculum ASC, tmp.idsched ASC) q1
                            UNION ALL
                            SELECT
                            *
                            FROM
                                (SELECT tmp.idsched,				
                                        tmp.idcurriculum,            
                                        tmp.days,           
                                        'tmp_sched' AS table_name,
                                        tmp.subj,        
                                        curriculum.description,            
                                        CONCAT(TIME_FORMAT(tmp.s_time, '%h:%i %p'),'-',TIME_FORMAT(tmp.e_time, '%h:%i %p')) AS class_time,
                                        (CASE tmp.days
                                        WHEN 0 THEN 'MON'
                                        WHEN 1 THEN 'TUE'
                                        WHEN 2 THEN 'WED'
                                        WHEN 3 THEN 'THU'
                                        WHEN 4 THEN 'FRI'
                                        WHEN 5 THEN 'SAT'
                                        WHEN 6 THEN 'SUN' END) AS week_day_name, 
                                        IF(curriculum.lab_unit = 0, curriculum.lec_unit,CONCAT(curriculum.lec_unit,'/',curriculum.lab_unit)) AS unit,
                                        room.room			
                                FROM            
                                    (SELECT sched.idsched,					
                                        get_course_code(sched.idsched) AS code1,
                                        section.idsem_settings,
                                        sched.days,
                                        sched.idcurriculum,
                                        sched.idroom,
                                        sched.idsection, 
                                        sched.idfaculty,
                                        sched.s_time,
                                        sched.e_time,					
                                        get_merged_sched(sched.idsched) AS subj 
                                    FROM sched LEFT join sched_merged ON sched.idsched = sched_merged.merged_with
                                    INNER JOIN section ON sched.idsection = section.idsection
                                    WHERE section.idsem_settings = ?
                                    ) AS tmp
                                INNER JOIN curriculum USING(idcurriculum) 
                                INNER JOIN room USING(idroom) 
                                INNER JOIN section USING(idsection)
                                INNER JOIN tmp_student_sched
                                ON tmp.idsched = tmp_student_sched.idsched
                                AND tmp.idsem_settings = tmp_student_sched.idsem_settings  
                                WHERE tmp_student_sched.idstudent = ?  
                                GROUP BY tmp.idsched
                                ORDER BY idcurriculum ASC, tmp.idsched ASC
                            ) AS q2;");

$stmt->execute([$idsem_settings, $idstudent, $idsem_settings, $idstudent]);
$class = '';	

$day = get_pef_status($idsem_settings, 'is_day_visible');
$time =  get_pef_status($idsem_settings, 'is_time_visible');
$room =  get_pef_status($idsem_settings, 'is_room_visible');
?>

<div class="alert alert-info"><i class="fas fa-check-circle text-success" style="font-size:1.2em;"></i><small><strong style="font-size:0.8em; vertical-align: 3px;"> SUBMITTED</strong></small> <span style="font-size:1.5em;"> |</span>
<i class="fas fa-times-circle text-danger" style="font-size:1.2em;"></i><small><strong style="font-size:0.8em; vertical-align: 3px;"> NOT SUBMITTED</strong></small></div>


<table class="table-bordered" width="100%" id="pef" style="font-size: 0.8em">
	<thead>		
		<th colspan="2">Code</th>		
		<th class="title">Title</th>
		<th class="unit">Units</th>
		<th class="day" <?php if($day==0){echo 'style="display:none;"';} ?>>Day</th>
		<th class="time" <?php if($time==0){echo 'style="display:none;"';} ?>>Time</th>		
		<th class="room" <?php if($room==0){echo 'style="display:none;"';} ?>>Room</th>
	</thead>
	<tbody>
		<?php
		foreach($stmt as $row) {	
            if($row["table_name"]=='tmp_sched') {
                $class = "text-danger";
            }
            else {
                $class = "text-success";
            }            	
		?>	
			<tr>
			<td><?php  if($row["table_name"]=='tmp_sched') { ?>
                            <button type="button" class="btn btn-danger" value="DEL"><i class="fas fa-trash-alt"></i></button>			
				<?php }else{ echo '<i class="fas fa-check-circle text-success"></i>'; }?>

				<input type="hidden" name="source" value="<?php echo $row["table_name"]; ?>"/>
                    <input type="hidden" name="idsched" value="<?php echo $row["idsched"]; ?>"/>
				<input type="hidden" name="idcurriculum" value="<?php echo $row["idcurriculum"]; ?>"/>                    
				</td>
			<td class="
                          <?php 
                              echo $class; ?>"><?php echo $row['subj']; 
                              if($row["table_name"]=='tmp_sched') {
                                   echo '<i class="fas fa-times-circle text-danger float-right"></i>';
                              }                              
                         ?> 
               </td>
			<td class="title <?php echo $class; ?>"><?php echo $row['description']; ?> </td>
			<td class="unit <?php echo $class; ?>"><?php echo $row['unit']; ?> </td>
			<td class="day <?php echo $class; ?>" <?php if($day==0){echo 'style="display:none;"';} ?>><?php echo $row['week_day_name']; ?> </td>
			<td class="time <?php echo $class;?>" <?php if($time==0){echo 'style="display:none;"';} ?>><?php echo $row['class_time']; ?> </td>
			<td class="room <?php echo $class;?>" <?php if($room==0){echo 'style="display:none;"';} ?>><?php echo $row['room']; ?> </td>
			</tr>
		<?php
		}
		?>		
	</tbody>
</table>
<div class="alert alert-success text-right" style="margin:0px"><?php echo 'TOTAL UNITS: <strong>'.get_total_subject_units($idsem_settings, $idstudent,0).'</strong>'; ?></div>
<!--<div class="alert alert-warning text-right" style="margin:0px"><?php echo 'TOTAL UNITS ARRPOVED BY ADVISER: <strong>'.get_total_subject_units($idsem_settings, $idstudent,1).'</strong>'; ?></div>-->
<!--<div class="alert alert-info text-right" style="margin:0px"><?php echo 'TOTAL UNITS ARRPOVED BY CHAIRPERSON: <strong>'.get_total_subject_units($idsem_settings, $idstudent,2).'</strong>'; ?></div>-->