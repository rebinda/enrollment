<?php
     include_once("include/connect.php");
     session_start();

	if ( !isset( $_SESSION[ 'is_login' ] ) ) {
		header( "Location: /" );
	}
     $idstudent = $_SESSION['idstudent'];

	if ( $_SERVER[ "REQUEST_METHOD" ] == "POST" ) {
		if (isset($_POST["submit"])) {			
			  if(trim($_POST['submit']) == "back"){
				   header("Location: pef.php");
			  }			  
		}
	}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Account</title>
    <link href="fontawesome5.9.0/css/all.min.css" rel="stylesheet">
	<link href="bootstrap-4.3.1/css/bootstrap.min.css" rel="stylesheet">
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="bootstrap-4.3.1/js/bootstrap.min.js"></script>
	<script src="js/devicedetector-min.js"></script>
	<script>$(function() {var selbtn = ''; $("#update").click(function(e) {selbtn = e.target.id; }); $("#user_account").submit(function(e) {if (selbtn == 'update') { update(); e.preventDefault(); } }); function show_alert(stat, msg) { $("#alerting").remove(); $("body").append('<div id="alerting" style="width:50%; margin-left:auto; margin-right:auto" class="fixed-top"><div class="alert '+stat+' alert-dismissible text-center"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>'+ msg +'</strong></div></div>') $("#alerting").fadeTo(3000, 500).slideUp(500, function(){$("#alerting").slideUp(500);}); } function update() {if (($("input[name='current_pass']").val()=='') || ($("input[name='new_pass']").val()=='') || ($("input[name='confirm_pass']").val()=='')) { show_alert("alert-danger","Password Empty!"); return; } if ($("input[name='new_pass']").val() !== $("input[name='confirm_pass']").val()) { show_alert("alert-danger","Confirm your password correctly!"); return; } $.ajax({ method: "POST", async: true, url: "include/verrify_user.php", data: { idstudent: <?php echo $idstudent; ?>, pass: $("input[name='current_pass']").val() }, beforeSend: function() {$("button").attr('disabled', true); $("input").prop('readonly', true); }, success: function(e) { $("button").attr('disabled', false); $("input").prop('readonly', false); if (e == 0) { show_alert("alert-danger","Incorrect Password!"); } else {execute();}}});}function execute() { $.ajax({method: "POST", async: true, url: "include/pass_update.php", data: { idstudent: <?php echo $idstudent; ?>, pass: $("input[name='confirm_pass']").val(), }, beforeSend: function() {$("button").attr('disabled', true); $("input").prop('readonly', true); }, success: function(e) { $("button").attr('disabled', false); $("input").prop('readonly', false); if (e==1) { show_alert("alert-success","Password has been updated!"); $("input[type='password']").val(''); }else{ show_alert("alert-warning",e.html()); }} }); }});</script>
</head>

<body>	
	<div class="container">		
		<div class="row">
			<div class="col-md-12">
				<h3 class="alert alert-info text-center display-12">CHANGE PASSWORD</h3>
			</div>
			
			<div class="col-md-12">
				<div style="width: 350px; margin-left: auto; margin-right: auto;">
				<form id="user_account" role="form" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Current Password">
								<span class="input-group-text">
									<i class="fas fa-unlock fa-lg fa-fw"></i>
								</span>
							</div>
							<input class="form-control" type="password" placeholder="Current Password" name="current_pass">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="New Password">
								<span class="input-group-text">
									<i class="fas fa-key fa-lg fa-fw"></i>
								</span>
							</div>
							<input class="form-control" type="password" placeholder="New Password" name="new_pass">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Confirm Password">
								<span class="input-group-text">
									<i class="fas fa-user-lock fa-lg fa-fw"></i>
								</span>
							</div>
							<input class="form-control" type="password" placeholder="Confirm Password" name="confirm_pass">
						</div>
					</div>
					<div class="form-group">						
						<button id="idsubmit" class="btn btn btn-danger" type="submit" value="back" name="submit">
							<i class="fas fa-long-arrow-alt-left fa-lg"></i> Back
						</button>
						<button id="update" class="btn btn-dark" type="submit" value="Submit" name="update">
							<i class="fas fa-check fa-lg"></i> Update
						</button>
					</div>
					</div>
					</div>					
				</form>
			</div>
		</div>
	</div>	
</body>
</html>