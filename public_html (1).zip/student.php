<?php
include_once('include/connect.php');
$res='';
$fname = '';
$lname = '';
$dob='';

if( $_SERVER[ 'REQUEST_METHOD' ] == "POST" ) {
     if(isset($_POST['back'])) {
          header("Location: /pef/");
     }
     if ( isset( $_POST['retrieve'] ) ) {          
          $fname = $_POST[ 'fname' ];
          $lname = $_POST[ 'lname' ];
          $dob = $_POST['dob'];
          $stmt = $pdo->prepare( "SELECT idnumber FROM student WHERE lname=? AND fname=? AND dob=?;" );
          $stmt->execute([$lname, $fname, $dob]);
          $count = $stmt->rowCount();
          $row = $stmt->fetchColumn();
          if ( $count > 0 ) {
               $res = '<p class="alert alert-success text-center" style="width:270px; margin-left:auto; margin-right:auto; margin-top:10px;"><small>Your ID Number is: <strong class="badge badge-info" style="font:normal 1.2em consolas;">'.$row. '</strong></small></p>';
          }
          else {
               $res = '<p class="alert alert-warning text-center" style="width:270px; margin-left:auto; margin-right:auto; margin-top:10px;"><small><strong>Unable to retrieve your Id Number.</strong></small></p>';
          }
     }
}
?>
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link href="fontawesome5.9.0/css/all.min.css" rel="stylesheet">
     <link href="bootstrap-4.3.1/css/bootstrap.min.css" rel="stylesheet">
     <link href="bootstrap4-toggle-3.5.0/css/bootstrap4-toggle.min.css" rel="stylesheet">
     <script src="js/jquery-3.3.1.min.js"></script>
     <script src="js/popper.min.js"></script>
     <script src="bootstrap-4.3.1/js/bootstrap.min.js"></script>
     <script src="bootstrap4-toggle-3.5.0/js/bootstrap4-toggle.min.js"></script>
     <meta charset="utf-8">
     <title>PSU Computer Studies Department PEF</title>
     <script>
          $(function() {
            $('[data-toggle="tooltip"]').tooltip();   
          })
     </script>         
</head>

<body>
     <h2 class="jumbotron text-center alert-info" style="height:100px; padding: 30px 0 30px 0;">ACCESS ID NUMBER</h2>
     <div class="container">
          <div class="row">
               <div class="col-md-12">
                    <div style="width:270px; margin-left:auto; margin-right:auto;">
                         <form role="form" id="recover" method="post" action="<?php echo( htmlspecialchars($_SERVER["PHP_SELF"])); ?>">
                              <div class="form-group">
                                   <div class="input-group">
                                        <div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Lastname"> <span class="input-group-text"> <i class="fas fa-align-left fa-fw"></i> </span>
                                        </div> <input type="text" class="form-control" name="lname" placeholder="Lastname" value="<?php echo $lname; ?>">
                                   </div>
                              </div>
                              <div class="form-group">
                                   <div class="input-group">
                                        <div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Firstname"> <span class="input-group-text"> <i class="fas fa-align-right fa-fw"></i> </span>
                                        </div> <input type="text" class="form-control" name="fname" placeholder="Firstname" value="<?php echo $fname; ?>">
                                   </div>
                              </div>
                              
                              <div class="form-group">                              
                                   <div class="input-group">
                                        <div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Birthdate"> <span class="input-group-text"> <i class="far fa-calendar-alt fa-fw"></i> </span>
                                        </div> <input type="date" name="dob" placeholder="yyyy-mm-dd" class="form-control" value="<?php echo $dob; ?>">
                                   </div>
					     </div>

                              <button id="idsubmit" class="btn btn-success" type="submit" value="Retrieve" name="retrieve"><i class="fas fa-check"></i> Retrieve</button> <button id="idlogout" class="btn btn-primary" type="submit" value="Back" name="back"><i class="fas fa-home"></i> Home</button>
                         </form>
                    </div>
               </div>
          </div>
          <div class="row">
               <div class="col-md-12">
                    <?php echo $res; ?>
                    <p class="text-center text-primary small" style="margin-top:20px;">Powered by Computer Studies. Copyright 2019</p>
               </div>
          </div>
     </div>
</body>
</html>