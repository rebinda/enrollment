<?php
session_start();
include_once( "include/function.php" );
$idstudent = $_SESSION[ 'idstudent' ];
$idcourse = get_idcourse($idstudent);

if ( !isset( $_SESSION[ 'is_login' ] ) ) {
	header( "Location: /" );
}

if ( $_SERVER[ "REQUEST_METHOD" ] == "POST" ) {
    if (isset($_POST["action"])) {
        if(trim($_POST['action']) == "Back") {
            header("Location: pef.php");
            
        }
        elseif (trim($_POST['action']) == "Generate Certificate") {
            header("Location: cog.php");
            // Add code here to handle the generation of the Certificate of Grades
            // You can redirect to a new page or perform any other necessary actions
            // For example, you can use header("Location: generate_certificate.php");
        }
        else{
            header("Location: pef.php");
        }
    }    
}
?>

<!doctype html>
<html lang="en"><head><meta name="viewport" content="width=device-width, initial-scale=1.0"><link href="fontawesome5.9.0/css/all.min.css" rel="stylesheet"><link href="bootstrap-4.3.1/css/bootstrap.min.css" rel="stylesheet"><link href="css/cb.css" rel="stylesheet"><link href="scrollbar/jquery.mCustomScrollbar.css" rel="stylesheet"><script src="js/jquery-3.3.1.min.js"></script><script src="js/popper.min.js"></script><script src="bootstrap-4.3.1/js/bootstrap.min.js"></script><script src="js/devicedetector-min.js"></script><script src="scrollbar/jquery.mCustomScrollbar.js"></script><script src="scrollbar/jquery.mCustomScrollbar.concat.min.js"></script><title>Palawan State University Grade Inventory</title><meta name="description" content="This page shows unofficial copy of grades. The grades may vary from the copy of OUR."><meta charset="utf-8"><style>th {padding:10px 0 10px 5px;} td {font-size: 0.9em;} </style> </head>
<body>
    <div class = "container">
        <div class="row">
            <div class="col-md-12">
                <h3 class="alert alert-info text-center display-12">GRADE INVENTORY</h3>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-6">
                <h4><small>STUDENT NAME: </small><span><?php echo get_student_name($idstudent);?></span></h4>
            </div>
			<div class="col-md-6">
				<div class="input-group">
				<div class="input-group-prepend" data-placement="top" data-toggle="tooltip" title="Course"> <span class="input-group-text"> <i class="fas fa-route fa-fw"></i> </span>
				</div>
				<select id="course" aria-label="Program"> class="form-control">
						<?php
						$stmt = $pdo->prepare("SELECT * FROM course WHERE idcourse IN (SELECT idcourse from student_grades WHERE idcourse = ?)ORDER BY course_name ASC;");
					    $stmt->execute([$idcourse]);
						foreach ( $stmt as $row ) {
							if ( $idcourse == $row[ 'idcourse' ] ) {
								echo '<option value="' . $row[ 'idcourse' ] . '" selected>' . $row[ 'course_name' ] . '</option>';
							} else {
								echo '<option value="' . $row[ 'idcourse' ] . '" >' . $row[ 'course_name' ] . '</option>';
							}

						}
						?></select>
				</div>
			</div>
        </div>		
        <div class="row mb-3">
            <div class="col-md-6">
                <small class="text-danger">[ * ] - Unposted</small>
            </div>
            <div class="col-md-6 text-right">
                <form  action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <button aria-label="Back" class="btn btn-dark" name="action" type="submit" value="Back"><i class="fas fa-long-arrow-alt-left fa-lg"></i> Back</button>
                    <button aria-label="Generate Certificate" class="btn btn-danger" name="action" type="submit" value="Generate Certificate"><i class="fas fa-print fa-lg"></i> Generate Certificate</button>
                </form>
            </div>            
        </div>
        <div class="row">
            <div class="col-md-12">
                <div id="result"></div>
            <div>
        </div>        
    </div>
</body>
<script>$(function() {function show_grades() {$.ajax({ method:"POST", url:"include/sg.php",data:{idcourse: $( "#course" ).val()},success: function(e) { $("#result").html(e);merge_common_rows("#sched_block tbody tr"); }});}$("#course").change( function () {show_grades();});function merge_common_rows(table) { var $prev_row = $(table).find("td");var $row = $(table).next().find("td"); var rowspan = 1;$(table).each(function () {var sem = $row.eq(0).text();var prev_sem = $prev_row.eq(0).text(); if (sem == prev_sem) { rowspan++; $row.eq(0).remove(); $prev_row.eq(0).attr('rowspan', rowspan); $row = $row.parent().next().find("td"); } else { rowspan = 1; $prev_row = $row.parent().find("td"); $row = $row.parent().next().find("td");}});}show_grades();});</script>
</html>